# Installation Quick Reference

## 🎯 Choose Your Installation Method

### Method 1: One-Click Installer ⚡ (RECOMMENDED)

**Best for:** Everyone - simplest and fastest!

**Time:** 5-10 minutes total

**What you get:**
- ✅ All dependencies bundled and installed
- ✅ Automatic configuration
- ✅ Services auto-start
- ✅ GUI wizard on Windows
- ✅ Interactive CLI on Linux

**How to install:**

#### Server
```batch
# Windows (Run as Administrator)
server-installer-windows.bat

# Linux (Run with sudo)
sudo bash server-installer-linux.sh
```

#### Agent
```batch
# Windows (Run as Administrator)
agent-installer-windows.bat

# Linux (Run with sudo)
sudo bash agent-installer-linux.sh
```

**What gets installed:**
- Server: PostgreSQL, Redis, MinIO, Node.js, Backend, Frontend
- Agent: Python, OpenJDK, JMeter, Load Generator

**After installation:**
- Access server: `http://localhost:8080`
- Default credentials shown during install
- Check [SETUP_WIZARD.md](SETUP_WIZARD.md) for details

---

### Method 2: Manual Developer Setup

**Best for:** Developers who want full control

**Time:** 30-60 minutes

**Prerequisites:**
- Node.js 18+
- PostgreSQL 15+
- Redis 7+
- Python 3.11+
- Java 17+
- JMeter 5.6.3+

**How to install:**
Follow [GETTING_STARTED.md](GETTING_STARTED.md)

---

### Method 3: Docker Deployment

**Best for:** Containerized environments

**Time:** 15-20 minutes

**Prerequisites:**
- Docker & Docker Compose

**How to deploy:**

```bash
# Clone repository
git clone <repo-url>

# Start server
cd docker
docker-compose up -d

# Deploy agents
docker run -d --name agent-1 \
  -e BACKEND_URL=http://server:3000 \
  jmeter-platform/agent:latest
```

**Check:** [AGENT_DEPLOYMENT.md](AGENT_DEPLOYMENT.md) for details

---

### Method 4: Kubernetes Deployment

**Best for:** Production environments, cloud-native

**Time:** 20-30 minutes

**Prerequisites:**
- Kubernetes cluster
- kubectl configured
- Helm (optional)

**How to deploy:**

```bash
# Deploy server
kubectl apply -f k8s/server/

# Deploy agents
kubectl apply -f k8s/agent/

# Scale agents
kubectl scale deployment jmeter-agent --replicas=5
```

**Check:** [AGENT_DEPLOYMENT.md](AGENT_DEPLOYMENT.md) for details

---

## 📊 Comparison Matrix

| Feature | One-Click | Manual | Docker | Kubernetes |
|---------|-----------|--------|--------|------------|
| **Setup Time** | 5-10 min | 30-60 min | 15-20 min | 20-30 min |
| **Dependencies** | Auto-installed | Manual | Containerized | Containerized |
| **Configuration** | Wizard | Manual | Environment vars | ConfigMaps |
| **Best For** | Quick start | Development | Testing | Production |
| **Skill Level** | Beginner | Intermediate | Intermediate | Advanced |
| **Customization** | Limited | Full | High | Highest |
| **Updates** | Auto-updater | Manual | Image rebuild | Rolling update |

## 🚀 Recommended Path

### For First-Time Users
1. **Start with One-Click Installer** ⚡
2. Test with sample JMX files
3. Deploy 1-2 agents
4. Run your first distributed test
5. Explore features

### For Development Teams
1. **Use One-Click Installer** for server
2. **Deploy agents** via Docker/K8s
3. Integrate with CI/CD
4. Scale as needed

### For Enterprise
1. **Use Kubernetes** deployment
2. Set up HA configuration
3. Configure monitoring
4. Implement backup strategy
5. Set up DR plan

## 📋 Post-Installation Checklist

### Server
- [ ] Access web interface at http://localhost:8080
- [ ] Login with default credentials
- [ ] Change admin password
- [ ] Create first project
- [ ] Upload sample JMX file
- [ ] Check all services running

### Agent
- [ ] Verify agent appears in UI
- [ ] Check agent status (healthy)
- [ ] Test agent connectivity
- [ ] Run sample test
- [ ] Check logs

### Optional
- [ ] Configure SSL/TLS
- [ ] Set up firewall rules
- [ ] Configure backup
- [ ] Set up monitoring
- [ ] Create additional users
- [ ] Deploy more agents

## 🆘 Troubleshooting

### Installation Fails

**Problem:** Installer stops with error

**Solutions:**
1. Check system requirements
2. Run as Administrator (Windows) or with sudo (Linux)
3. Disable antivirus temporarily
4. Check logs in installation directory
5. Ensure ports not already in use

### Can't Access Web Interface

**Problem:** Browser can't connect to http://localhost:8080

**Solutions:**
1. Check if service is running
   ```bash
   # Windows
   sc query JMeterPlatformBackend
   
   # Linux
   sudo systemctl status jmeter-platform-backend
   ```
2. Check firewall settings
3. Try http://127.0.0.1:8080
4. Check logs for errors

### Agent Not Connecting

**Problem:** Agent doesn't appear in UI

**Solutions:**
1. Verify server URL in agent config
2. Check network connectivity
3. Verify firewall allows outbound connections
4. Check agent logs
5. Restart agent service

### Common Port Conflicts

| Service | Default Port | Alternative |
|---------|--------------|-------------|
| Backend API | 3000 | 3001, 8000 |
| Frontend | 8080 | 8081, 80 |
| PostgreSQL | 5432 | 5433 |
| Redis | 6379 | 6380 |
| MinIO | 9000 | 9001 |

To change ports, edit configuration files during installation or after in:
- Windows: `C:\JMeterPlatform\config\`
- Linux: `/etc/jmeter-platform/`

## 📞 Getting Help

### Documentation
- [README.md](README.md) - Complete overview
- [SETUP_WIZARD.md](SETUP_WIZARD.md) - Detailed installation guide
- [GETTING_STARTED.md](GETTING_STARTED.md) - Manual setup
- [PLATFORM_SUPPORT.md](PLATFORM_SUPPORT.md) - Platform compatibility

### Logs Location
**Server:**
- Windows: `C:\JMeterPlatform\logs\`
- Linux: `/var/log/jmeter-platform/`

**Agent:**
- Windows: `C:\JMeterAgent\logs\`
- Linux: `/var/log/jmeter-agent/`

### Support Channels
- GitHub Issues
- Community Forum
- Documentation Wiki
- Email Support

## 🎊 Next Steps After Installation

1. **Login** to web interface
2. **Create** your first project
3. **Upload** a JMX script
4. **Deploy** additional agents if needed
5. **Run** your first test
6. **View** real-time results
7. **Export** results to CSV
8. **Compare** multiple test runs

## 📚 Learn More

- [Architecture](ARCHITECTURE.md) - Understand the system
- [API Reference](API_REFERENCE.md) - Integrate with APIs
- [Features](FEATURE_CHECKLIST.md) - See all capabilities
- [Deployment](AGENT_DEPLOYMENT.md) - Advanced deployment

---

**Ready to get started?** Choose your installation method above and follow the guide!
