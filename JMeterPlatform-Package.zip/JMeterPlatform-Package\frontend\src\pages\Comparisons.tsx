import { useEffect, useState } from 'react';
import {
  Container,
  Typography,
  Card,
  CardContent,
  Box,
  Button,
  Alert,
  CircularProgress,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Chip,
  Checkbox,
  FormControlLabel,
  FormGroup,
  AppBar,
  Toolbar,
  Stepper,
  Step,
  StepLabel,
  Grid,
  TextField,
  InputAdornment,
} from '@mui/material';
import MuiTooltip from '@mui/material/Tooltip';
import CompareArrowsIcon from '@mui/icons-material/CompareArrows';
import RestartAltIcon from '@mui/icons-material/RestartAlt';
import SearchIcon from '@mui/icons-material/Search';
import DownloadIcon from '@mui/icons-material/Download';
import { api } from '../api/client';

interface Test {
  id: string;
  name: string;
  status: string;
  createdAt: string;
  project: {
    name: string;
  };
}

interface Transaction {
  label: string;
  avg: number;
  min: number;
  max: number;
  p90: number;
  pass: number;
  fail: number;
  errorRate: number;
}

interface TestWithTransactions {
  test: Test;
  transactions: Transaction[];
}

export default function Comparisons() {
  const [tests, setTests] = useState<Test[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [activeStep, setActiveStep] = useState(0);
  
  // Step 1: Selected tests
  const [selectedTests, setSelectedTests] = useState<string[]>([]);
  const [searchFilter, setSearchFilter] = useState('');
  
  // Step 3: Comparison search
  const [comparisonSearchFilter, setComparisonSearchFilter] = useState('');
  
  // Step 2: Selected metrics
  const [selectedMetrics, setSelectedMetrics] = useState({
    avg: true,
    min: true,
    max: true,
    p90: true,
    p95: false,
    count: true,
    errorRate: true,
  });
  
  // Step 3: Comparison data
  const [comparisonData, setComparisonData] = useState<TestWithTransactions[]>([]);
  const [generatingComparison, setGeneratingComparison] = useState(false);

  const steps = ['Select Tests (2-5)', 'Select Metrics', 'View Comparison'];

  useEffect(() => {
    loadTests();
  }, []);

  const loadTests = async () => {
    try {
      setLoading(true);
      const data = await api.getTests();
      console.log('Loaded tests:', data);
      // Filter only completed tests
      const completedTests = data.filter((t: Test) => t.status === 'completed');
      console.log('Completed tests:', completedTests);
      setTests(completedTests);
      setError('');
    } catch (err: any) {
      console.error('Failed to load tests:', err);
      setError(err.response?.data?.error || 'Failed to load tests');
    } finally {
      setLoading(false);
    }
  };

  const handleTestSelection = (testId: string) => {
    setSelectedTests(prev => {
      if (prev.includes(testId)) {
        return prev.filter(id => id !== testId);
      } else if (prev.length < 5) {
        return [...prev, testId];
      }
      return prev;
    });
  };

  const handleGenerateComparison = async () => {
    if (selectedTests.length < 2 || selectedTests.length > 5) {
      setError('Please select 2 to 5 tests');
      return;
    }
    setActiveStep(1);
  };

  const handleGenerateComparisonTable = async () => {
    setGeneratingComparison(true);
    try {
      const testsData: TestWithTransactions[] = [];
      
      for (const testId of selectedTests) {
        const test = tests.find(t => t.id === testId)!;
        const transactions = await api.getTestTransactions(testId);
        testsData.push({ test, transactions });
      }
      
      setComparisonData(testsData);
      setActiveStep(2);
      setError('');
    } catch (err: any) {
      setError(err.response?.data?.error || 'Failed to generate comparison');
    } finally {
      setGeneratingComparison(false);
    }
  };

  const handleReset = () => {
    setActiveStep(0);
    setSelectedTests([]);
    setComparisonData([]);
    setSelectedMetrics({
      avg: true,
      min: true,
      max: true,
      p90: true,
      p95: false,
      count: true,
      errorRate: true,
    });
  };

  // Get all unique transaction labels across selected tests
  const getAllLabels = () => {
    const labels = new Set<string>();
    comparisonData.forEach(data => {
      data.transactions.forEach(txn => labels.add(txn.label));
    });
    return Array.from(labels).sort();
  };

  // Get transaction by label for a specific test
  const getTransactionByLabel = (testData: TestWithTransactions, label: string) => {
    return testData.transactions.find(t => t.label === label);
  };

  // Calculate P95 (approximation)
  const calculateP95 = (txn: Transaction) => {
    // Approximate P95 from P90 and max
    return Math.round(txn.p90 + (txn.max - txn.p90) * 0.5);
  };

  const exportToCSV = () => {
    // Get filtered labels
    const filteredLabels = getAllLabels().filter(label => {
      if (!comparisonSearchFilter) return true;
      return label.toLowerCase().includes(comparisonSearchFilter.toLowerCase());
    });

    // Build CSV header
    const headers = ['Label'];
    
    if (selectedMetrics.avg) {
      comparisonData.forEach(data => headers.push(`Avg - ${data.test.name}`));
    }
    if (selectedMetrics.min) {
      comparisonData.forEach(data => headers.push(`Min - ${data.test.name}`));
    }
    if (selectedMetrics.max) {
      comparisonData.forEach(data => headers.push(`Max - ${data.test.name}`));
    }
    if (selectedMetrics.p90) {
      comparisonData.forEach(data => headers.push(`P90 - ${data.test.name}`));
    }
    if (selectedMetrics.p95) {
      comparisonData.forEach(data => headers.push(`P95 - ${data.test.name}`));
    }
    if (selectedMetrics.count) {
      comparisonData.forEach(data => headers.push(`Count - ${data.test.name}`));
    }
    if (selectedMetrics.errorRate) {
      comparisonData.forEach(data => headers.push(`Error% - ${data.test.name}`));
    }

    // Build CSV rows
    const rows = filteredLabels.map(label => {
      const row = [label];
      
      if (selectedMetrics.avg) {
        comparisonData.forEach(data => {
          const txn = getTransactionByLabel(data, label);
          row.push(txn ? txn.avg.toFixed(2) : 'N/A');
        });
      }
      if (selectedMetrics.min) {
        comparisonData.forEach(data => {
          const txn = getTransactionByLabel(data, label);
          row.push(txn ? txn.min.toString() : 'N/A');
        });
      }
      if (selectedMetrics.max) {
        comparisonData.forEach(data => {
          const txn = getTransactionByLabel(data, label);
          row.push(txn ? txn.max.toString() : 'N/A');
        });
      }
      if (selectedMetrics.p90) {
        comparisonData.forEach(data => {
          const txn = getTransactionByLabel(data, label);
          row.push(txn ? txn.p90.toString() : 'N/A');
        });
      }
      if (selectedMetrics.p95) {
        comparisonData.forEach(data => {
          const txn = getTransactionByLabel(data, label);
          row.push(txn ? calculateP95(txn).toString() : 'N/A');
        });
      }
      if (selectedMetrics.count) {
        comparisonData.forEach(data => {
          const txn = getTransactionByLabel(data, label);
          row.push(txn ? (txn.pass + txn.fail).toString() : 'N/A');
        });
      }
      if (selectedMetrics.errorRate) {
        comparisonData.forEach(data => {
          const txn = getTransactionByLabel(data, label);
          row.push(txn ? txn.errorRate.toFixed(2) : 'N/A');
        });
      }
      
      return row;
    });

    // Combine headers and rows
    const csvContent = [
      headers.join(','),
      ...rows.map(row => row.join(','))
    ].join('\n');

    // Download CSV
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `comparison_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  if (loading) {
    return (
      <Box sx={{ background: 'linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%)', minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <CircularProgress size={60} sx={{ color: '#667eea' }} />
      </Box>
    );
  }

  return (
    <Box sx={{ background: 'linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%)', minHeight: '100vh', pb: 4 }}>
      <AppBar position="static" elevation={0} sx={{ background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)' }}>
        <Toolbar sx={{ justifyContent: 'space-between' }}>
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <CompareArrowsIcon sx={{ mr: 2, fontSize: 32 }} />
            <Typography variant="h5" component="h1" sx={{ fontWeight: 700 }}>
              📊 Test Comparisons
            </Typography>
          </Box>
          {activeStep > 0 && (
            <Button
              variant="contained"
              startIcon={<RestartAltIcon />}
              onClick={handleReset}
              sx={{ 
                bgcolor: 'white', 
                color: '#667eea',
                fontWeight: 600,
                '&:hover': { bgcolor: '#f5f5f5' }
              }}
            >
              Start Over
            </Button>
          )}
        </Toolbar>
      </AppBar>

      <Container maxWidth={false} sx={{ mt: 4 }}>
        {error && (
          <Alert severity="error" sx={{ mb: 3, borderRadius: 2 }} onClose={() => setError('')}>
            {error}
          </Alert>
        )}

        {tests.length < 2 && (
          <Alert severity="info" sx={{ mb: 3, borderRadius: 2 }}>
            ℹ️ You need at least 2 completed tests to create a comparison
          </Alert>
        )}

        <Card sx={{ mb: 3 }}>
          <CardContent>
            <Stepper activeStep={activeStep} alternativeLabel>
              {steps.map((label) => (
                <Step key={label}>
                  <StepLabel>{label}</StepLabel>
                </Step>
              ))}
            </Stepper>
          </CardContent>
        </Card>

        {/* Step 1: Select Tests */}
        {activeStep === 0 && (
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Select Tests to Compare (2-5 tests)
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
                Selected: {selectedTests.length} / 5
              </Typography>
              
              <TextField
                fullWidth
                placeholder="Search tests by name or project..."
                value={searchFilter}
                onChange={(e) => setSearchFilter(e.target.value)}
                sx={{ mb: 3 }}
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <SearchIcon />
                    </InputAdornment>
                  ),
                }}
              />
              
              <TableContainer>
                <Table>
                  <TableHead>
                    <TableRow>
                      <TableCell padding="checkbox"></TableCell>
                      <TableCell>Test Name</TableCell>
                      <TableCell>Project</TableCell>
                      <TableCell>Status</TableCell>
                      <TableCell>Created</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {tests
                      .filter(test => {
                        if (!searchFilter) return true;
                        const search = searchFilter.toLowerCase();
                        return (
                          test.name.toLowerCase().includes(search) ||
                          test.project.name.toLowerCase().includes(search)
                        );
                      })
                      .map((test) => (
                      <TableRow 
                        key={test.id}
                        hover
                        onClick={() => handleTestSelection(test.id)}
                        sx={{ cursor: 'pointer' }}
                      >
                        <TableCell padding="checkbox">
                          <Checkbox
                            checked={selectedTests.includes(test.id)}
                            disabled={!selectedTests.includes(test.id) && selectedTests.length >= 5}
                          />
                        </TableCell>
                        <TableCell>{test.name}</TableCell>
                        <TableCell>{test.project.name}</TableCell>
                        <TableCell>
                          <Chip label={test.status} color="success" size="small" />
                        </TableCell>
                        <TableCell>{new Date(test.createdAt).toLocaleString()}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>

              <Box sx={{ mt: 3, textAlign: 'right' }}>
                <Button
                  variant="contained"
                  onClick={handleGenerateComparison}
                  disabled={selectedTests.length < 2 || selectedTests.length > 5}
                  sx={{ 
                    background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                    px: 4
                  }}
                >
                  Next: Select Metrics
                </Button>
              </Box>
            </CardContent>
          </Card>
        )}

        {/* Step 2: Select Metrics */}
        {activeStep === 1 && (
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Select Metrics to Compare
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
                Choose which performance metrics you want to see in the comparison table
              </Typography>

              <FormGroup>
                <Grid container spacing={2}>
                  <Grid item xs={12} sm={6} md={4}>
                    <FormControlLabel
                      control={
                        <Checkbox
                          checked={selectedMetrics.avg}
                          onChange={(e) => setSelectedMetrics({...selectedMetrics, avg: e.target.checked})}
                        />
                      }
                      label="Average Response Time (ms)"
                    />
                  </Grid>
                  <Grid item xs={12} sm={6} md={4}>
                    <FormControlLabel
                      control={
                        <Checkbox
                          checked={selectedMetrics.min}
                          onChange={(e) => setSelectedMetrics({...selectedMetrics, min: e.target.checked})}
                        />
                      }
                      label="Min Response Time (ms)"
                    />
                  </Grid>
                  <Grid item xs={12} sm={6} md={4}>
                    <FormControlLabel
                      control={
                        <Checkbox
                          checked={selectedMetrics.max}
                          onChange={(e) => setSelectedMetrics({...selectedMetrics, max: e.target.checked})}
                        />
                      }
                      label="Max Response Time (ms)"
                    />
                  </Grid>
                  <Grid item xs={12} sm={6} md={4}>
                    <FormControlLabel
                      control={
                        <Checkbox
                          checked={selectedMetrics.p90}
                          onChange={(e) => setSelectedMetrics({...selectedMetrics, p90: e.target.checked})}
                        />
                      }
                      label="P90 Response Time (ms)"
                    />
                  </Grid>
                  <Grid item xs={12} sm={6} md={4}>
                    <FormControlLabel
                      control={
                        <Checkbox
                          checked={selectedMetrics.p95}
                          onChange={(e) => setSelectedMetrics({...selectedMetrics, p95: e.target.checked})}
                        />
                      }
                      label="P95 Response Time (ms)"
                    />
                  </Grid>
                  <Grid item xs={12} sm={6} md={4}>
                    <FormControlLabel
                      control={
                        <Checkbox
                          checked={selectedMetrics.count}
                          onChange={(e) => setSelectedMetrics({...selectedMetrics, count: e.target.checked})}
                        />
                      }
                      label="Sample Count"
                    />
                  </Grid>
                  <Grid item xs={12} sm={6} md={4}>
                    <FormControlLabel
                      control={
                        <Checkbox
                          checked={selectedMetrics.errorRate}
                          onChange={(e) => setSelectedMetrics({...selectedMetrics, errorRate: e.target.checked})}
                        />
                      }
                      label="Error Rate (%)"
                    />
                  </Grid>
                </Grid>
              </FormGroup>

              <Box sx={{ mt: 3, display: 'flex', justifyContent: 'space-between' }}>
                <Button
                  variant="outlined"
                  onClick={() => setActiveStep(0)}
                >
                  Back
                </Button>
                <Button
                  variant="contained"
                  onClick={handleGenerateComparisonTable}
                  disabled={generatingComparison || !Object.values(selectedMetrics).some(v => v)}
                  sx={{ 
                    background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                    px: 4
                  }}
                >
                  {generatingComparison ? <CircularProgress size={24} color="inherit" /> : 'Generate Comparison'}
                </Button>
              </Box>
            </CardContent>
          </Card>
        )}

        {/* Step 3: View Comparison */}
        {activeStep === 2 && comparisonData.length > 0 && (
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Comparison Results
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
                Comparing {comparisonData.length} tests across {getAllLabels().length} transaction types
              </Typography>

              <Box sx={{ display: 'flex', gap: 2, mb: 3 }}>
                <TextField
                  fullWidth
                  placeholder="Search transaction labels..."
                  value={comparisonSearchFilter}
                  onChange={(e) => setComparisonSearchFilter(e.target.value)}
                  InputProps={{
                    startAdornment: (
                      <InputAdornment position="start">
                        <SearchIcon />
                      </InputAdornment>
                    ),
                  }}
                />
                <Button
                  variant="contained"
                  startIcon={<DownloadIcon />}
                  onClick={exportToCSV}
                  sx={{ 
                    minWidth: 150,
                    background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)'
                  }}
                >
                  Export CSV
                </Button>
              </Box>

              <TableContainer component={Paper} sx={{ maxHeight: 600 }}>
                <Table stickyHeader size="small">
                  <TableHead>
                    <TableRow>
                      <TableCell sx={{ fontWeight: 'bold', bgcolor: '#f5f5f5' }}>Label</TableCell>
                      {selectedMetrics.avg && comparisonData.map(data => (
                        <TableCell key={`avg-${data.test.id}`} sx={{ fontWeight: 'bold', bgcolor: '#e3f2fd', textAlign: 'center' }}>
                          Avg
                          <Typography variant="caption" display="block" color="text.secondary">
                            {data.test.name}
                          </Typography>
                        </TableCell>
                      ))}
                      {selectedMetrics.min && comparisonData.map(data => (
                        <TableCell key={`min-${data.test.id}`} sx={{ fontWeight: 'bold', bgcolor: '#f3e5f5', textAlign: 'center' }}>
                          Min
                          <Typography variant="caption" display="block" color="text.secondary">
                            {data.test.name}
                          </Typography>
                        </TableCell>
                      ))}
                      {selectedMetrics.max && comparisonData.map(data => (
                        <TableCell key={`max-${data.test.id}`} sx={{ fontWeight: 'bold', bgcolor: '#fff3e0', textAlign: 'center' }}>
                          Max
                          <Typography variant="caption" display="block" color="text.secondary">
                            {data.test.name}
                          </Typography>
                        </TableCell>
                      ))}
                      {selectedMetrics.p90 && comparisonData.map(data => (
                        <TableCell key={`p90-${data.test.id}`} sx={{ fontWeight: 'bold', bgcolor: '#e8f5e9', textAlign: 'center' }}>
                          P90
                          <Typography variant="caption" display="block" color="text.secondary">
                            {data.test.name}
                          </Typography>
                        </TableCell>
                      ))}
                      {selectedMetrics.p95 && comparisonData.map(data => (
                        <TableCell key={`p95-${data.test.id}`} sx={{ fontWeight: 'bold', bgcolor: '#fce4ec', textAlign: 'center' }}>
                          P95
                          <Typography variant="caption" display="block" color="text.secondary">
                            {data.test.name}
                          </Typography>
                        </TableCell>
                      ))}
                      {selectedMetrics.count && comparisonData.map(data => (
                        <TableCell key={`count-${data.test.id}`} sx={{ fontWeight: 'bold', bgcolor: '#f1f8e9', textAlign: 'center' }}>
                          Count
                          <Typography variant="caption" display="block" color="text.secondary">
                            {data.test.name}
                          </Typography>
                        </TableCell>
                      ))}
                      {selectedMetrics.errorRate && comparisonData.map(data => (
                        <TableCell key={`error-${data.test.id}`} sx={{ fontWeight: 'bold', bgcolor: '#ffebee', textAlign: 'center' }}>
                          Error%
                          <Typography variant="caption" display="block" color="text.secondary">
                            {data.test.name}
                          </Typography>
                        </TableCell>
                      ))}
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {getAllLabels()
                      .filter(label => {
                        if (!comparisonSearchFilter) return true;
                        return label.toLowerCase().includes(comparisonSearchFilter.toLowerCase());
                      })
                      .map(label => (
                      <TableRow key={label} hover>
                        <TableCell sx={{ fontWeight: 'bold', position: 'sticky', left: 0, bgcolor: 'white', zIndex: 1 }}>
                          <MuiTooltip title={label} arrow>
                            <span>
                              {label.length > 50 ? `${label.slice(0, 50)}…` : label}
                            </span>
                          </MuiTooltip>
                        </TableCell>
                        {selectedMetrics.avg && comparisonData.map(data => {
                          const txn = getTransactionByLabel(data, label);
                          return (
                            <TableCell key={`avg-${data.test.id}`} sx={{ textAlign: 'center' }}>
                              {txn ? txn.avg.toFixed(2) : 'N/A'}
                            </TableCell>
                          );
                        })}
                        {selectedMetrics.min && comparisonData.map(data => {
                          const txn = getTransactionByLabel(data, label);
                          return (
                            <TableCell key={`min-${data.test.id}`} sx={{ textAlign: 'center' }}>
                              {txn ? txn.min : 'N/A'}
                            </TableCell>
                          );
                        })}
                        {selectedMetrics.max && comparisonData.map(data => {
                          const txn = getTransactionByLabel(data, label);
                          return (
                            <TableCell key={`max-${data.test.id}`} sx={{ textAlign: 'center' }}>
                              {txn ? txn.max : 'N/A'}
                            </TableCell>
                          );
                        })}
                        {selectedMetrics.p90 && comparisonData.map(data => {
                          const txn = getTransactionByLabel(data, label);
                          return (
                            <TableCell key={`p90-${data.test.id}`} sx={{ textAlign: 'center' }}>
                              {txn ? txn.p90 : 'N/A'}
                            </TableCell>
                          );
                        })}
                        {selectedMetrics.p95 && comparisonData.map(data => {
                          const txn = getTransactionByLabel(data, label);
                          return (
                            <TableCell key={`p95-${data.test.id}`} sx={{ textAlign: 'center' }}>
                              {txn ? calculateP95(txn) : 'N/A'}
                            </TableCell>
                          );
                        })}
                        {selectedMetrics.count && comparisonData.map(data => {
                          const txn = getTransactionByLabel(data, label);
                          return (
                            <TableCell key={`count-${data.test.id}`} sx={{ textAlign: 'center' }}>
                              {txn ? (txn.pass + txn.fail).toLocaleString() : 'N/A'}
                            </TableCell>
                          );
                        })}
                        {selectedMetrics.errorRate && comparisonData.map(data => {
                          const txn = getTransactionByLabel(data, label);
                          return (
                            <TableCell 
                              key={`error-${data.test.id}`}
                              sx={{ 
                                textAlign: 'center',
                                color: txn && txn.errorRate > 5 ? 'error.main' : 
                                       txn && txn.errorRate > 1 ? 'warning.main' : 'success.main',
                                fontWeight: txn && txn.errorRate > 5 ? 'bold' : 'normal'
                              }}
                            >
                              {txn ? `${txn.errorRate.toFixed(2)}%` : 'N/A'}
                            </TableCell>
                          );
                        })}
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>

              <Box sx={{ mt: 3, display: 'flex', justifyContent: 'space-between' }}>
                <Button
                  variant="outlined"
                  onClick={() => setActiveStep(1)}
                >
                  Back to Metrics
                </Button>
                <Button
                  variant="contained"
                  onClick={handleReset}
                  sx={{ 
                    background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)'
                  }}
                >
                  New Comparison
                </Button>
              </Box>
            </CardContent>
          </Card>
        )}
      </Container>
    </Box>
  );
}
