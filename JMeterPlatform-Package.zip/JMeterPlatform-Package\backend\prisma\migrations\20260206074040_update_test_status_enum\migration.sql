-- AlterTable
ALTER TABLE "scripts" ADD COLUMN "threadGroupConfig" TEXT;
