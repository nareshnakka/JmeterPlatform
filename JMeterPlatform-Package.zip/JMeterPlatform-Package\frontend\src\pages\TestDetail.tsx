import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import {
  Container,
  Typography,
  Card,
  CardContent,
  Grid,
  Box,
  Button,
  Chip,
  Alert,
  CircularProgress,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableRow,
  TableHead,
  IconButton,
  Menu,
  MenuItem,
  LinearProgress,
  TextField,
  InputAdornment,
  Select,
  FormControl,
  InputLabel,
  Slider,
  Paper,
  Checkbox,
  FormControlLabel,
  FormGroup,
  Divider,
  Tabs,
  Tab,
} from '@mui/material';
import PlayArrowIcon from '@mui/icons-material/PlayArrow';
import StopIcon from '@mui/icons-material/Stop';
import DownloadIcon from '@mui/icons-material/Download';
import TimerIcon from '@mui/icons-material/Timer';
import TrendingUpIcon from '@mui/icons-material/TrendingUp';
import SpeedIcon from '@mui/icons-material/Speed';
import ErrorIcon from '@mui/icons-material/Error';
import ArrowUpwardIcon from '@mui/icons-material/ArrowUpward';
import ArrowDownwardIcon from '@mui/icons-material/ArrowDownward';
import SearchIcon from '@mui/icons-material/Search';
import RefreshIcon from '@mui/icons-material/Refresh';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import { wsClient } from '../api/websocket';
import ComputerIcon from '@mui/icons-material/Computer';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import MuiTooltip from '@mui/material/Tooltip';
import { api } from '../api/client';

interface Test {
  id: string;
  name: string;
  status: string;
  threads: number;
  duration: number;
  rampUp: number;
  createdAt: string;
  startedAt: string | null;
  completedAt: string | null;
  script: {
    name: string;
  };
  project: {
    name: string;
  };
}

interface TestMetric {
  id: string;
  timestamp: string;
  label: string;
  responseTime: number;
  throughput: number;
  errorRate: number;
  activeThreads: number;
  success?: boolean;
}

interface TestResult {
  id: string;
  totalSamples: number;
  successfulSamples: number;
  failedSamples: number;
  avgResponseTime: number;
  minResponseTime: number;
  maxResponseTime: number;
  throughput: number;
  errorRate: number;
  p50: number;
  p90: number;
  p95: number;
  p99: number;
}

interface TestLog {
  timestamp: string;
  level: string;
  message: string;
  agent: string;
}

interface AgentResult {
  id: string;
  agentId: string;
  threads: number;
  status: string;
  totalSamples: number | null;
  successfulSamples: number | null;
  failedSamples: number | null;
  avgResponseTime: number | null;
  minResponseTime: number | null;
  maxResponseTime: number | null;
  throughput: number | null;
  errorRate: number | null;
  completedAt: string | null;
  agent: {
    id: string;
    name: string;
    location: string;
  };
}

export default function TestDetail() {
  const { id } = useParams<{ id: string }>();
  const [test, setTest] = useState<Test | null>(null);
  const [result, setResult] = useState<TestResult | null>(null);
  const [agentResults, setAgentResults] = useState<AgentResult[]>([]);
  const [metrics, setMetrics] = useState<TestMetric[]>([]);
  const [rawMetrics, setRawMetrics] = useState<TestMetric[]>([]); // Raw metrics with labels
  const [transactions, setTransactions] = useState<any[]>([]);
  const [logs, setLogs] = useState<TestLog[]>([]);
  const [responseCodes, setResponseCodes] = useState<Record<string, number>>({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const [sortConfig, setSortConfig] = useState<{key: string, direction: 'asc' | 'desc'}>({key: 'label', direction: 'asc'});
  const [filterAnchorEl, setFilterAnchorEl] = useState<null | HTMLElement>(null);
  const [searchText, setSearchText] = useState<string>('');
  const [currentTime, setCurrentTime] = useState(Date.now());
  const [refreshInterval, setRefreshInterval] = useState<number>(5000); // Default 5 seconds
  const [timeRange, setTimeRange] = useState<[number, number]>([0, 100]); // Percentage range
  const [enableTimeFilter, setEnableTimeFilter] = useState(false);
  const [activeTab, setActiveTab] = useState<string>('metrics');
  
  // Label metrics states
  const [availableLabels, setAvailableLabels] = useState<string[]>([]);
  const [selectedLabels, setSelectedLabels] = useState<string[]>([]);
  const [labelSearchText, setLabelSearchText] = useState('');
  
  // Host metrics visibility state
  const [hiddenHostMetrics, setHiddenHostMetrics] = useState<Set<string>>(new Set());
  const [labelMetrics, setLabelMetrics] = useState<any>(null);
  const [timeGranularity, setTimeGranularity] = useState('auto');
  const [loadingLabels, setLoadingLabels] = useState(false);
  const [loadingLabelMetrics, setLoadingLabelMetrics] = useState(false);
  
  // Host metrics states
  const [hostMetrics, setHostMetrics] = useState<any[]>([]);
  const [loadingHostMetrics, setLoadingHostMetrics] = useState(false);

  useEffect(() => {
    if (id) {
      loadTest();
      loadMetrics();
      loadTransactions();
      loadLogs();
      loadResponseCodes();
      
      // Set up WebSocket listener for real-time metrics
      const socket = wsClient.getSocket();
      if (socket) {
        socket.emit('subscribe:test', id);
        
        // Listen for real-time metrics updates
        socket.on('metrics', (metricsData: any) => {
          console.log('Received metrics via WebSocket:', metricsData);
          setMetrics(prev => [...prev, metricsData]);
          
          // Update transactions if provided
          if (metricsData.transactions && metricsData.transactions.length > 0) {
            console.log('Updating transactions:', metricsData.transactions);
            setTransactions(metricsData.transactions);
          }
        });
        
        // Listen for status updates
        socket.on('test:completed', (data: any) => {
          if (data.testId === id) {
            loadTest();
            loadMetrics();
            loadResponseCodes();
            loadLabels();
          }
        });
        
        socket.on('test:stopped', (data: any) => {
          if (data.testId === id) {
            loadTest();
          }
        });
      }
      
      return () => {
        // Clean up socket listeners
        const socket = wsClient.getSocket();
        if (socket) {
          socket.emit('unsubscribe:test', id);
          socket.off('metrics');
          socket.off('test:completed');
          socket.off('test:stopped');
        }
      };
    }
  }, [id]);

  useEffect(() => {
    if (test?.status === 'running' && refreshInterval > 0) {
      // Poll for test status and transactions based on selected interval
      const interval = setInterval(() => {
        loadTest(); // Refresh test status
        loadTransactions(); // Refresh transactions to ensure they're up-to-date
        loadMetrics(); // Refresh metrics
      }, refreshInterval);
      return () => clearInterval(interval);
    }
  }, [test?.status, refreshInterval]);

  // Update current time every second for progress calculation
  useEffect(() => {
    if (test?.status === 'running') {
      const interval = setInterval(() => {
        setCurrentTime(Date.now());
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [test?.status]);

  // Load labels when test is completed
  useEffect(() => {
    if (test?.status === 'completed') {
      loadLabels();
      loadHostMetrics(); // Load host metrics for completed tests
    }
  }, [test?.status]);
  
  // Load host metrics during running tests
  useEffect(() => {
    if (test?.status === 'running') {
      loadHostMetrics(); // Initial load
      const interval = setInterval(() => {
        loadHostMetrics(); // Poll every 10 seconds
      }, 10000);
      return () => clearInterval(interval);
    } else if (test?.status === 'cancelled') {
      loadHostMetrics(); // Load for cancelled tests too
    }
  }, [test?.status]);

  // Load label metrics when selection or granularity changes
  useEffect(() => {
    if (selectedLabels.length > 0) {
      loadLabelMetrics();
    }
  }, [selectedLabels, timeGranularity]);

  // Calculate progress
  const calculateProgress = () => {
    if (!test?.startedAt || test.status !== 'running') return 0;
    const elapsed = (currentTime - new Date(test.startedAt).getTime()) / 1000;
    const progress = (elapsed / test.duration) * 100;
    return Math.min(progress, 100);
  };

  const getTimeRemaining = () => {
    if (!test?.startedAt || test.status !== 'running') return '0:00';
    const elapsed = (currentTime - new Date(test.startedAt).getTime()) / 1000;
    const remaining = Math.max(0, test.duration - elapsed);
    const minutes = Math.floor(remaining / 60);
    const seconds = Math.floor(remaining % 60);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  const getLatestMetric = (key: string) => {
    if (metrics.length === 0) return '0';
    const latest = metrics[metrics.length - 1];
    if (key === 'responseTime') return latest.responseTime.toFixed(2);
    if (key === 'throughput') return latest.throughput.toFixed(2);
    if (key === 'errorRate') return latest.errorRate.toFixed(2);
    if (key === 'activeThreads') return latest.activeThreads.toString();
    return '0';
  };

  const loadTest = async () => {
    try {
      setLoading(true);
      const data = await api.getTest(id!);
      setTest(data);
      
      // Load aggregate results for any non-running terminal state
      if (data.status !== 'pending' && data.status !== 'running') {
        try {
          const resultData = await api.getTestResults(id!);
          setResult(resultData);
          
          // Load per-agent results
          loadAgentResults();
        } catch (err) {
          console.error('Failed to load test results:', err);
          setResult(null);
        }
      } else {
        setResult(null);
        setAgentResults([]);
      }
      
      setError(''); // Clear any previous errors on successful load
    } catch (err: any) {
      setError(err.response?.data?.error || 'Failed to load test');
    } finally {
      setLoading(false);
    }
  };

  const loadAgentResults = async () => {
    try {
      const data = await api.get(`/tests/${id}/agent-results`);
      setAgentResults(data);
    } catch (err: any) {
      console.error('Failed to load agent results:', err);
    }
  };

  const loadMetrics = async () => {
    try {
      const data = await api.getTestMetrics(id!);
      // Handle both old format (array) and new format (object with aggregated and raw)
      if (data && typeof data === 'object' && 'aggregated' in data) {
        setMetrics(data.aggregated || []);
        setRawMetrics(data.raw || []);
      } else if (Array.isArray(data)) {
        setMetrics(data);
        setRawMetrics([]);
      } else {
        setMetrics([]);
        setRawMetrics([]);
      }
    } catch (err: any) {
      console.error('Failed to load metrics:', err);
    }
  };

  const loadTransactions = async () => {
    try {
      const data = await api.getTestTransactions(id!);
      console.log('Loaded transactions from API:', data);
      setTransactions(data);
    } catch (err: any) {
      console.error('Failed to load transactions:', err);
    }
  };

  const loadLogs = async () => {
    try {
      const data = await api.getTestLogs(id!);
      setLogs(data);
    } catch (err: any) {
      console.error('Failed to load logs:', err);
    }
  };

  const loadResponseCodes = async () => {
    try {
      const data = await api.getTestResponseCodes(id!);
      setResponseCodes(data);
    } catch (err: any) {
      // Silently ignore if JTL file doesn't exist
      if (err.response?.status !== 404) {
        console.error('Failed to load response codes:', err);
      }
    }
  };

  const loadLabels = async () => {
    if (!id) return;
    setLoadingLabels(true);
    try {
      const labels = await api.getTestLabels(id);
      setAvailableLabels(labels);
      
      // Auto-select all labels for completed tests to show graph immediately
      if (test?.status === 'completed' && labels.length > 0) {
        setSelectedLabels(labels);
      }
    } catch (err: any) {
      // Silently ignore if JTL file doesn't exist
      if (err.response?.status !== 404) {
        console.error('Failed to load labels:', err);
      }
    } finally {
      setLoadingLabels(false);
    }
  };

  const loadLabelMetrics = async () => {
    if (!id || selectedLabels.length === 0) {
      setLabelMetrics(null);
      return;
    }
    setLoadingLabelMetrics(true);
    try {
      // Check if all labels are selected
      const selectAll = selectedLabels.length === availableLabels.length;
      // Use 30s granularity when all labels are selected, unless user manually changed it
      const effectiveGranularity = selectAll && timeGranularity === 'auto' ? '30s' : timeGranularity;
      
      const data = await api.getTestLabelMetrics(id, selectedLabels, effectiveGranularity, selectAll);
      setLabelMetrics(data);
    } catch (err: any) {
      console.error('Failed to load label metrics:', err);
      setLabelMetrics(null);
    } finally {
      setLoadingLabelMetrics(false);
    }
  };

  const loadHostMetrics = async () => {
    if (!id) return;
    setLoadingHostMetrics(true);
    try {
      const data = await api.getTestHostMetrics(id);
      setHostMetrics(data);
    } catch (err: any) {
      console.error('Failed to load host metrics:', err);
      setHostMetrics([]);
    } finally {
      setLoadingHostMetrics(false);
    }
  };

  const handleStart = async () => {
    try {
      // Start without per-test overrides from this view; tests created
      // with per-run thread-group overrides will already have them
      // associated at start time from the ProjectDetail page.
      await api.startTest(id!);
      loadTest();
    } catch (err: any) {
      setError(err.response?.data?.error || 'Failed to start test');
    }
  };

  const handleStop = async () => {
    try {
      await api.stopTest(id!);
      loadTest();
    } catch (err: any) {
      setError(err.response?.data?.error || 'Failed to stop test');
    }
  };

  const handleExport = async (format: 'csv' | 'json', type: 'summary' | 'detailed' | 'metrics') => {
    try {
      const blob = await api.exportResults(id!, format, type);
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `test-${id}-${type}.${format}`;
      a.click();
      setAnchorEl(null);
    } catch (err: any) {
      setError(err.response?.data?.error || 'Failed to export results');
    }
  };

  const handleDownloadJtl = async () => {
    try {
      const blob = await api.downloadJtlFile(id!);
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `test-${id}-results.jtl`;
      a.click();
      setAnchorEl(null);
    } catch (err: any) {
      setError(err.response?.data?.error || 'Failed to download JTL file');
    }
  };

  const handleDownloadScript = async () => {
    try {
      const scriptId = (test as any)?.script?.id;
      if (!scriptId) {
        setError('Script download is not available for this test');
        return;
      }
      const fileName = `${test.script.name || 'script'}.zip`;
      await api.downloadScriptZip(scriptId, fileName);
      setAnchorEl(null);
    } catch (err: any) {
      setError(err.response?.data?.error || 'Failed to download script bundle');
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'running': return 'info';
      case 'completed': return 'success';
      case 'collating': return 'info';
      case 'failed': return 'error';
      case 'stopped': return 'warning';
      default: return 'default';
    }
  };

  const formatMetricsForChart = () => {
    let filteredMetrics = metrics;
    
    // Apply time window filter for completed tests
    if (enableTimeFilter && test?.status === 'completed' && test?.startedAt && test?.completedAt) {
      const startTime = new Date(test.startedAt).getTime();
      const endTime = new Date(test.completedAt).getTime();
      const duration = endTime - startTime;
      
      const filterStartTime = startTime + (duration * timeRange[0] / 100);
      const filterEndTime = startTime + (duration * timeRange[1] / 100);
      
      filteredMetrics = metrics.filter(m => {
        const metricTime = new Date(m.timestamp).getTime();
        return metricTime >= filterStartTime && metricTime <= filterEndTime;
      });
    }
    
    return filteredMetrics.map(m => ({
      time: new Date(m.timestamp).toLocaleTimeString(),
      'Response Time (ms)': m.responseTime,
      'Throughput (req/s)': m.throughput,
      'Error Rate (%)': m.errorRate,
      'Active Threads': m.activeThreads,
    }));
  };

  const getFilteredTransactions = () => {
    // If time filter is not enabled or test is not completed, return original transactions
    if (!enableTimeFilter || test?.status !== 'completed' || !test?.startedAt || !test?.completedAt) {
      return transactions;
    }

    // If no raw metrics available, return original transactions
    if (!rawMetrics || rawMetrics.length === 0) {
      return transactions;
    }

    // Calculate filtered time range
    const startTime = new Date(test.startedAt).getTime();
    const endTime = new Date(test.completedAt).getTime();
    const duration = endTime - startTime;
    
    const filterStartTime = startTime + (duration * timeRange[0] / 100);
    const filterEndTime = startTime + (duration * timeRange[1] / 100);
    
    // Filter raw metrics by time window
    const filteredMetrics = rawMetrics.filter(m => {
      const metricTime = new Date(m.timestamp).getTime();
      return metricTime >= filterStartTime && metricTime <= filterEndTime;
    });

    // Recalculate transaction statistics from filtered metrics
    const labelStats = new Map<string, {
      samples: number[];
      pass: number;
      fail: number;
    }>();

    filteredMetrics.forEach(metric => {
      if (metric.label && metric.label !== 'aggregate') {
        if (!labelStats.has(metric.label)) {
          labelStats.set(metric.label, {
            samples: [],
            pass: 0,
            fail: 0
          });
        }
        
        const stats = labelStats.get(metric.label)!;
        stats.samples.push(metric.responseTime);
        
        if (metric.success !== undefined) {
          if (metric.success) {
            stats.pass++;
          } else {
            stats.fail++;
          }
        }
      }
    });

    // Build transaction array from filtered data
    const filteredTransactions = Array.from(labelStats.entries()).map(([label, stats]) => {
      const sorted = [...stats.samples].sort((a, b) => a - b);
      const count = sorted.length;
      
      if (count === 0) return null;
      
      const avg = sorted.reduce((a, b) => a + b, 0) / count;
      const min = sorted[0];
      const max = sorted[count - 1];
      const p90Index = Math.floor(count * 0.9);
      const p90 = sorted[p90Index] || sorted[count - 1];
      const errorRate = count > 0 ? (stats.fail / count) * 100 : 0;
      
      return {
        label,
        avg: Math.round(avg * 100) / 100,
        min,
        max,
        p90,
        pass: stats.pass,
        fail: stats.fail,
        errorRate: Math.round(errorRate * 100) / 100
      };
    }).filter(t => t !== null);

    return filteredTransactions.length > 0 ? filteredTransactions : transactions;
  };

  if (loading) {
    return (
      <Container maxWidth={false} sx={{ mt: 4, mb: 4, textAlign: 'center' }}>
        <CircularProgress />
      </Container>
    );
  }

  if (!test) {
    return (
      <Container maxWidth={false} sx={{ mt: 4, mb: 4 }}>
        {error && (
          <Alert severity="error" onClose={() => setError('')}>
            {error}
          </Alert>
        )}
      </Container>
    );
  }

  const getResponseCodeMessage = (code: string): string => {
    const messages: Record<string, string> = {
      '200': 'OK',
      '201': 'Created',
      '202': 'Accepted',
      '204': 'No Content',
      '301': 'Moved Permanently',
      '302': 'Found',
      '303': 'See Other',
      '304': 'Not Modified',
      '307': 'Temporary Redirect',
      '308': 'Permanent Redirect',
      '400': 'Bad Request',
      '401': 'Unauthorized',
      '403': 'Forbidden',
      '404': 'Not Found',
      '405': 'Method Not Allowed',
      '408': 'Request Timeout',
      '409': 'Conflict',
      '429': 'Too Many Requests',
      '500': 'Internal Server Error',
      '502': 'Bad Gateway',
      '503': 'Service Unavailable',
      '504': 'Gateway Timeout'
    };
    return messages[code] || 'Unknown';
  };

  const chartData = formatMetricsForChart();

  const hasTabs = test.status !== 'pending';

  // Derive an error rate value for the summary card (prefer aggregated result, otherwise latest metric)
  const getSummaryErrorRate = () => {
    if (result && typeof result.errorRate === 'number') {
      return result.errorRate;
    }
    if (metrics.length > 0) {
      const latest = metrics[metrics.length - 1];
      return typeof latest.errorRate === 'number' ? latest.errorRate : 0;
    }
    return 0;
  };

  return (
    <Box sx={{ display: 'flex', mt: 4, mb: 4, width: '100%', overflowX: 'hidden' }}>
      {/* Main Content */}
      <Container maxWidth="xl" sx={{ flexGrow: 1, px: { xs: 2, md: 3 }, minWidth: 0 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Box>
          <Typography variant="h4">{test.name}</Typography>
          <Typography color="text.secondary">
            {test.project.name} / {test.script.name}
          </Typography>
        </Box>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
          {test.status === 'running' && (
            <FormControl size="small" sx={{ minWidth: 180 }}>
              <InputLabel>Auto Refresh</InputLabel>
              <Select
                value={refreshInterval}
                label="Auto Refresh"
                onChange={(e) => setRefreshInterval(Number(e.target.value))}
                startAdornment={<RefreshIcon sx={{ ml: 1, mr: -0.5, fontSize: 20, color: 'action.active' }} />}
              >
                <MenuItem value={5000}>5 seconds</MenuItem>
                <MenuItem value={10000}>10 seconds</MenuItem>
                <MenuItem value={30000}>30 seconds</MenuItem>
                <MenuItem value={60000}>1 minute</MenuItem>
                <MenuItem value={300000}>5 minutes</MenuItem>
                <MenuItem value={900000}>15 minutes</MenuItem>
                <MenuItem value={0}>Never</MenuItem>
              </Select>
            </FormControl>
          )}
          <Box>
          {test.status === 'pending' && (
            <Button
              variant="contained"
              startIcon={<PlayArrowIcon />}
              onClick={handleStart}
              sx={{ mr: 1 }}
            >
              Start Test
            </Button>
          )}
          {test.status === 'running' && (
            <Button
              variant="contained"
              color="error"
              startIcon={<StopIcon />}
              onClick={handleStop}
              sx={{ mr: 1 }}
            >
              Stop Test
            </Button>
          )}
          </Box>
        </Box>
      </Box>

      {/* Collating Status Banner */}
      {test.status === 'collating' && (
        <Alert severity="info" sx={{ mb: 3 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
            <CircularProgress size={20} />
            <Typography>
              <strong>Collating Results:</strong> All agents have completed. Merging JTL files into a single combined result file. This may take a few minutes for large result sets.
            </Typography>
          </Box>
        </Alert>
      )}

      {/* Status Summary - Only show for completed, failed, or cancelled tests */}
      {(test.status === 'completed' || test.status === 'failed' || test.status === 'cancelled') && (
        <Box id="summary" sx={{ mb: 3, scrollMarginTop: 80 }}>
          <Typography variant="h6" gutterBottom sx={{ fontWeight: 'bold', mb: 2 }}>
            Status Summary
          </Typography>
          <Grid container spacing={3} sx={{ mb: 3 }}>
        <Grid item xs={12} sm={6} md={2.4}>
          <Card sx={{ 
            background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
            color: 'white',
            height: '100%'
          }}>
            <CardContent sx={{ textAlign: 'center' }}>
              <Typography variant="caption" sx={{ opacity: 0.9, fontWeight: 'bold', fontSize: '0.875rem' }}>Status</Typography>
              <Box sx={{ mt: 1 }}>
                <Chip 
                  label={test.status.toUpperCase()} 
                  sx={{ 
                    bgcolor: 'rgba(255,255,255,0.2)',
                    color: 'white',
                    fontWeight: 'bold'
                  }} 
                />
              </Box>
            </CardContent>
          </Card>
        </Grid>
        
        <Grid item xs={12} sm={6} md={2.4}>
          <Card sx={{ 
            background: 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)',
            color: 'white',
            height: '100%'
          }}>
            <CardContent sx={{ textAlign: 'center' }}>
              <Typography variant="caption" sx={{ opacity: 0.9, fontWeight: 'bold', fontSize: '0.875rem' }}>Threads</Typography>
              <Typography variant="h4" sx={{ mt: 1, fontWeight: 'bold' }}>
                {test.threads}
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        
        <Grid item xs={12} sm={6} md={2.4}>
          <Card sx={{ 
            background: 'linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)',
            color: 'white',
            height: '100%'
          }}>
            <CardContent sx={{ textAlign: 'center' }}>
              <Typography variant="caption" sx={{ opacity: 0.9, fontWeight: 'bold', fontSize: '0.875rem' }}>Duration</Typography>
              <Typography variant="h4" sx={{ mt: 1, fontWeight: 'bold' }}>
                {test.duration}<Typography component="span" variant="h6">s</Typography>
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        
        <Grid item xs={12} sm={6} md={2.4}>
          <Card sx={{ 
            background: 'linear-gradient(135deg, #43e97b 0%, #38f9d7 100%)',
            color: 'white',
            height: '100%'
          }}>
            <CardContent sx={{ textAlign: 'center' }}>
              <Typography variant="caption" sx={{ opacity: 0.9, fontWeight: 'bold', fontSize: '0.875rem' }}>Ramp-up</Typography>
              <Typography variant="h4" sx={{ mt: 1, fontWeight: 'bold' }}>
                {test.rampUp}<Typography component="span" variant="h6">s</Typography>
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        
        {(() => {
          const errorRate = getSummaryErrorRate();
          return (
            <Grid item xs={12} sm={6} md={2.4}>
              <Card sx={{ 
                background: errorRate > 5 
                  ? 'linear-gradient(135deg, #fa709a 0%, #fee140 100%)'
                  : errorRate > 0 
                  ? 'linear-gradient(135deg, #ffa751 0%, #ffe259 100%)'
                  : 'linear-gradient(135deg, #0ba360 0%, #3cba92 100%)',
                color: 'white',
                height: '100%'
              }}>
                <CardContent sx={{ textAlign: 'center' }}>
                  <Typography variant="caption" sx={{ opacity: 0.9, fontWeight: 'bold', fontSize: '0.875rem' }}>Error Rate</Typography>
                  <Typography variant="h4" sx={{ mt: 1, fontWeight: 'bold' }}>
                    {errorRate.toFixed(2)}<Typography component="span" variant="h6">%</Typography>
                  </Typography>
                </CardContent>
              </Card>
            </Grid>
          );
        })()}
      </Grid>
        </Box>
      )}
      
      {test.startedAt && (
        <Box sx={{ mb: 3 }}>
          <Typography variant="caption" color="text.secondary">
            Started: {new Date(test.startedAt).toLocaleString()}
            {test.completedAt && ` • Completed: ${new Date(test.completedAt).toLocaleString()}`}
          </Typography>
        </Box>
      )}

      {/* Time Window Filter - shared for completed tests with metrics */}
      {test.status === 'completed' && metrics.length > 0 && test.startedAt && test.completedAt && (
        <Card sx={{ mb: 3 }}>
          <CardContent>
            <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 2 }}>
              <Box sx={{ display: 'flex', alignItems: 'center' }}>
                <AccessTimeIcon sx={{ mr: 1, color: 'primary.main' }} />
                <Typography variant="h6" gutterBottom sx={{ fontWeight: 'bold', mb: 2 }}>Time Window Filter</Typography>
              </Box>
              <Button
                size="small"
                variant={enableTimeFilter ? 'contained' : 'outlined'}
                onClick={() => {
                  setEnableTimeFilter(!enableTimeFilter);
                  if (enableTimeFilter) {
                    setTimeRange([0, 100]); // Reset to full range
                  }
                }}
              >
                {enableTimeFilter ? 'Disable Filter' : 'Enable Filter'}
              </Button>
            </Box>
            {enableTimeFilter && (
              <Box sx={{ px: 2 }}>
                <Typography variant="body2" color="text.secondary" gutterBottom>
                  Select time window to analyze specific test phases:
                </Typography>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mt: 2 }}>
                  <Typography variant="caption" sx={{ minWidth: 80 }}>
                    {(() => {
                      const startTime = new Date(test.startedAt).getTime();
                      const endTime = new Date(test.completedAt).getTime();
                      const duration = endTime - startTime;
                      const windowStart = new Date(startTime + (duration * timeRange[0] / 100));
                      return windowStart.toLocaleTimeString();
                    })()}
                  </Typography>
                  <Slider
                    value={timeRange}
                    onChange={(_, newValue) => setTimeRange(newValue as [number, number])}
                    valueLabelDisplay="auto"
                    valueLabelFormat={(value) => `${value}%`}
                    min={0}
                    max={100}
                    sx={{ flex: 1 }}
                  />
                  <Typography variant="caption" sx={{ minWidth: 80, textAlign: 'right' }}>
                    {(() => {
                      const startTime = new Date(test.startedAt).getTime();
                      const endTime = new Date(test.completedAt).getTime();
                      const duration = endTime - startTime;
                      const windowEnd = new Date(startTime + (duration * timeRange[1] / 100));
                      return windowEnd.toLocaleTimeString();
                    })()}
                  </Typography>
                </Box>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 1 }}>
                  <Typography variant="caption" color="text.secondary">
                    Window: {timeRange[0]}% - {timeRange[1]}%
                  </Typography>
                  <Typography variant="caption" color="text.secondary">
                    Duration: {(() => {
                      const startTime = new Date(test.startedAt).getTime();
                      const endTime = new Date(test.completedAt).getTime();
                      const duration = endTime - startTime;
                      const windowDuration = (duration * (timeRange[1] - timeRange[0]) / 100) / 1000;
                      return `${Math.floor(windowDuration / 60)}m ${Math.floor(windowDuration % 60)}s`;
                    })()}
                  </Typography>
                </Box>
                <Box sx={{ display: 'flex', gap: 1, mt: 2, flexWrap: 'wrap' }}>
                  <Button size="small" variant="outlined" onClick={() => setTimeRange([0, 25])}>
                    First 25%
                  </Button>
                  <Button size="small" variant="outlined" onClick={() => setTimeRange([25, 75])}>
                    Middle 50%
                  </Button>
                  <Button size="small" variant="outlined" onClick={() => setTimeRange([75, 100])}>
                    Last 25%
                  </Button>
                  <Button size="small" variant="outlined" onClick={() => setTimeRange([0, 100])}>
                    Full Test
                  </Button>
                </Box>
              </Box>
            )}
          </CardContent>
        </Card>
      )}

      {/* Tabs for test analysis sections (all non-pending statuses) */}
      {hasTabs && (
        <Box sx={{ borderBottom: 1, borderColor: 'divider', mb: 3 }}>
          <Tabs
            value={activeTab}
            onChange={(_, value) => setActiveTab(value)}
            variant="scrollable"
            scrollButtons="auto"
            aria-label="Test result sections"
          >
            <Tab value="metrics" label="Performance Metrics" />
            <Tab value="response-codes" label="Response Codes" />
            <Tab value="transaction-stats" label="Transaction Statistics" />
            <Tab value="transaction-timeline" label="Transaction Timeline" />
            <Tab value="agent-breakdown" label="Execution Logs" />
            <Tab value="host-metrics" label="Host Metrics" />
          </Tabs>
        </Box>
      )}

      {/* Per-Agent Results Breakdown - Only for completed multi-agent tests (tabbed) */}
      {test.status === 'completed' && agentResults.length > 1 && activeTab === 'agent-breakdown' && (
        <Card id="agent-breakdown" sx={{ mb: 3, scrollMarginTop: 80 }}>
          <CardContent>
            <Typography variant="h6" gutterBottom sx={{ fontWeight: 'bold', mb: 2 }}>
              Load Distribution Across Agents
            </Typography>
            <TableContainer>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell sx={{ fontWeight: 'bold' }}>Agent</TableCell>
                    <TableCell sx={{ fontWeight: 'bold' }}>Location</TableCell>
                    <TableCell align="right" sx={{ fontWeight: 'bold' }}>Threads</TableCell>
                    <TableCell align="right" sx={{ fontWeight: 'bold' }}>Samples</TableCell>
                    <TableCell align="right" sx={{ fontWeight: 'bold' }}>Avg Response (ms)</TableCell>
                    <TableCell align="right" sx={{ fontWeight: 'bold' }}>Throughput</TableCell>
                    <TableCell align="right" sx={{ fontWeight: 'bold' }}>Error Rate</TableCell>
                    <TableCell align="right" sx={{ fontWeight: 'bold' }}>Status</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {agentResults.map((agentResult) => (
                    <TableRow key={agentResult.id} hover>
                      <TableCell>
                        <Box sx={{ display: 'flex', alignItems: 'center' }}>
                          <ComputerIcon sx={{ mr: 1, color: 'primary.main' }} />
                          <Typography variant="body2" sx={{ fontWeight: 'bold' }}>
                            {agentResult.agent.name}
                          </Typography>
                        </Box>
                      </TableCell>
                      <TableCell>
                        <Chip 
                          label={agentResult.agent.location} 
                          size="small" 
                          variant="outlined"
                        />
                      </TableCell>
                      <TableCell align="right">
                        <Typography variant="body2" sx={{ fontWeight: 'bold' }}>
                          {agentResult.threads}
                        </Typography>
                      </TableCell>
                      <TableCell align="right">
                        <Typography variant="body2">
                          {agentResult.totalSamples?.toLocaleString() || 'N/A'}
                        </Typography>
                      </TableCell>
                      <TableCell align="right">
                        <Typography variant="body2">
                          {agentResult.avgResponseTime?.toFixed(2) || 'N/A'}
                        </Typography>
                      </TableCell>
                      <TableCell align="right">
                        <Typography variant="body2">
                          {agentResult.throughput?.toFixed(2) || 'N/A'} req/s
                        </Typography>
                      </TableCell>
                      <TableCell align="right">
                        <Chip
                          label={`${agentResult.errorRate?.toFixed(2) || 0}%`}
                          size="small"
                          color={(agentResult.errorRate || 0) > 5 ? 'error' : (agentResult.errorRate || 0) > 0 ? 'warning' : 'success'}
                          sx={{ minWidth: '60px' }}
                        />
                      </TableCell>
                      <TableCell align="right">
                        <Chip
                          label={agentResult.status.toUpperCase()}
                          size="small"
                          color={agentResult.status === 'completed' ? 'success' : 'default'}
                          sx={{ minWidth: '80px' }}
                        />
                      </TableCell>
                    </TableRow>
                  ))}
                  {/* Aggregated Total Row */}
                  {result && (
                    <TableRow sx={{ bgcolor: 'action.hover' }}>
                      <TableCell colSpan={3} sx={{ fontWeight: 'bold' }}>
                        TOTAL (Aggregated)
                      </TableCell>
                      <TableCell align="right" sx={{ fontWeight: 'bold' }}>
                        {result.totalSamples.toLocaleString()}
                      </TableCell>
                      <TableCell align="right" sx={{ fontWeight: 'bold' }}>
                        {result.avgResponseTime.toFixed(2)}
                      </TableCell>
                      <TableCell align="right" sx={{ fontWeight: 'bold' }}>
                        {result.throughput.toFixed(2)} req/s
                      </TableCell>
                      <TableCell align="right" sx={{ fontWeight: 'bold' }}>
                        <Chip
                          label={`${result.errorRate.toFixed(2)}%`}
                          size="small"
                          color={result.errorRate > 5 ? 'error' : result.errorRate > 0 ? 'warning' : 'success'}
                          sx={{ minWidth: '60px', fontWeight: 'bold' }}
                        />
                      </TableCell>
                      <TableCell align="right">
                        <Chip
                          label="COMBINED"
                          size="small"
                          color="primary"
                          sx={{ minWidth: '80px', fontWeight: 'bold' }}
                        />
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </TableContainer>
            <Alert severity="info" sx={{ mt: 2 }}>
              <Typography variant="body2">
                <strong>Load was distributed across {agentResults.length} agents.</strong> Each agent executed {agentResults[0]?.threads} threads independently. 
                The aggregated metrics above represent the combined results from all agents.
              </Typography>
            </Alert>
          </CardContent>
        </Card>
      )}

      {/* Live Progress Bar (when running) */}
      {test.status === 'running' && (
        <Card sx={{ mb: 3, background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)' }}>
          <CardContent>
            <Box sx={{ display: 'flex', alignItems: 'center', mb: 2, color: 'white' }}>
              <TimerIcon sx={{ mr: 1 }} />
              <Typography variant="h6">Test in Progress</Typography>
              <Chip 
                label="LIVE" 
                size="small" 
                sx={{ ml: 2, bgcolor: '#ff3d00', color: 'white', animation: 'pulse 2s infinite' }} 
              />
              {(test as any).testAgents && (test as any).testAgents.length > 1 && (
                <Chip 
                  label={`${(test as any).testAgents.length} AGENTS`} 
                  size="small" 
                  icon={<ComputerIcon />}
                  sx={{ ml: 1, bgcolor: 'rgba(255,255,255,0.2)', color: 'white' }} 
                />
              )}
              <Box sx={{ flexGrow: 1 }} />
              <Typography variant="h5" sx={{ fontWeight: 'bold' }}>
                {getTimeRemaining()}
              </Typography>
            </Box>
            <LinearProgress 
              variant="determinate" 
              value={calculateProgress()} 
              sx={{ 
                height: 10, 
                borderRadius: 5,
                backgroundColor: 'rgba(255,255,255,0.3)',
                '& .MuiLinearProgress-bar': {
                  backgroundColor: '#4caf50',
                  borderRadius: 5,
                }
              }} 
            />
            <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 1, color: 'white' }}>
              <Typography variant="caption">
                {calculateProgress().toFixed(1)}% Complete
              </Typography>
              <Typography variant="caption">
                Elapsed: {Math.floor((currentTime - new Date(test.startedAt).getTime()) / 1000)}s / {test.duration}s
              </Typography>
            </Box>
          </CardContent>
        </Card>
      )}

      {/* Live Metrics Cards (when running) */}
      {test.status === 'running' && metrics.length > 0 && (
        <>
          {(test as any).testAgents && (test as any).testAgents.length > 1 && (
            <Alert severity="info" sx={{ mb: 2 }} icon={<ComputerIcon />}>
              <Typography variant="body2">
                <strong>Multi-Agent Load Test:</strong> Metrics displayed below are aggregated in real-time from {(test as any).testAgents.length} agents. 
                Total load: {test.threads} threads distributed as {Math.floor(test.threads / (test as any).testAgents.length)} threads per agent.
              </Typography>
            </Alert>
          )}
          <Grid container spacing={3} sx={{ mb: 3 }}>
          <Grid item xs={12} sm={6} md={3}>
            <Card sx={{ 
              background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)', 
              color: 'white',
              transition: 'transform 0.3s',
              '&:hover': { transform: 'translateY(-4px)' }
            }}>
              <CardContent>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                  <SpeedIcon sx={{ mr: 1 }} />
                  <Typography variant="subtitle2">Response Time</Typography>
                </Box>
                <Typography variant="h4" sx={{ fontWeight: 'bold' }}>
                  {getLatestMetric('responseTime')}
                </Typography>
                <Typography variant="caption">milliseconds (avg)</Typography>
              </CardContent>
            </Card>
          </Grid>

          <Grid item xs={12} sm={6} md={3}>
            <Card sx={{ 
              background: 'linear-gradient(135deg, #4caf50 0%, #45a247 100%)', 
              color: 'white',
              transition: 'transform 0.3s',
              '&:hover': { transform: 'translateY(-4px)' }
            }}>
              <CardContent>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                  <TrendingUpIcon sx={{ mr: 1 }} />
                  <Typography variant="subtitle2">Throughput</Typography>
                </Box>
                <Typography variant="h4" sx={{ fontWeight: 'bold' }}>
                  {getLatestMetric('throughput')}
                </Typography>
                <Typography variant="caption">req/sec (total)</Typography>
              </CardContent>
            </Card>
          </Grid>

          <Grid item xs={12} sm={6} md={3}>
            <Card sx={{ 
              background: parseFloat(getLatestMetric('errorRate')) > 5 
                ? 'linear-gradient(135deg, #f44336 0%, #e91e63 100%)' 
                : 'linear-gradient(135deg, #ff9800 0%, #fb8c00 100%)', 
              color: 'white',
              transition: 'transform 0.3s',
              '&:hover': { transform: 'translateY(-4px)' }
            }}>
              <CardContent>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                  <ErrorIcon sx={{ mr: 1 }} />
                  <Typography variant="subtitle2">Error Rate</Typography>
                </Box>
                <Typography variant="h4" sx={{ fontWeight: 'bold' }}>
                  {getLatestMetric('errorRate')}%
                </Typography>
                <Typography variant="caption">percentage (avg)</Typography>
              </CardContent>
            </Card>
          </Grid>

          <Grid item xs={12} sm={6} md={3}>
            <Card sx={{ 
              background: 'linear-gradient(135deg, #2196f3 0%, #1976d2 100%)', 
              color: 'white',
              transition: 'transform 0.3s',
              '&:hover': { transform: 'translateY(-4px)' }
            }}>
              <CardContent>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                  <ComputerIcon sx={{ mr: 1 }} />
                  <Typography variant="subtitle2">Active Threads</Typography>
                </Box>
                <Typography variant="h4" sx={{ fontWeight: 'bold' }}>
                  {getLatestMetric('activeThreads')}
                </Typography>
                <Typography variant="caption">threads (total)</Typography>
              </CardContent>
            </Card>
          </Grid>
        </Grid>
        </>
      )}

      {/* Response Code Summary - Only for completed tests (tabbed) */}
      {test.status === 'completed' && Object.keys(responseCodes).length > 0 && activeTab === 'response-codes' && (
        <Card id="response-codes" sx={{ mb: 3, scrollMarginTop: 80 }}>
          <CardContent>
            <Typography variant="h6" gutterBottom sx={{ fontWeight: 'bold', mb: 2 }}>Response Code Summary</Typography>
            <TableContainer>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell sx={{ fontWeight: 'bold' }}>Response Code</TableCell>
                    <TableCell sx={{ fontWeight: 'bold' }}>Description</TableCell>
                    <TableCell align="right" sx={{ fontWeight: 'bold' }}>Count</TableCell>
                    <TableCell align="right" sx={{ fontWeight: 'bold' }}>Percentage</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {(() => {
                    const totalRequests = Object.values(responseCodes).reduce((sum, count) => sum + count, 0);
                    const sortedCodes = Object.entries(responseCodes).sort((a, b) => b[1] - a[1]);
                    
                    return sortedCodes.map(([code, count]) => {
                      const percentage = ((count / totalRequests) * 100).toFixed(2);
                      const badgeColor = code.startsWith('2') ? 'success' 
                        : code.startsWith('3') ? 'info'
                        : code.startsWith('4') ? 'warning'
                        : code.startsWith('5') ? 'error'
                        : 'default';
                      
                      return (
                        <TableRow key={code} hover>
                          <TableCell>
                            <Chip 
                              label={code} 
                              color={badgeColor as any}
                              size="small"
                              sx={{ fontWeight: 'bold', minWidth: '60px' }}
                            />
                          </TableCell>
                          <TableCell>
                            <Typography variant="body2">
                              {getResponseCodeMessage(code)}
                            </Typography>
                          </TableCell>
                          <TableCell align="right">
                            <Typography variant="body2" sx={{ fontWeight: 'bold' }}>
                              {count.toLocaleString()}
                            </Typography>
                          </TableCell>
                          <TableCell align="right">
                            <Typography variant="body2" color="text.secondary">
                              {percentage}%
                            </Typography>
                          </TableCell>
                        </TableRow>
                      );
                    });
                  })()}
                </TableBody>
              </Table>
            </TableContainer>
          </CardContent>
        </Card>
      )}

      {/* Label Response Time Chart - Only for completed tests (tabbed) */}
      {test?.status === 'completed' && availableLabels.length > 0 && activeTab === 'transaction-timeline' && (
        <Card id="transaction-timeline" sx={{ mb: 3, scrollMarginTop: 80 }}>
          <CardContent>
            <Typography variant="h6" gutterBottom sx={{ fontWeight: 'bold', mb: 2 }}>
              Transaction Response Time Analysis
            </Typography>
            
            {/* Label Selection */}
            <Box sx={{ mb: 3 }}>
              <TextField
                size="small"
                placeholder="Search transactions..."
                value={labelSearchText}
                onChange={(e) => setLabelSearchText(e.target.value)}
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <SearchIcon />
                    </InputAdornment>
                  ),
                }}
                sx={{ mb: 2, width: '100%', maxWidth: 400 }}
              />
              
              <Box sx={{ display: 'flex', gap: 2, mb: 2, alignItems: 'center' }}>
                <FormControlLabel
                  control={
                    <Checkbox
                      checked={selectedLabels.length === availableLabels.length}
                      indeterminate={selectedLabels.length > 0 && selectedLabels.length < availableLabels.length}
                      onChange={(e) => {
                        if (e.target.checked) {
                          setSelectedLabels([...availableLabels]);
                          setTimeGranularity('30s'); // Auto-set to 30s when selecting all
                        } else {
                          setSelectedLabels([]);
                        }
                      }}
                    />
                  }
                  label={<Typography variant="body2" sx={{ fontWeight: 'bold' }}>Select All</Typography>}
                />
                
                <Divider orientation="vertical" flexItem />
                
                <FormControl size="small" sx={{ minWidth: 150 }}>
                  <InputLabel>Time Granularity</InputLabel>
                  <Select
                    value={timeGranularity}
                    label="Time Granularity"
                    onChange={(e) => setTimeGranularity(e.target.value)}
                  >
                    <MenuItem value="auto">Auto</MenuItem>
                    <MenuItem value="1s">1 second</MenuItem>
                    <MenuItem value="10s">10 seconds</MenuItem>
                    <MenuItem value="30s">30 seconds</MenuItem>
                    <MenuItem value="1min">1 minute</MenuItem>
                    <MenuItem value="5min">5 minutes</MenuItem>
                    <MenuItem value="10min">10 minutes</MenuItem>
                    <MenuItem value="20min">20 minutes</MenuItem>
                    <MenuItem value="30min">30 minutes</MenuItem>
                    <MenuItem value="1hr">1 hour</MenuItem>
                  </Select>
                </FormControl>
                
                {selectedLabels.length > 0 && (
                  <Chip 
                    label={`${selectedLabels.length} selected`} 
                    color="primary" 
                    size="small" 
                  />
                )}
              </Box>
              
              <Paper variant="outlined" sx={{ maxHeight: 250, overflow: 'auto', p: 2 }}>
                <FormGroup>
                  {availableLabels
                    .filter(label => label.toLowerCase().includes(labelSearchText.toLowerCase()))
                    .map(label => (
                      <FormControlLabel
                        key={label}
                        control={
                          <Checkbox
                            checked={selectedLabels.includes(label)}
                            onChange={(e) => {
                              if (e.target.checked) {
                                setSelectedLabels([...selectedLabels, label]);
                              } else {
                                setSelectedLabels(selectedLabels.filter(l => l !== label));
                              }
                            }}
                          />
                        }
                        label={<Typography variant="body2">{label}</Typography>}
                      />
                    ))}
                </FormGroup>
              </Paper>
            </Box>
            
            {/* Chart */}
            {loadingLabelMetrics ? (
              <Box sx={{ display: 'flex', justifyContent: 'center', p: 4 }}>
                <CircularProgress />
              </Box>
            ) : labelMetrics && selectedLabels.length > 0 ? (
              <Box>
                <Box sx={{ mb: 2, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <Typography variant="body2" color="text.secondary">
                    Showing average response time over time
                  </Typography>
                  {labelMetrics.granularity && (
                    <Chip 
                      label={`Granularity: ${labelMetrics.granularity}`} 
                      size="small" 
                      variant="outlined"
                    />
                  )}
                </Box>
                <ResponsiveContainer width="100%" height={selectedLabels.length > 5 ? 500 : 400}>
                  <LineChart
                    data={labelMetrics.timestamps.map((timestamp: string, index: number) => {
                      const dataPoint: any = { time: new Date(timestamp).toLocaleTimeString() };
                      selectedLabels.forEach(label => {
                        dataPoint[label] = labelMetrics.series[label]?.[index];
                      });
                      return dataPoint;
                    })}
                    margin={{ top: 5, right: 30, left: 20, bottom: 100 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis 
                      dataKey="time" 
                      tick={{ fontSize: 12 }}
                      interval="preserveStartEnd"
                    />
                    <YAxis 
                      label={{ value: 'Response Time (ms)', angle: -90, position: 'insideLeft' }}
                    />
                    <Tooltip />
                    <Legend 
                      verticalAlign="bottom" 
                      height={80}
                      wrapperStyle={{ 
                        paddingTop: '20px',
                        maxHeight: '80px', 
                        overflowY: 'auto',
                        fontSize: '12px'
                      }}
                    />
                    {selectedLabels.map((label, index) => {
                      const colors = ['#8884d8', '#82ca9d', '#ffc658', '#ff7c7c', '#8dd1e1', '#a4de6c', '#d0ed57', '#83a6ed', '#8e4585'];
                      return (
                        <Line
                          key={label}
                          type="monotone"
                          dataKey={label}
                          stroke={colors[index % colors.length]}
                          strokeWidth={2}
                          dot={false}
                          connectNulls
                        />
                      );
                    })}
                  </LineChart>
                </ResponsiveContainer>
              </Box>
            ) : selectedLabels.length > 0 ? (
              <Alert severity="info">No data available for selected transactions</Alert>
            ) : (
              <Alert severity="info">Select one or more transactions to view their response time trend</Alert>
            )}
          </CardContent>
        </Card>
      )}

      {/* Real-time Metrics Charts */}
      {metrics.length > 0 && (
        <>
          {/* Metrics header and charts - tabbed for all non-pending tests */}
          {!hasTabs || activeTab === 'metrics' ? (
            <>
              <Box id="metrics" sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mt: 4, mb: 2, scrollMarginTop: 80 }}>
                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                  <Typography variant="h6" gutterBottom sx={{ fontWeight: 'bold', mb: 2 }}>
                    Performance Metrics
                  </Typography>
                  {test.status === 'running' && (
                    <Chip label="Live" color="error" size="small" sx={{ ml: 2 }} />
                  )}
                  {enableTimeFilter && test.status === 'completed' && (
                    <Chip 
                      label={`Filtered: ${timeRange[0]}% - ${timeRange[1]}%`} 
                      color="primary" 
                      size="small" 
                      sx={{ ml: 2 }} 
                    />
                  )}
                </Box>
              </Box>

              <Card sx={{ mb: 3 }}>
                <CardContent>
                  <Typography variant="subtitle1" gutterBottom>Response Time</Typography>
                  <ResponsiveContainer width="100%" height={300}>
                    <LineChart data={chartData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="time" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Line type="monotone" dataKey="Response Time (ms)" stroke="#8884d8" strokeWidth={2} />
                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card sx={{ mb: 3 }}>
                <CardContent>
                  <Typography variant="subtitle1" gutterBottom>Throughput</Typography>
                  <ResponsiveContainer width="100%" height={300}>
                    <LineChart data={chartData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="time" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Line type="monotone" dataKey="Throughput (req/s)" stroke="#82ca9d" strokeWidth={2} />
                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Grid container spacing={3}>
                <Grid item xs={12} md={6}>
                  <Card>
                    <CardContent>
                      <Typography variant="subtitle1" gutterBottom>Error Rate</Typography>
                      <ResponsiveContainer width="100%" height={250}>
                        <LineChart data={chartData}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="time" />
                          <YAxis />
                          <Tooltip />
                          <Legend />
                          <Line type="monotone" dataKey="Error Rate (%)" stroke="#ff7300" strokeWidth={2} />
                        </LineChart>
                      </ResponsiveContainer>
                    </CardContent>
                  </Card>
                </Grid>
                <Grid item xs={12} md={6}>
                  <Card>
                    <CardContent>
                      <Typography variant="subtitle1" gutterBottom>Active Threads</Typography>
                      <ResponsiveContainer width="100%" height={250}>
                        <LineChart data={chartData}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="time" />
                          <YAxis />
                          <Tooltip />
                          <Legend />
                          <Line type="monotone" dataKey="Active Threads" stroke="#ffc658" strokeWidth={2} />
                        </LineChart>
                      </ResponsiveContainer>
                    </CardContent>
                  </Card>
                </Grid>
              </Grid>
            </>
          ) : null}

          {/* Transaction Table - tabbed for all non-pending tests */}
          {transactions.length > 0 && (!hasTabs || activeTab === 'transaction-stats') ? (
            <Card id="transaction-stats" sx={{ mb: 3, scrollMarginTop: 80 }}>
              <CardContent>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                  <Typography variant="subtitle1">Transaction Statistics</Typography>
                  <TextField
                    size="small"
                    placeholder="Search transactions..."
                    value={searchText}
                    onChange={(e) => setSearchText(e.target.value)}
                    sx={{ width: 300 }}
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position="start">
                          <SearchIcon fontSize="small" />
                        </InputAdornment>
                      ),
                    }}
                  />
                </Box>
                <TableContainer>
                  <Table size="small">
                    <TableHead>
                      <TableRow>
                        <TableCell>
                          <Box 
                            sx={{ display: 'flex', alignItems: 'center', cursor: 'pointer', userSelect: 'none' }}
                            onClick={() => {
                              setSortConfig(prev => ({
                                key: 'label',
                                direction: prev.key === 'label' && prev.direction === 'asc' ? 'desc' : 'asc'
                              }));
                            }}
                          >
                            <strong>Label</strong>
                            {sortConfig.key === 'label' && (
                              sortConfig.direction === 'asc' ? <ArrowUpwardIcon fontSize="small" /> : <ArrowDownwardIcon fontSize="small" />
                            )}
                          </Box>
                        </TableCell>
                        {['avg', 'min', 'max', 'p90', 'pass', 'fail', 'errorRate'].map(field => (
                          <TableCell 
                            key={field}
                            align="right"
                            onClick={() => {
                              setSortConfig(prev => ({
                                key: field,
                                direction: prev.key === field && prev.direction === 'asc' ? 'desc' : 'asc'
                              }));
                            }}
                            sx={{ cursor: 'pointer', userSelect: 'none', '&:hover': { bgcolor: 'action.hover' } }}
                          >
                            <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end' }}>
                              <strong>
                                {field === 'avg' && 'Avg (ms)'}
                                {field === 'min' && 'Min (ms)'}
                                {field === 'max' && 'Max (ms)'}
                                {field === 'p90' && 'P90 (ms)'}
                                {field === 'pass' && 'Pass'}
                                {field === 'fail' && 'Fail'}
                                {field === 'errorRate' && 'Error %'}
                              </strong>
                              {sortConfig.key === field && (
                                sortConfig.direction === 'asc' ? <ArrowUpwardIcon fontSize="small" /> : <ArrowDownwardIcon fontSize="small" />
                              )}
                            </Box>
                          </TableCell>
                        ))}
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {(() => {
                        // Get filtered transactions based on time window
                        const displayTransactions = getFilteredTransactions();
                        
                        // Filter across all fields
                        const filtered = displayTransactions.filter(txn => {
                          if (!searchText) return true;
                          const search = searchText.toLowerCase();
                          return (
                            txn.label.toLowerCase().includes(search) ||
                            txn.avg.toString().includes(search) ||
                            txn.min.toString().includes(search) ||
                            txn.max.toString().includes(search) ||
                            txn.p90.toString().includes(search) ||
                            txn.pass.toString().includes(search) ||
                            txn.fail.toString().includes(search) ||
                            txn.errorRate.toString().includes(search)
                          );
                        });
                        
                        if (filtered.length === 0) {
                          return (
                            <TableRow>
                              <TableCell colSpan={8} align="center" sx={{ py: 3 }}>
                                <Typography variant="body2" color="text.secondary">
                                  {searchText ? 'No matching transactions found' : 'No transaction data available yet'}
                                </Typography>
                              </TableCell>
                            </TableRow>
                          );
                        }
                        
                        const sorted = [...filtered].sort((a, b) => {
                          const aVal = a[sortConfig.key];
                          const bVal = b[sortConfig.key];
                          
                          if (typeof aVal === 'string') {
                            return sortConfig.direction === 'asc' 
                              ? aVal.localeCompare(bVal)
                              : bVal.localeCompare(aVal);
                          }
                          
                          return sortConfig.direction === 'asc' 
                            ? aVal - bVal
                            : bVal - aVal;
                        });
                        
                        return sorted.map((txn, index) => (
                          <TableRow key={index}>
                            <TableCell>
                              <MuiTooltip title={txn.label} arrow>
                                <span>
                                  {txn.label.length > 60 ? `${txn.label.slice(0, 60)}…` : txn.label}
                                </span>
                              </MuiTooltip>
                            </TableCell>
                            <TableCell align="right">{txn.avg}</TableCell>
                            <TableCell align="right">{txn.min}</TableCell>
                            <TableCell align="right">{txn.max}</TableCell>
                            <TableCell align="right">{txn.p90}</TableCell>
                            <TableCell align="right" sx={{ color: 'success.main' }}>{txn.pass}</TableCell>
                            <TableCell align="right" sx={{ color: 'error.main' }}>{txn.fail}</TableCell>
                            <TableCell align="right">
                              <Chip 
                                label={`${txn.errorRate}%`} 
                                size="small"
                                color={txn.errorRate > 5 ? 'error' : txn.errorRate > 1 ? 'warning' : 'success'}
                              />
                            </TableCell>
                          </TableRow>
                        ));
                      })()}
                    </TableBody>
                  </Table>
                </TableContainer>
              </CardContent>
            </Card>
          ) : null}
        </>
      )}
      {/* Execution Logs & Downloads - gated by tab when tabs are present */}
      {logs.length > 0 && (!hasTabs || activeTab === 'agent-breakdown') && (
        <Card sx={{ mt: 3 }}>
          <CardContent>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1 }}>
              <Box>
                <Typography variant="h6" gutterBottom>
                  Execution Logs
                  {test?.status === 'running' && (
                    <Chip label="LIVE" color="error" size="small" sx={{ ml: 2 }} />
                  )}
                </Typography>
              </Box>
              {test.status === 'completed' && (
                <Box>
                  <IconButton size="small" onClick={(e) => setAnchorEl(e.currentTarget)}>
                    <DownloadIcon />
                  </IconButton>
                  <Menu
                    anchorEl={anchorEl}
                    open={Boolean(anchorEl)}
                    onClose={() => setAnchorEl(null)}
                  >
                    <MenuItem onClick={handleDownloadJtl}>Download JTL File</MenuItem>
                    <MenuItem onClick={() => handleExport('csv', 'summary')}>Export Summary (CSV)</MenuItem>
                    <MenuItem onClick={() => handleExport('json', 'summary')}>Export Summary (JSON)</MenuItem>
                    <MenuItem onClick={() => handleExport('csv', 'detailed')}>Export Detailed (CSV)</MenuItem>
                    <MenuItem onClick={() => handleExport('csv', 'metrics')}>Export Metrics (CSV)</MenuItem>
                    <MenuItem onClick={handleDownloadScript}>Download Script (JMX + deps)</MenuItem>
                  </Menu>
                </Box>
              )}
            </Box>
            <Box sx={{ 
              maxHeight: 400, 
              overflow: 'auto',
              bgcolor: '#1e1e1e',
              p: 2,
              borderRadius: 1,
              fontFamily: 'monospace'
            }}>
              {logs.map((log, index) => (
                <Box 
                  key={index} 
                  sx={{ 
                    py: 0.5,
                    color: log.level === 'error' ? '#f44336' : 
                           log.level === 'success' ? '#4caf50' :
                           log.level === 'warning' ? '#ff9800' : '#90caf9',
                    fontSize: '0.875rem'
                  }}
                >
                  <Box component="span" sx={{ color: '#888', mr: 1 }}>
                    {new Date(log.timestamp).toLocaleTimeString()}
                  </Box>
                  <Box component="span" sx={{ color: '#64b5f6', mr: 1 }}>
                    [{log.agent}]
                  </Box>
                  <Box component="span">
                    {log.message}
                  </Box>
                </Box>
              ))}
            </Box>
          </CardContent>
        </Card>
      )}
      {metrics.length === 0 && test.status !== 'pending' && (
        <Card>
          <CardContent sx={{ textAlign: 'center', py: 8 }}>
            <Typography color="text.secondary">
              No metrics data available yet
            </Typography>
          </CardContent>
        </Card>
      )}

      {/* Host Resource Metrics - tabbed for all non-pending tests */}
      {hostMetrics.length > 0 && (!hasTabs || activeTab === 'host-metrics') && (
        <Card id="host-metrics" sx={{ mb: 3, scrollMarginTop: 80 }}>
          <CardContent>
            <Typography variant="h6" gutterBottom sx={{ fontWeight: 'bold', mb: 2 }}>
              <ComputerIcon sx={{ verticalAlign: 'middle', mr: 1 }} />
              Host Resource Metrics
            </Typography>
            
            {loadingHostMetrics && test?.status === 'running' && (
              <Box sx={{ display: 'flex', justifyContent: 'center', mb: 2 }}>
                <CircularProgress size={20} sx={{ mr: 1 }} />
                <Typography variant="body2" color="text.secondary">
                  Updating metrics...
                </Typography>
              </Box>
            )}
            
            {/* Combined graph for all hosts */}
            {(() => {
              // Group metrics by timestamp to combine all agents
              const timeGrouped = hostMetrics.reduce((acc: any, metric: any) => {
                const timeKey = new Date(metric.timestamp).toLocaleTimeString();
                if (!acc[timeKey]) {
                  acc[timeKey] = { time: timeKey };
                }
                // Add CPU and Memory for each agent
                const hostLabel = metric.agentHostname || metric.agentName;
                acc[timeKey][`${hostLabel}-CPU`] = metric.cpuPercent;
                acc[timeKey][`${hostLabel}-Memory`] = metric.memoryPercent;
                return acc;
              }, {});
              
              const chartData = Object.values(timeGrouped);
              
              // Get unique agent hostnames for creating lines
              const uniqueAgents = [...new Set(hostMetrics.map((m: any) => m.agentHostname || m.agentName))];
              
              // Color palette for different agents - each host gets distinct colors
              const cpuColors = ['#ff6b6b', '#4ecdc4', '#45b7d1', '#ffa07a', '#98d8c8', '#f7dc6f', '#bb8fce', '#85c1e2'];
              const memoryColors = ['#ee5a6f', '#37b8af', '#3498db', '#ff8c69', '#7dcea0', '#f4d03f', '#a569bd', '#5dade2'];
              
              // Handle legend click to toggle visibility
              const handleLegendClick = (dataKey: string) => {
                setHiddenHostMetrics(prev => {
                  const newSet = new Set(prev);
                  if (newSet.has(dataKey)) {
                    newSet.delete(dataKey);
                  } else {
                    newSet.add(dataKey);
                  }
                  return newSet;
                });
              };
              
              return (
                <ResponsiveContainer width="100%" height={400}>
                  <LineChart data={chartData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis 
                      dataKey="time" 
                      tick={{ fontSize: 12 }}
                      interval="preserveStartEnd"
                    />
                    <YAxis 
                      label={{ value: 'Usage (%)', angle: -90, position: 'insideLeft' }}
                      domain={[0, 100]}
                    />
                    <Tooltip />
                    <Legend 
                      onClick={(e) => handleLegendClick(e.dataKey)}
                      wrapperStyle={{ cursor: 'pointer' }}
                    />
                    {uniqueAgents.map((agent: string, index: number) => (
                      <>
                        <Line
                          key={`${agent}-cpu`}
                          type="monotone"
                          dataKey={`${agent}-CPU`}
                          name={`${agent} CPU`}
                          stroke={cpuColors[index % cpuColors.length]}
                          strokeWidth={2}
                          dot={false}
                          hide={hiddenHostMetrics.has(`${agent}-CPU`)}
                          strokeOpacity={hiddenHostMetrics.has(`${agent}-CPU`) ? 0.3 : 1}
                        />
                        <Line
                          key={`${agent}-memory`}
                          type="monotone"
                          dataKey={`${agent}-Memory`}
                          name={`${agent} Memory`}
                          stroke={memoryColors[index % memoryColors.length]}
                          strokeWidth={2}
                          strokeDasharray="5 5"
                          dot={false}
                          hide={hiddenHostMetrics.has(`${agent}-Memory`)}
                          strokeOpacity={hiddenHostMetrics.has(`${agent}-Memory`) ? 0.3 : 1}
                        />
                      </>
                    ))}
                  </LineChart>
                </ResponsiveContainer>
              );
            })()}
          </CardContent>
        </Card>
      )}
      </Container>
    </Box>
  );
}
