import { Router, Response } from 'express';
import { body, validationResult } from 'express-validator';
import { PrismaClient } from '@prisma/client';
import { authenticate, AuthRequest } from '../middleware/auth';

const router = Router();

router.use(authenticate);

// Create comparison
router.post(
  '/',
  [
    body('name').trim().isLength({ min: 1 }),
    body('testIds').isArray({ min: 2, max: 10 })
  ],
  async (req: AuthRequest, res: Response): Promise<void> => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        res.status(400).json({ errors: errors.array() });

        return;
      }
      
      const prisma: PrismaClient = req.app.get('prisma');
      const { name, testIds } = req.body;
      
      // Verify all tests belong to user
      const tests = await prisma.test.findMany({
        where: { id: { in: testIds } },
        include: { project: true }
      });
      
      if (tests.length !== testIds.length) {
        res.status(404).json({ error: 'One or more tests not found' });

        return;
      }
      
      const unauthorized = tests.some(t => t.project.userId !== req.user!.id);
      if (unauthorized) {
        res.status(403).json({ error: 'Unauthorized' });

        return;
      }
      
      // Create comparison
      const comparison = await prisma.testComparison.create({
        data: {
          name,
          testIds
        }
      });
      
      res.status(201).json(comparison);
    } catch (error) {
      console.error('Error creating comparison:', error);
      res.status(500).json({ error: 'Failed to create comparison' });
    }
  }
);

// Get comparison
router.get('/:id', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const prisma: PrismaClient = req.app.get('prisma');
    
    const comparison = await prisma.testComparison.findUnique({
      where: { id: req.params.id as string }
    });
    
    if (!comparison) {
      res.status(404).json({ error: 'Comparison not found' });

      return;
    }
    
    // Fetch all tests with results
    const testIdsArray = comparison.testIds.split(',').map(id => id.trim());
    const tests = await prisma.test.findMany({
      where: { id: { in: testIdsArray } },
      include: {
        project: true,
        results: true,
        script: { select: { name: true } }
      }
    });
    
    // Verify user has access
    const unauthorized = tests.some(t => t.project.userId !== req.user!.id);
    if (unauthorized) {
      res.status(403).json({ error: 'Unauthorized' });

      return;
    }
    
    // Calculate comparison data
    const comparisonData = {
      id: comparison.id,
      name: comparison.name,
      createdAt: comparison.createdAt,
      tests: tests.map(t => ({
        id: t.id,
        name: t.name,
        scriptName: t.script.name,
        status: t.status,
        threads: t.threads,
        duration: t.duration,
        results: t.results
      })),
      metrics: {
        avgResponseTime: tests.map(t => ({
          testId: t.id,
          value: t.results?.avgResponseTime || 0,
          delta: 0 // Calculate delta in frontend
        })),
        throughput: tests.map(t => ({
          testId: t.id,
          value: t.results?.throughput || 0,
          delta: 0
        })),
        errorRate: tests.map(t => ({
          testId: t.id,
          value: t.results?.errorRate || 0,
          delta: 0
        })),
        p95: tests.map(t => ({
          testId: t.id,
          value: t.results?.p95 || 0,
          delta: 0
        }))
      }
    };
    
    res.json(comparisonData);
  } catch (error) {
    console.error('Error fetching comparison:', error);
    res.status(500).json({ error: 'Failed to fetch comparison' });
  }
});

// Get all comparisons
router.get('/', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const prisma: PrismaClient = req.app.get('prisma');
    
    const comparisons = await prisma.testComparison.findMany({
      orderBy: { createdAt: 'desc' }
    });
    
    // Filter to only those the user has access to
    const accessibleComparisons = [];
    for (const comp of comparisons) {
      const testIdsArray = comp.testIds.split(',').map(id => id.trim());
      const tests = await prisma.test.findMany({
        where: { id: { in: testIdsArray } },
        include: { project: true }
      });
      
      if (tests.every(t => t.project.userId === req.user!.id)) {
        accessibleComparisons.push({
          ...comp,
          testCount: tests.length
        });
      }
    }
    
    res.json(accessibleComparisons);
  } catch (error) {
    console.error('Error fetching comparisons:', error);
    res.status(500).json({ error: 'Failed to fetch comparisons' });
  }
});

// Delete comparison
router.delete('/:id', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const prisma: PrismaClient = req.app.get('prisma');
    
    await prisma.testComparison.delete({
      where: { id: req.params.id as string }
    });
    
    res.status(204).send();
  } catch (error) {
    console.error('Error deleting comparison:', error);
    res.status(500).json({ error: 'Failed to delete comparison' });
  }
});

export default router;

