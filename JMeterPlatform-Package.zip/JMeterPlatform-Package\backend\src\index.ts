import express from 'express';
import cors from 'cors';
import { Server } from 'socket.io';
import http from 'http';
import dotenv from 'dotenv';
import { PrismaClient } from '@prisma/client';
import { createLogger } from './utils/logger';
import { errorHandler } from './middleware/errorHandler';
import { initializeMinIO, minioClient } from './config/minio';

// Import routes
import authRoutes from './routes/auth';
import projectRoutes from './routes/projects';
import scriptRoutes from './routes/scripts';
import agentRoutes from './routes/agents';
import testRoutes from './routes/tests';
import exportRoutes from './routes/export';
import comparisonRoutes from './routes/comparison';

// Load environment variables
dotenv.config();

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: process.env.CORS_ORIGIN || 'http://localhost:8080',
    credentials: true
  }
});

// Initialize
const prisma = new PrismaClient();
const logger = createLogger();
const PORT = parseInt(process.env.PORT || '3000');
const HOST = process.env.HOST || '0.0.0.0';

// Middleware
app.use(cors({
  origin: process.env.CORS_ORIGIN || 'http://localhost:8080',
  credentials: true
}));

// Increase payload size limits for large JTL file uploads (3GB)
app.use(express.json({ limit: '50mb' })); // For JSON payloads
app.use(express.urlencoded({ extended: true, limit: '50mb' })); // For URL-encoded payloads

// Make io and prisma available to routes
app.set('io', io);
app.set('prisma', prisma);
app.set('minio', minioClient);

// Health check
app.get('/health', (_req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

app.get('/api/health', (_req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// API Routes
app.use('/api/auth', authRoutes);
app.use('/api/projects', projectRoutes);
app.use('/api/scripts', scriptRoutes);
app.use('/api/agents', agentRoutes);
app.use('/api/tests', testRoutes);
app.use('/api/export', exportRoutes);
app.use('/api/comparison', comparisonRoutes);

// Error handler (must be last)
app.use(errorHandler);

// WebSocket connection handling
io.on('connection', (socket) => {
  logger.info(`Client connected: ${socket.id}`);
  
  socket.on('disconnect', () => {
    logger.info(`Client disconnected: ${socket.id}`);
  });
  
  socket.on('subscribe:test', (testId: string) => {
    socket.join(`test:${testId}`);
    logger.info(`Client ${socket.id} subscribed to test ${testId}`);
  });
  
  socket.on('unsubscribe:test', (testId: string) => {
    socket.leave(`test:${testId}`);
    logger.info(`Client ${socket.id} unsubscribed from test ${testId}`);
  });
});

// Initialize MinIO and start server
async function startServer() {
  try {
    // Test database connection
    await prisma.$connect();
    logger.info('Database connected successfully');
    
    // Initialize MinIO (optional - skip if not available)
    try {
      await initializeMinIO();
      logger.info('MinIO initialized successfully');
    } catch (minioError) {
      logger.warn('MinIO not available - file upload features will be limited');
      logger.warn('To enable file uploads, start MinIO: docker-compose up -d minio');
    }
    
    // Start server
    server.listen(PORT, HOST, () => {
      logger.info(`Server running on http://${HOST}:${PORT}`);
      logger.info(`Environment: ${process.env.NODE_ENV || 'development'}`);
    });
  } catch (error) {
    logger.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Graceful shutdown
process.on('SIGINT', async () => {
  logger.info('Shutting down gracefully...');
  await prisma.$disconnect();
  server.close(() => {
    logger.info('Server closed');
    process.exit(0);
  });
});

process.on('SIGTERM', async () => {
  logger.info('SIGTERM received, shutting down...');
  await prisma.$disconnect();
  server.close(() => {
    logger.info('Server closed');
    process.exit(0);
  });
});

startServer();

export { app, io, prisma };
