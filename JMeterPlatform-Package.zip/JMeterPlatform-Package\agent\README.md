# JMeter Load Generator Agent

This is a standalone load generator agent that connects to your JMeter testing platform and executes distributed performance tests.

## Features

- ✅ Auto-registration with backend server
- ✅ Automatic JMeter detection
- ✅ Real-time heartbeat and status updates
- ✅ Download test scripts and dependencies
- ✅ Execute JMeter tests in non-GUI mode
- ✅ Upload results to backend
- ✅ Cross-platform support (Windows, Linux, macOS)
- ✅ Docker support
- ✅ Localhost and remote deployment

## Quick Start

### Option 1: Localhost Setup (Windows)

1. **Prerequisites**
   - Python 3.9 or higher
   - JMeter 5.5 or higher installed

2. **Setup**
   ```cmd
   cd agent
   start-agent.bat
   ```

3. **First Run**
   - The script will create a virtual environment
   - Install dependencies automatically
   - Create `.env` file from template
   - Edit `.env` with your backend URL

4. **Run Again**
   ```cmd
   start-agent.bat
   ```

### Option 2: Localhost Setup (Linux/Mac)

1. **Prerequisites**
   - Python 3.9 or higher
   - JMeter 5.5 or higher installed

2. **Setup**
   ```bash
   cd agent
   chmod +x start-agent.sh
   ./start-agent.sh
   ```

3. **Configuration**
   - Edit `.env` file with your settings
   ```bash
   nano .env
   ```

4. **Run Again**
   ```bash
   ./start-agent.sh
   ```

### Option 3: Manual Setup

```bash
# Create virtual environment
python -m venv venv

# Activate (Windows)
venv\Scripts\activate

# Activate (Linux/Mac)
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Copy and configure .env
cp .env.example .env
nano .env

# Run agent
python agent.py
```

### Option 4: Docker Setup

```bash
# Build and run with Docker Compose
docker-compose up -d

# View logs
docker-compose logs -f

# Stop agent
docker-compose down
```

Or using Docker directly:

```bash
# Build image
docker build -t jmeter-agent .

# Run container
docker run -d \
  --name jmeter-agent \
  -e BACKEND_URL=http://your-backend:3000 \
  -e AGENT_NAME=docker-agent-001 \
  -e AGENT_LOCATION=cloud-region-1 \
  jmeter-agent
```

## Configuration

Edit the `.env` file:

```env
# Backend Server
BACKEND_URL=http://localhost:3000

# Agent Identification
AGENT_NAME=agent-localhost-001
AGENT_LOCATION=localhost

# Capacity
MAX_THREADS=1000

# JMeter Installation (auto-detected if empty)
JMETER_HOME=/path/to/jmeter

# Polling (optional)
POLL_INTERVAL=5
```

### Configuration Options

| Variable | Description | Default | Required |
|----------|-------------|---------|----------|
| `BACKEND_URL` | URL of the backend API server | `http://localhost:3000` | Yes |
| `AGENT_NAME` | Unique name for this agent | Hostname | No |
| `AGENT_LOCATION` | Geographic location or identifier | `localhost` | No |
| `MAX_THREADS` | Maximum concurrent threads | `1000` | No |
| `JAVA_HOME` | Path to JDK installation | Auto-detected | No |
| `JMETER_HOME` | Path to JMeter installation | Auto-detected | No |
| `POLL_INTERVAL` | Seconds between polling for tests | `5` | No |

## JDK and JMeter Installation

### Configuring Custom Paths

You can configure custom paths for Java and JMeter in the `.env` file:

```env
# Windows
JAVA_HOME=C:\Program Files\Java\jdk-17
JMETER_HOME=C:\apache-jmeter-5.6.3

# Linux
JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64
JMETER_HOME=/opt/jmeter

# macOS
JAVA_HOME=/Library/Java/JavaVirtualMachines/jdk-17.jdk/Contents/Home
JMETER_HOME=/usr/local/apache-jmeter-5.6.3
```

**Auto-Detection**: If you leave these empty, the agent will automatically detect installations.

### Windows

**Install Java:**
1. Download JDK from https://www.oracle.com/java/technologies/downloads/ or https://adoptium.net/
2. Install to default location or custom path
3. Set `JAVA_HOME` in `.env` or let the agent auto-detect

**Install JMeter:**
1. Download JMeter from https://jmeter.apache.org/download_jmeter.cgi
2. Extract to `C:\jmeter` or your preferred location
3. Set `JMETER_HOME` in `.env` or let the agent auto-detect

### Linux

**Install Java:**
```bash
# Ubuntu/Debian
sudo apt-get update
sudo apt-get install openjdk-17-jdk

# Find Java path
which java
readlink -f $(which java)

# Set in .env or use auto-detection
JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64
```

**Install JMeter:**
```bash
# Using package manager (Ubuntu/Debian)
sudo apt-get update
sudo apt-get install jmeter

# Or download manually
wget https://downloads.apache.org/jmeter/binaries/apache-jmeter-5.6.3.tgz
tar -xzf apache-jmeter-5.6.3.tgz
sudo mv apache-jmeter-5.6.3 /opt/jmeter

# Set in .env
JMETER_HOME=/opt/jmeter
```

### macOS

**Install Java:**
```bash
# Using Homebrew
brew install openjdk@17

# Find Java path
/usr/libexec/java_home -V

# Set in .env
JAVA_HOME=/Library/Java/JavaVirtualMachines/jdk-17.jdk/Contents/Home
```

**Install JMeter:**
```bash
# Using Homebrew
brew install jmeter

# Or download manually
wget https://downloads.apache.org/jmeter/binaries/apache-jmeter-5.6.3.tgz
tar -xzf apache-jmeter-5.6.3.tgz
sudo mv apache-jmeter-5.6.3 /usr/local/apache-jmeter-5.6.3

# Set in .env
JMETER_HOME=/usr/local/Cellar/jmeter/5.6.3/libexec
```

### Docker

JMeter is included in the Docker image automatically.

## Deploying Multiple Agents

### Same Machine

Create multiple directories:

```bash
# Agent 1
mkdir agent1
cd agent1
# Copy agent files
python -m venv venv
# Edit .env with AGENT_NAME=agent-1
python agent.py &

# Agent 2
mkdir agent2
cd agent2
# Copy agent files
python -m venv venv
# Edit .env with AGENT_NAME=agent-2
python agent.py &
```

### Different Machines

1. Copy the entire `agent` folder to each machine
2. Configure each `.env` with:
   - Same `BACKEND_URL`
   - Unique `AGENT_NAME`
   - Appropriate `AGENT_LOCATION`
3. Run the agent on each machine

### Cloud Deployment

#### AWS EC2

```bash
# Launch EC2 instance
# Connect via SSH
ssh -i key.pem ubuntu@ec2-ip

# Install dependencies
sudo apt-get update
sudo apt-get install -y python3 python3-pip default-jre

# Download and setup JMeter
wget https://downloads.apache.org/jmeter/binaries/apache-jmeter-5.6.3.tgz
tar -xzf apache-jmeter-5.6.3.tgz
sudo mv apache-jmeter-5.6.3 /opt/jmeter

# Clone/copy agent files
# Configure and run
./start-agent.sh
```

#### Azure VM

```bash
# Similar to AWS, after creating VM
# Install dependencies
sudo apt-get update
sudo apt-get install -y python3 python3-pip default-jre

# Setup JMeter and agent
# Run agent
```

#### Google Cloud

```bash
# Create GCE instance
# SSH into instance
# Install and configure similar to AWS
```

#### Kubernetes

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: jmeter-agents
spec:
  replicas: 3
  selector:
    matchLabels:
      app: jmeter-agent
  template:
    metadata:
      labels:
        app: jmeter-agent
    spec:
      containers:
      - name: jmeter-agent
        image: your-registry/jmeter-agent:latest
        env:or "Java not found" error

**Solution**:
- Install JDK and JMeter
- Configure paths in `.env`:
  ```env
  JAVA_HOME=/path/to/jdk
  JMETER_HOME=/path/to/jmeter
  ```
- Verify installations:
  ```bash
  # Test Java
  $JAVA_HOME/bin/java -version
  
  # Test JMeter (Windows)
  %JMETER_HOME%\bin\jmeter.bat --version
  
  # Test JMeter (Linux/Mac)
  $JMETER_HOME/bin/jmeter --version
  ```
- Restart the agent after configuration

## Monitoring

### View Logs

```bash
# Real-time logs
tail -f agent.log

# Last 100 lines
tail -n 100 agent.log

# Docker logs
docker-compose logs -f
```

### Agent Status

The agent sends heartbeat every 10 seconds with:
- Status (online, busy, offline)
- CPU usage
- Memory usage
- Current test (if running)

Check backend dashboard to see agent status.

## Troubleshooting

### Agent Won't Register

**Problem**: Connection refused to backend

**Solution**:
- Check `BACKEND_URL` in `.env`
- Ensure backend is running
- Check firewall/network settings
- For Docker, use `host.docker.internal` instead of `localhost`

### JMeter Not Found

**Problem**: "JMeter not found" error

**Solution**:
- Install JMeter
- Set `JMETER_HOME` in `.env` to correct path
- Verify JMeter works: `jmeter --version`

### Test Execution Fails

**Problem**: Test starts but fails during execution

**Solution**:
- Check `agent.log` for errors
- Check `work/{test-id}/jmeter.log` for JMeter errors
- Verify JMX file is valid
- Check available memory and CPU

### Dependencies Not Loading

**Problem**: CSV or JAR files not found during test

**Solution**:
- Check `work/{test-id}/` directory for downloaded files
- Verify backend has correct dependency URLs
- Check file permissions

## Performance Tuning

### JVM Settings

Edit JMeter's `bin/jmeter.sh` or `jmeter.bat`:

```bash
# Increase heap size
HEAP="-Xms2g -Xmx4g -XX:MaxMetaspaceSize=512m"
```

### Agent Settings

```env
# Increase max threads for larger tests
MAX_THREADS=5000

# Reduce polling for lower CPU usage
POLL_INTERVAL=10
```

### System Resources

- **CPU**: 2+ cores recommended
- **RAM**: 4GB+ recommended (8GB for large tests)
- **Network**: Low latency to target servers
- **Disk**: SSD recommended for log writing

## Security

### API Key Authentication

The agent receives an API key during registration. This key is used for all subsequent requests.

### Network Security

- Use HTTPS for backend communication in production
- Configure firewall to allow only necessary ports
- Use VPN or private network for agent-backend communication

### File Security

- Agent creates `work/` directory for temporary files
- Files are cleaned up after test completion (configurable)
- Logs may contain sensitive data - secure appropriately

## Updating the Agent

```bash
# Stop agent
# Ctrl+C or kill process

# Pull latest code
git pull

# Update dependencies
pip install -r requirements.txt

# Restart agent
python agent.py
```

## Uninstalling

```bash
# Stop agent
# Remove directory
cd ..
rm -rf agent

# Or on Windows
rmdir /s agent
```

## Support

For issues or questions:
- Check logs in `agent.log`
- Review backend API logs
- Check JMeter logs in `work/{test-id}/jmeter.log`
- Verify network connectivity
- Ensure JMeter version compatibility
