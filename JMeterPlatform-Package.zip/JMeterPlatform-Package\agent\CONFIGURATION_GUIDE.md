# Agent Configuration Guide

## Overview

The JMeter Load Generator Agent requires Java (JDK) and Apache JMeter to execute tests. Both can be auto-detected or manually configured.

## Configuration Methods

### Method 1: Auto-Detection (Recommended for Standard Installations)

Leave `JAVA_HOME` and `JMETER_HOME` empty in `.env`:

```env
JAVA_HOME=
JMETER_HOME=
```

The agent will search common installation paths:
- System PATH
- Standard installation directories
- Environment variables

### Method 2: Manual Configuration (Recommended for Custom Installations)

Specify exact paths in `.env`:

```env
JAVA_HOME=C:\Program Files\Java\jdk-17
JMETER_HOME=C:\apache-jmeter-5.6.3
```

## Platform-Specific Configuration

### Windows

#### Java Configuration

**Find Java Installation:**
```cmd
where java
```

**Common Java Paths:**
```
C:\Program Files\Java\jdk-11
C:\Program Files\Java\jdk-17
C:\Program Files\Java\jdk-21
C:\Program Files\Eclipse Adoptium\jdk-11
C:\Program Files\Eclipse Adoptium\jdk-17
```

**Configure in .env:**
```env
JAVA_HOME=C:\Program Files\Java\jdk-17
```

**Note**: On Windows, use backslashes `\` or double backslashes `\\` in paths.

#### JMeter Configuration

**Common JMeter Paths:**
```
C:\jmeter
C:\apache-jmeter-5.6.3
C:\Program Files\apache-jmeter-5.6.3
```

**Configure in .env:**
```env
JMETER_HOME=C:\apache-jmeter-5.6.3
```

#### Example Windows .env:
```env
BACKEND_URL=http://localhost:3000
AGENT_NAME=windows-agent-001
AGENT_LOCATION=localhost
MAX_THREADS=1000

# Configure Java and JMeter paths
JAVA_HOME=C:\Program Files\Java\jdk-17
JMETER_HOME=C:\apache-jmeter-5.6.3

POLL_INTERVAL=5
```

### Linux

#### Java Configuration

**Find Java Installation:**
```bash
which java
readlink -f $(which java)
echo $JAVA_HOME
```

**Common Java Paths:**
```
/usr/lib/jvm/java-11-openjdk-amd64
/usr/lib/jvm/java-17-openjdk-amd64
/usr/lib/jvm/default-java
/opt/jdk-11
/opt/jdk-17
```

**Configure in .env:**
```env
JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64
```

#### JMeter Configuration

**Common JMeter Paths:**
```
/opt/jmeter
/opt/apache-jmeter-5.6.3
/usr/local/jmeter
/usr/share/jmeter
```

**Configure in .env:**
```env
JMETER_HOME=/opt/jmeter
```

#### Example Linux .env:
```env
BACKEND_URL=http://backend.company.com:3000
AGENT_NAME=linux-agent-001
AGENT_LOCATION=datacenter-us-east

# Configure Java and JMeter paths
JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64
JMETER_HOME=/opt/apache-jmeter-5.6.3

MAX_THREADS=2000
POLL_INTERVAL=5
```

### macOS

#### Java Configuration

**Find Java Installation:**
```bash
/usr/libexec/java_home
/usr/libexec/java_home -V
which java
```

**Common Java Paths:**
```
/Library/Java/JavaVirtualMachines/jdk-11.jdk/Contents/Home
/Library/Java/JavaVirtualMachines/jdk-17.jdk/Contents/Home
/opt/homebrew/opt/openjdk@17
```

**Configure in .env:**
```env
JAVA_HOME=/Library/Java/JavaVirtualMachines/jdk-17.jdk/Contents/Home
```

#### JMeter Configuration

**Common JMeter Paths:**
```
/usr/local/Cellar/jmeter/5.6.3/libexec
/opt/apache-jmeter-5.6.3
/usr/local/jmeter
```

**Configure in .env:**
```env
JMETER_HOME=/usr/local/Cellar/jmeter/5.6.3/libexec
```

#### Example macOS .env:
```env
BACKEND_URL=http://localhost:3000
AGENT_NAME=mac-agent-001
AGENT_LOCATION=localhost

# Configure Java and JMeter paths
JAVA_HOME=/Library/Java/JavaVirtualMachines/jdk-17.jdk/Contents/Home
JMETER_HOME=/usr/local/Cellar/jmeter/5.6.3/libexec

MAX_THREADS=1000
POLL_INTERVAL=5
```

## Verification

### Verify Configuration

After configuring paths, verify they are correct:

#### Windows:
```cmd
# Test Java
"%JAVA_HOME%\bin\java.exe" -version

# Test JMeter
"%JMETER_HOME%\bin\jmeter.bat" --version
```

#### Linux/Mac:
```bash
# Test Java
$JAVA_HOME/bin/java -version

# Test JMeter
$JMETER_HOME/bin/jmeter --version
```

### Agent Validation

When the agent starts, it validates all paths:

```
Agent initialized: agent-localhost-001
Backend URL: http://localhost:3000
Java Home: /usr/lib/jvm/java-17-openjdk-amd64
JMeter Home: /opt/apache-jmeter-5.6.3
Java version detected: openjdk version "17.0.9"
JMeter found at: /opt/apache-jmeter-5.6.3/bin/jmeter
```

If validation fails, you'll see clear error messages:

```
Configuration errors detected:
  - Java executable not found at: C:\invalid\path\bin\java.exe
  - JMeter executable not found at: C:\invalid\jmeter\bin\jmeter.bat

Please configure JAVA_HOME and JMETER_HOME in .env file
Example .env configuration:
  JAVA_HOME=C:\Program Files\Java\jdk-17
  JMETER_HOME=C:\apache-jmeter-5.6.3
```

## Troubleshooting

### Issue: "Java not found"

**Solutions:**

1. **Install Java:**
   - Download from https://adoptium.net/ or https://www.oracle.com/java/technologies/downloads/
   - Install JDK 11 or higher

2. **Configure Path:**
   ```env
   JAVA_HOME=/path/to/java
   ```

3. **Verify Installation:**
   ```bash
   java -version
   ```

### Issue: "JMeter not found"

**Solutions:**

1. **Install JMeter:**
   - Download from https://jmeter.apache.org/download_jmeter.cgi
   - Extract to a directory

2. **Configure Path:**
   ```env
   JMETER_HOME=/path/to/jmeter
   ```

3. **Verify Installation:**
   ```bash
   jmeter --version
   ```

### Issue: "Path contains spaces"

**Windows Solution:**
```env
# Use quotes or escape spaces
JAVA_HOME=C:\Program Files\Java\jdk-17
# Agent handles spaces automatically
```

**Linux/Mac Solution:**
```env
# Escape spaces with backslash
JAVA_HOME=/Applications/Java\ JDK/jdk-17
# Or use the actual path without spaces
```

### Issue: "Permission denied"

**Linux/Mac Solution:**
```bash
# Make JMeter executable
chmod +x $JMETER_HOME/bin/jmeter

# Make agent executable
chmod +x start-agent.sh
```

## Multiple JDK/JMeter Versions

If you have multiple versions installed, specify which one to use:

```env
# Use specific Java version
JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64

# Use specific JMeter version
JMETER_HOME=/opt/apache-jmeter-5.6.3
```

## Environment-Specific Configuration

### Development
```env
BACKEND_URL=http://localhost:3000
JAVA_HOME=
JMETER_HOME=
# Auto-detection works fine for development
```

### Production
```env
BACKEND_URL=https://jmeter-platform.company.com
JAVA_HOME=/opt/jdk-17
JMETER_HOME=/opt/apache-jmeter-5.6.3
# Explicit paths for production stability
```

### Docker
```env
# Paths are pre-configured in Dockerfile
JAVA_HOME=/usr/lib/jvm/default-java
JMETER_HOME=/opt/jmeter
```

## Best Practices

1. **Use Absolute Paths**: Always use complete paths, not relative paths
2. **Avoid Spaces**: If possible, install in paths without spaces
3. **Use Latest LTS**: Java 17 or 21 LTS, JMeter 5.6+
4. **Test First**: Verify installations before starting agent
5. **Document Paths**: Keep a record of installation paths for your team
6. **Version Control**: Don't commit `.env` with local paths; use `.env.example`

## Quick Reference

| Platform | Java Path Example | JMeter Path Example |
|----------|------------------|---------------------|
| Windows | `C:\Program Files\Java\jdk-17` | `C:\apache-jmeter-5.6.3` |
| Linux | `/usr/lib/jvm/java-17-openjdk-amd64` | `/opt/apache-jmeter-5.6.3` |
| macOS | `/Library/Java/JavaVirtualMachines/jdk-17.jdk/Contents/Home` | `/usr/local/Cellar/jmeter/5.6.3/libexec` |
| Docker | `/usr/lib/jvm/default-java` | `/opt/jmeter` |
