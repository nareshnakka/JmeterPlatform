-- AlterTable
ALTER TABLE "test_agents" ADD COLUMN "avgResponseTime" REAL;
ALTER TABLE "test_agents" ADD COLUMN "completedAt" DATETIME;
ALTER TABLE "test_agents" ADD COLUMN "errorRate" REAL;
ALTER TABLE "test_agents" ADD COLUMN "failedSamples" INTEGER;
ALTER TABLE "test_agents" ADD COLUMN "maxResponseTime" REAL;
ALTER TABLE "test_agents" ADD COLUMN "minResponseTime" REAL;
ALTER TABLE "test_agents" ADD COLUMN "resultFilePath" TEXT;
ALTER TABLE "test_agents" ADD COLUMN "successfulSamples" INTEGER;
ALTER TABLE "test_agents" ADD COLUMN "throughput" REAL;
ALTER TABLE "test_agents" ADD COLUMN "totalSamples" INTEGER;
