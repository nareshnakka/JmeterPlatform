"""
JMeter Load Generator Agent
This agent can run on any system to execute distributed JMeter tests
"""

import os
import sys
import subprocess
import requests
import time
import json
import psutil
import socket
import platform
import logging
import shutil
from pathlib import Path
from datetime import datetime
from typing import Optional, Dict, List
from dotenv import load_dotenv
import threading

# Setup logging with UTF-8 encoding for Windows
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('agent.log', encoding='utf-8'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger('JMeterAgent')

# Set UTF-8 encoding for stdout on Windows
if sys.platform == 'win32':
    import codecs
    if sys.stdout.encoding != 'utf-8':
        sys.stdout.reconfigure(encoding='utf-8')

class JMeterAgent:
    def __init__(self):
        # Capture any explicit environment overrides for this process
        # so that per-process settings (like AGENT_NAME/AGENT_MODE set by
        # start scripts) are not clobbered by values in .env.
        forced_agent_name = os.environ.get('AGENT_NAME')
        forced_agent_mode = os.environ.get('AGENT_MODE')
        forced_heartbeat = os.environ.get('HEARTBEAT_INTERVAL')

        # Load configuration from .env
        load_dotenv(override=True)

        # ------------------------------------------------------------------
        # Step 1: Ensure required settings exist in .env (prompt if missing)
        # ------------------------------------------------------------------

        # Backend URL
        backend_url_env = os.getenv('BACKEND_URL', '').strip()
        if not backend_url_env:
            backend_url_env = self._prompt_backend_url()

        # JAVA_HOME
        java_home_env = os.getenv('JAVA_HOME', '').strip()
        if not java_home_env:
            detected_java = self._find_java()
            if detected_java:
                java_home_env = detected_java
                self._save_to_env('JAVA_HOME', java_home_env)
            else:
                java_home_env = self._prompt_java_path()
                if java_home_env:
                    self._save_to_env('JAVA_HOME', java_home_env)

        # JMETER_HOME
        jmeter_home_env = os.getenv('JMETER_HOME', '').strip()
        if not jmeter_home_env:
            detected_jmeter = self._find_jmeter()
            if detected_jmeter:
                jmeter_home_env = detected_jmeter
                self._save_to_env('JMETER_HOME', jmeter_home_env)
            else:
                jmeter_home_env = self._prompt_jmeter_path()
                if jmeter_home_env:
                    self._save_to_env('JMETER_HOME', jmeter_home_env)

        # ------------------------------------------------------------------
        # Step 2: Reload .env so we always start from persisted configuration
        # ------------------------------------------------------------------
        load_dotenv(override=True)

        # Re-apply any explicit env overrides for agent identity/behaviour
        # so that values provided by the launching script win over .env.
        if forced_agent_name:
            os.environ['AGENT_NAME'] = forced_agent_name
        if forced_agent_mode:
            os.environ['AGENT_MODE'] = forced_agent_mode
        if forced_heartbeat:
            os.environ['HEARTBEAT_INTERVAL'] = forced_heartbeat

        # Final configuration from .env + explicit overrides
        self.backend_url = os.getenv('BACKEND_URL', backend_url_env).strip()
        self.java_home = os.getenv('JAVA_HOME', java_home_env).strip()
        self.jmeter_home = os.getenv('JMETER_HOME', jmeter_home_env).strip()

        # Generate unique agent name if not set
        agent_name_env = os.getenv('AGENT_NAME', '').strip()
        if not agent_name_env:
            self.agent_name = self._generate_unique_agent_name()
        else:
            self.agent_name = agent_name_env

        self.agent_location = os.getenv('AGENT_LOCATION', 'localhost')
        self.max_threads = int(os.getenv('MAX_THREADS', '1000'))
        self.poll_interval = int(os.getenv('POLL_INTERVAL', '5'))
        # Heartbeat interval (seconds) - controls how often CPU/Memory are reported
        self.heartbeat_interval = int(os.getenv('HEARTBEAT_INTERVAL', '30'))
        # Agent mode:
        #   'load'    - default, polls for tests and executes JMeter
        #   'monitor' - host monitoring only (no Java/JMeter required, no tests executed)
        self.agent_mode = os.getenv('AGENT_MODE', 'load').strip().lower() or 'load'
        
        # State
        self.agent_id = None
        self.api_key = None
        self.is_running = True
        self.current_test = None
        
        # Directories
        self.work_dir = Path('./work')
        self.work_dir.mkdir(exist_ok=True)
        # Work directory retention policy
        self.work_dir_retention_days = int(os.getenv('WORK_DIR_RETENTION_DAYS', '10'))
        self.work_dir_max_folders = int(os.getenv('WORK_DIR_MAX_FOLDERS', '10'))
        # Enforce retention on startup so old data doesn't accumulate
        self._enforce_work_dir_retention()
        
        logger.info(f"Agent initialized: {self.agent_name}")
        logger.info(f"Backend URL: {self.backend_url}")
        logger.info(f"Java Home: {self.java_home}")
        logger.info(f"JMeter Home: {self.jmeter_home}")
        
        # Validate paths
        self._validate_paths()
    
    def _find_java(self) -> str:
        """Attempt to find Java installation"""
        # Check if java is in PATH
        if shutil.which('java'):
            java_path = shutil.which('java')
            # Try to get JAVA_HOME from java executable
            java_home = str(Path(java_path).parent.parent)
            if os.path.exists(java_home):
                return java_home
        
        # Check common Java installation paths
        common_paths = [
            os.getenv('JAVA_HOME', ''),
            '/usr/lib/jvm/default-java',
            '/usr/lib/jvm/java-11-openjdk-amd64',
            '/usr/lib/jvm/java-17-openjdk-amd64',
            'C:\\Program Files\\Java\\jdk-11',
            'C:\\Program Files\\Java\\jdk-17',
            'C:\\Program Files\\Java\\jdk-21',
            'C:\\Program Files\\Eclipse Adoptium\\jdk-11',
            'C:\\Program Files\\Eclipse Adoptium\\jdk-17',
            os.path.expanduser('~/jdk'),
        ]
        
        for path in common_paths:
            if path and os.path.exists(path):
                java_bin = os.path.join(path, 'bin', 'java.exe' if platform.system() == 'Windows' else 'java')
                if os.path.exists(java_bin):
                    return path
        
        logger.warning("Java not found. Please set JAVA_HOME environment variable")
        return ''

    def _prompt_java_path(self) -> str:
        """Interactively prompt user for Java (JDK) path to use as JAVA_HOME"""
        print("\n" + "=" * 70)
        print("  ⚠️  Java (JDK) Installation Not Found")
        print("=" * 70)
        print("\nJava could not be auto-detected on your system.")
        print("\nPlease enter the path to your Java JDK installation (JAVA_HOME).")
        print("Examples:")
        if platform.system() == 'Windows':
            print("  C\\Program Files\\Java\\jdk-17")
            print("  C\\Program Files\\Java\\jdk-21")
        else:
            print("  /usr/lib/jvm/java-17-openjdk-amd64")
            print("  /usr/lib/jvm/java-11-openjdk-amd64")

        while True:
            print("\n" + "-" * 70)
            java_home = input("Enter JAVA_HOME path (or leave blank to exit): ").strip()

            if not java_home:
                print("❌ JAVA_HOME is required for running JMeter.")
                print("   Exiting. Please install Java and set JAVA_HOME, then run the agent again.")
                sys.exit(1)

            java_home = os.path.expanduser(java_home)
            java_exe = 'java.exe' if platform.system() == 'Windows' else 'java'
            java_bin = os.path.join(java_home, 'bin', java_exe)

            if not os.path.exists(java_home):
                print(f"❌ Directory not found: {java_home}")
                continue

            if not os.path.exists(java_bin):
                print(f"❌ Java executable not found at: {java_bin}")
                print("   Please make sure you entered the JDK home directory (not bin folder)")
                continue

            # Verify Java actually works
            print(f"\n🔍 Verifying Java installation...")
            try:
                result = subprocess.run(
                    [java_bin, '-version'],
                    capture_output=True,
                    text=True,
                    timeout=10
                )
                version_line = result.stderr.split('\n')[0]
                print(f"✅ Java verified: {version_line}")
            except subprocess.TimeoutExpired:
                print("❌ Java verification timed out")
                continue
            except Exception as e:
                print(f"❌ Failed to verify Java: {e}")
                retry = input("\n   Try a different path? (y/n): ").strip().lower()
                if retry == 'y':
                    continue
                else:
                    sys.exit(1)

            print(f"✅ Java configured successfully: {java_home}")
            return java_home
    
    def _find_jmeter(self) -> str:
        """Attempt to find JMeter installation"""
        common_paths = [
            '/opt/jmeter',
            '/usr/local/jmeter',
            'C:\\jmeter',
            'C:\\apache-jmeter',
            'C:\\apache-jmeter-5.6.3',
            'C:\\Program Files\\apache-jmeter',
            os.path.expanduser('~/jmeter'),
            os.path.expanduser('~/apache-jmeter'),
        ]
        
        # Check common paths
        for path in common_paths:
            jmeter_bin = 'jmeter.bat' if platform.system() == 'Windows' else 'jmeter'
            if os.path.exists(os.path.join(path, 'bin', jmeter_bin)):
                return path
        
        # Check if jmeter is in PATH
        if shutil.which('jmeter'):
            jmeter_path = shutil.which('jmeter')
            return str(Path(jmeter_path).parent.parent)
        
        logger.warning("JMeter not found in common locations")
        return ''
    
    def _generate_unique_agent_name(self) -> str:
        """Generate a unique agent name based on hostname"""
        hostname = socket.gethostname()
        
        # Try to fetch existing agents from backend to find next available number
        try:
            response = requests.get(f'{self.backend_url}/api/agents', timeout=5)
            if response.status_code == 200:
                agents = response.json()
                # Find agents with similar hostname pattern on this host
                matching_agents = []
                for agent in agents:
                    agent_metadata = agent.get('metadata', '{}')
                    if isinstance(agent_metadata, str):
                        try:
                            metadata = json.loads(agent_metadata)
                        except:
                            metadata = {}
                    else:
                        metadata = agent_metadata
                    
                    # Check if agent is from same hostname
                    if metadata.get('hostname', '') == hostname:
                        matching_agents.append({
                            'name': agent['name'],
                            'status': agent['status'],
                            'location': agent.get('location', 'unknown')
                        })
                
                # If agents already exist on this host, ask for confirmation
                if matching_agents:
                    print("\n" + "=" * 70)
                    print("  ⚠️  Existing Agent(s) Detected on This Server")
                    print("=" * 70)
                    print(f"\nFound {len(matching_agents)} agent(s) already registered from this host:")
                    print("\n" + "-" * 70)
                    for idx, agent_info in enumerate(matching_agents, 1):
                        status_icon = "🟢" if agent_info['status'] == 'online' else "🔴"
                        print(f"  {idx}. {status_icon} {agent_info['name']}")
                        print(f"     Status: {agent_info['status'].upper()}")
                        print(f"     Location: {agent_info['location']}")
                    print("-" * 70)
                    
                    print("\nRunning multiple agents on the same server will:")
                    print("  • Share system resources (CPU, Memory, Network)")
                    print("  • May impact individual test performance")
                    print("  • Is useful for maximizing resource utilization")
                    
                    print("\n" + "=" * 70)
                    confirm = input("Do you want to start another agent on this server? (yes/no): ").strip().lower()
                    
                    if confirm not in ['yes', 'y']:
                        print("\n❌ Agent startup cancelled by user")
                        print("   Tip: You can start the existing agent instead")
                        sys.exit(0)
                    
                    print("\n✅ Proceeding to start additional agent on this server...")
                
                # Find the highest number used
                max_num = 0
                for agent_info in matching_agents:
                    name = agent_info['name']
                    # Try to extract number from pattern hostname-agent-N
                    if '-agent-' in name:
                        try:
                            num = int(name.split('-agent-')[-1])
                            max_num = max(max_num, num)
                        except (ValueError, IndexError):
                            continue
                
                agent_name = f"{hostname}-agent-{max_num + 1}"
                
                logger.info(f"Generated unique agent name: {agent_name}")
                
                # Save to .env file
                print("\n" + "-" * 70)
                save = input(f"💾 Auto-generated agent name: {agent_name}\n   Save to .env file? (y/n): ").strip().lower()
                if save == 'y':
                    self._save_to_env('AGENT_NAME', agent_name)
                    print(f"✅ Saved AGENT_NAME to .env file")
                
                return agent_name
            else:
                # Fallback to hostname-agent-1 if can't fetch agents
                logger.warning(f"Could not fetch existing agents, using default pattern")
                return f"{hostname}-agent-1"
                
        except Exception as e:
            logger.warning(f"Could not check existing agents: {e}")
            # Fallback with timestamp or PID to ensure uniqueness
            import time
            timestamp = int(time.time() * 1000) % 10000  # Last 4 digits of timestamp
            return f"{hostname}-agent-{timestamp}"
    
    def _prompt_backend_url(self) -> str:
        """Interactively prompt user for backend server URL and verify connectivity"""
        print("\n" + "=" * 70)
        print("  🌐 Backend Server Configuration")
        print("=" * 70)
        print("\nPlease specify the JMeter Load Testing Server (backend) address.")
        print("\nExamples:")
        print("  http://192.168.1.100:3000    (Remote server)")
        print("  http://10.0.0.50:3000        (Another network)")
        print("  http://localhost:3000        (Local development)")
        print("  http://jmeter-server:3000    (Hostname)")
        
        while True:
            print("\n" + "-" * 70)
            backend_url = input("Enter backend server URL: ").strip()
            
            if not backend_url:
                print("❌ URL cannot be empty")
                continue
            
            # Add http:// if not specified
            if not backend_url.startswith(('http://', 'https://')):
                backend_url = f'http://{backend_url}'
            
            # Remove trailing slash
            backend_url = backend_url.rstrip('/')
            
            # Verify connectivity
            print(f"\n🔍 Verifying connectivity to {backend_url}...")
            try:
                response = requests.get(f'{backend_url}/api/health', timeout=10)
                
                if response.status_code == 200:
                    print(f"✅ Connection successful!")
                    data = response.json()
                    if 'status' in data:
                        print(f"   Server status: {data.get('status', 'Unknown')}")
                    
                    # Save to .env file
                    save = input("\n💾 Save this URL to .env file for future use? (y/n): ").strip().lower()
                    if save == 'y':
                        self._save_to_env('BACKEND_URL', backend_url)
                        print(f"✅ Saved BACKEND_URL to .env file")
                    
                    return backend_url
                else:
                    print(f"⚠️  Server responded with status code: {response.status_code}")
                    retry = input("\n   Try a different URL? (y/n): ").strip().lower()
                    if retry != 'y':
                        print("❌ Cannot proceed without valid backend server")
                        sys.exit(1)
                    continue
                    
            except requests.exceptions.Timeout:
                print(f"❌ Connection timeout - server did not respond within 10 seconds")
                print(f"   Please check:")
                print(f"   - Is the server running?")
                print(f"   - Is the URL correct?")
                print(f"   - Can you reach the server from this machine?")
                retry = input("\n   Try again? (y/n): ").strip().lower()
                if retry != 'y':
                    print("❌ Cannot proceed without valid backend server")
                    sys.exit(1)
                continue
                
            except requests.exceptions.ConnectionError:
                print(f"❌ Connection failed - could not reach server")
                print(f"   Please check:")
                print(f"   - Is the backend server running?")
                print(f"   - Is the URL correct? ({backend_url})")
                print(f"   - Is there a firewall blocking the connection?")
                print(f"   - Can you ping the server?")
                retry = input("\n   Try a different URL? (y/n): ").strip().lower()
                if retry != 'y':
                    print("❌ Cannot proceed without valid backend server")
                    sys.exit(1)
                continue
                
            except Exception as e:
                print(f"❌ Error connecting to server: {e}")
                retry = input("\n   Try a different URL? (y/n): ").strip().lower()
                if retry != 'y':
                    print("❌ Cannot proceed without valid backend server")
                    sys.exit(1)
                continue
    
    def _prompt_jmeter_path(self) -> str:
        """Interactively prompt user for JMeter path"""
        print("\n" + "=" * 70)
        print("  ⚠️  JMeter Installation Not Found")
        print("=" * 70)
        print("\nJMeter could not be auto-detected on your system.")
        print("\nOptions:")
        print("  1. Enter the path to your JMeter installation")
        print("  2. Skip for now (agent will register but cannot execute tests)")
        print("  3. Exit and install JMeter first")
        
        while True:
            print("\n" + "-" * 70)
            choice = input("Choose an option (1/2/3): ").strip()
            
            if choice == '1':
                print("\nExamples:")
                if platform.system() == 'Windows':
                    print("  C:\\apache-jmeter-5.6.3")
                    print("  C:\\Program Files\\apache-jmeter")
                else:
                    print("  /opt/jmeter")
                    print("  /usr/local/apache-jmeter-5.6.3")
                
                jmeter_path = input("\nEnter JMeter installation path: ").strip()
                
                # Validate the path
                if not jmeter_path:
                    print("❌ Path cannot be empty")
                    continue
                
                jmeter_path = os.path.expanduser(jmeter_path)
                jmeter_bin = 'jmeter.bat' if platform.system() == 'Windows' else 'jmeter'
                jmeter_executable = os.path.join(jmeter_path, 'bin', jmeter_bin)
                
                if not os.path.exists(jmeter_path):
                    print(f"❌ Directory not found: {jmeter_path}")
                    print(f"   Please check the path and try again")
                    continue
                
                if not os.path.exists(jmeter_executable):
                    print(f"❌ JMeter executable not found at: {jmeter_executable}")
                    print(f"   Please make sure you entered the JMeter home directory (not bin folder)")
                    continue
                
                # Verify JMeter actually works
                print(f"\n🔍 Verifying JMeter installation...")
                try:
                    result = subprocess.run(
                        [jmeter_executable, '--version'],
                        capture_output=True,
                        text=True,
                        timeout=10
                    )
                    
                    # Check if JMeter version is in output
                    output = result.stdout + result.stderr
                    if 'jmeter' in output.lower() or 'apache' in output.lower():
                        # Extract version info
                        version_line = [line for line in output.split('\n') if 'jmeter' in line.lower()]
                        if version_line:
                            print(f"✅ JMeter verified: {version_line[0].strip()}")
                        else:
                            print(f"✅ JMeter installation verified")
                    else:
                        print(f"⚠️  Warning: JMeter responded but version info unclear")
                        print(f"   Output: {output[:200]}")
                        confirm = input("\n   Continue anyway? (y/n): ").strip().lower()
                        if confirm != 'y':
                            continue
                
                except subprocess.TimeoutExpired:
                    print(f"❌ JMeter verification timed out")
                    print(f"   The executable at {jmeter_executable} is not responding")
                    print(f"   Please check your JMeter installation")
                    continue
                except Exception as e:
                    print(f"❌ Failed to verify JMeter: {e}")
                    print(f"   Please check your JMeter installation")
                    retry = input("\n   Try a different path? (y/n): ").strip().lower()
                    if retry == 'y':
                        continue
                    else:
                        return ''
                
                # Save to .env file
                save = input("\n💾 Save this path to .env file for future use? (y/n): ").strip().lower()
                if save == 'y':
                    self._save_to_env('JMETER_HOME', jmeter_path)
                    print(f"✅ Saved JMETER_HOME to .env file")
                
                print(f"✅ JMeter configured successfully: {jmeter_path}")
                return jmeter_path
            
            elif choice == '2':
                print("\n⚠️  Continuing without JMeter configuration")
                print("   Agent will register but cannot execute tests")
                print("   You can configure JMeter later by setting JMETER_HOME in .env")
                return ''
            
            elif choice == '3':
                print("\n📥 To install JMeter:")
                print("   1. Download from: https://jmeter.apache.org/download_jmeter.cgi")
                print("   2. Extract to a directory (e.g., C:\\apache-jmeter-5.6.3)")
                print("   3. Run this agent again")
                print("\nExiting...")
                sys.exit(0)
            
            else:
                print("❌ Invalid choice. Please enter 1, 2, or 3")
    
    def _save_to_env(self, key: str, value: str):
        """Save or update a key-value pair in .env file"""
        env_file = Path('.env')
        
        if env_file.exists():
            # Read existing content
            with open(env_file, 'r') as f:
                lines = f.readlines()
            
            # Update or append
            key_found = False
            for i, line in enumerate(lines):
                if line.startswith(f'{key}='):
                    lines[i] = f'{key}={value}\n'
                    key_found = True
                    break
            
            if not key_found:
                lines.append(f'{key}={value}\n')
            
            # Write back
            with open(env_file, 'w') as f:
                f.writelines(lines)
        else:
            # Create new .env file
            with open(env_file, 'w') as f:
                f.write(f'{key}={value}\n')
    
    def _validate_paths(self):
        """Validate JDK and JMeter paths"""
        errors = []
        
        # Validate Java (required only for load-generating agents)
        if self.agent_mode != 'monitor':
            if not self.java_home:
                errors.append("Java not found. Please install Java or set JAVA_HOME")
            else:
                java_exe = 'java.exe' if platform.system() == 'Windows' else 'java'
                java_bin = os.path.join(self.java_home, 'bin', java_exe)
                if not os.path.exists(java_bin):
                    errors.append(f"Java executable not found at: {java_bin}")
                else:
                    # Test Java version
                    try:
                        result = subprocess.run(
                            [java_bin, '-version'],
                            capture_output=True,
                            text=True,
                            timeout=5
                        )
                        logger.info(f"Java version detected: {result.stderr.split('\\n')[0]}")
                    except Exception as e:
                        errors.append(f"Failed to verify Java: {e}")
        
        # Validate JMeter (optional - and not needed for pure monitoring agents)
        if self.agent_mode != 'monitor':
            if not self.jmeter_home:
                logger.warning("JMeter not found. Agent will register but cannot execute tests until JMeter is configured.")
            else:
                jmeter_exe = 'jmeter.bat' if platform.system() == 'Windows' else 'jmeter'
                jmeter_bin = os.path.join(self.jmeter_home, 'bin', jmeter_exe)
                if not os.path.exists(jmeter_bin):
                    logger.warning(f"JMeter executable not found at: {jmeter_bin}")
                    logger.warning("Agent will register but cannot execute tests until JMeter is properly configured.")
                else:
                    logger.info(f"JMeter found at: {jmeter_bin}")
        
        if errors:
            logger.error("Configuration errors detected:")
            for error in errors:
                logger.error(f"  - {error}")

            if self.agent_mode == 'monitor':
                # In monitor-only mode we don't require Java/JMeter; just warn and continue
                logger.warning("Running in monitor-only mode - Java/JMeter validation errors will be ignored.")
            else:
                logger.error("\\nPlease configure JAVA_HOME in .env file")
                logger.error("Example .env configuration:")
                logger.error("  JAVA_HOME=C:\\Program Files\\Java\\jdk-17")
                logger.error("  JMETER_HOME=C:\\apache-jmeter-5.6.3 (optional)")
                sys.exit(1)
    
    def get_system_info(self) -> Dict:
        """Collect system information"""
        mem = psutil.virtual_memory()
        return {
            'hostname': socket.gethostname(),
            'ip_address': self._get_ip_address(),
            'platform': platform.system(),
            'platform_version': platform.version(),
            'cpu_count': psutil.cpu_count(),
            'total_memory_mb': mem.total // (1024 * 1024),
            'available_memory_mb': mem.available // (1024 * 1024),
            'cpu_percent': psutil.cpu_percent(interval=1),
            'memory_percent': mem.percent
        }
    
    def _get_ip_address(self) -> str:
        """Get local IP address"""
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except Exception:
            return '127.0.0.1'
    
    def register(self) -> bool:
        """Register agent with backend server"""
        try:
            system_info = self.get_system_info()
            payload = {
                'name': self.agent_name,
                'hostname': system_info['hostname'],
                'ipAddress': system_info['ip_address'],
                'location': self.agent_location,
                'maxThreads': self.max_threads,
                'platform': system_info['platform'],
                'cpuCount': system_info['cpu_count'],
                'totalMemoryMb': system_info['total_memory_mb'],
                # Expose agent mode so backend/UI can distinguish
                # load-generating agents from monitor-only agents.
                'mode': self.agent_mode,
            }
            
            logger.info(f"Registering agent: {self.agent_name}")
            response = requests.post(
                f'{self.backend_url}/api/agents/register',
                json=payload,
                timeout=10
            )
            
            # Accept both 200 (existing agent) and 201 (new agent) as success
            if response.status_code in [200, 201]:
                data = response.json()
                self.agent_id = data['id']
                self.api_key = data.get('apiKey', '')
                status_msg = "updated" if response.status_code == 200 else "registered"
                logger.info("")
                logger.info("*" * 80)
                logger.info(f"  AGENT {status_msg.upper()} SUCCESSFULLY")
                logger.info(f"  Agent ID: {self.agent_id}")
                logger.info(f"  Agent Name: {self.agent_name}")
                logger.info(f"  Status: ONLINE")
                logger.info("*" * 80)
                logger.info("")
                return True
            else:
                logger.error(f"[FAIL] Failed to register agent: {response.status_code} - {response.text}")
                return False
                
        except Exception as e:
            logger.error(f"[FAIL] Error registering agent: {e}")
            return False
    
    def heartbeat(self):
        """Send heartbeat to backend"""
        if not self.agent_id:
            logger.debug("Skipping heartbeat - agent_id not set")
            return
        
        try:
            system_info = self.get_system_info()
            payload = {
                'status': 'busy' if self.current_test else 'online',
                'cpuPercent': system_info['cpu_percent'],
                'memoryPercent': system_info['memory_percent'],
                'availableMemoryMb': system_info['available_memory_mb'],
                'currentTest': self.current_test,
                'currentLoad': int(system_info['cpu_percent'])
            }
            
            headers = {'Authorization': f'Bearer {self.api_key}'} if self.api_key else {}
            
            response = requests.put(
                f'{self.backend_url}/api/agents/{self.agent_id}/heartbeat',
                json=payload,
                headers=headers,
                timeout=5
            )
            
            if response.status_code == 200:
                current_status = 'busy' if self.current_test else 'online'
                logger.info(f"[HEARTBEAT] Sent - Status: {current_status}, Test: {self.current_test or 'None'}, CPU: {system_info['cpu_percent']:.1f}%, Memory: {system_info['memory_percent']:.1f}%")
            else:
                logger.warning(f"Heartbeat failed: {response.status_code} - {response.text}")
            
            # Check for restart command
            self.check_restart_command()
                
        except requests.exceptions.Timeout:
            logger.warning(f"Heartbeat timeout - server may be slow or unreachable")
        except requests.exceptions.ConnectionError:
            logger.warning(f"Heartbeat connection error - server may be down")
        except Exception as e:
            logger.error(f"Error sending heartbeat: {e}", exc_info=True)
    
    def check_restart_command(self):
        """Check if backend has requested agent restart"""
        try:
            headers = {'Authorization': f'Bearer {self.api_key}'} if self.api_key else {}
            
            response = requests.get(
                f'{self.backend_url}/api/agents/{self.agent_id}/restart-status',
                headers=headers,
                timeout=5
            )
            
            if response.status_code == 200:
                data = response.json()
                if data.get('restartRequested'):
                    logger.warning("=" * 80)
                    logger.warning("RESTART COMMAND RECEIVED FROM BACKEND")
                    logger.warning("Initiating agent restart...")
                    logger.warning("=" * 80)
                    # Exit the process - the system service/script should restart it
                    import sys
                    sys.exit(0)
                    
        except Exception as e:
            logger.debug(f"Error checking restart command: {e}")
    
    def poll_for_tests(self) -> Optional[Dict]:
        """Poll backend for test assignments"""
        if not self.agent_id:
            return None
        
        try:
            headers = {'Authorization': f'Bearer {self.api_key}'} if self.api_key else {}
            
            response = requests.get(
                f'{self.backend_url}/api/agents/{self.agent_id}/pending-tests',
                headers=headers,
                timeout=5
            )
            
            if response.status_code == 200:
                tests = response.json()
                return tests[0] if tests else None
            else:
                logger.debug(f"No pending tests")
                return None
                
        except Exception as e:
            logger.error(f"Error polling for tests: {e}")
            return None
    
    def download_test_files(self, test_id: str) -> Optional[str]:
        """Download JMX script and dependencies"""
        try:
            test_dir = self.work_dir / test_id
            test_dir.mkdir(exist_ok=True, parents=True)
            
            headers = {'Authorization': f'Bearer {self.api_key}'} if self.api_key else {}
            
            # Download JMX file
            logger.info(f"Downloading test script for test {test_id}")
            response = requests.get(
                f'{self.backend_url}/api/tests/{test_id}/jmx',
                headers=headers,
                timeout=30
            )
            
            if response.status_code != 200:
                logger.error(f"Failed to download JMX: {response.status_code}")
                return None
            
            jmx_path = test_dir / 'test.jmx'
            jmx_path.write_bytes(response.content)
            logger.info(f"[OK] Downloaded JMX file: {jmx_path}")
            
            # Download dependencies
            response = requests.get(
                f'{self.backend_url}/api/tests/{test_id}/dependencies',
                headers=headers,
                timeout=10
            )
            
            if response.status_code == 200:
                dependencies = response.json()
                logger.info(f"Downloading {len(dependencies)} dependencies")
                
                for dep in dependencies:
                    dep_response = requests.get(dep['url'], timeout=30)
                    dep_path = test_dir / dep['name']
                    dep_path.write_bytes(dep_response.content)
                    logger.info(f"[OK] Downloaded dependency: {dep['name']}")
            
            return str(jmx_path)
            
        except Exception as e:
            logger.error(f"Error downloading test files: {e}")
            return None
    
    def update_jmx_parameters(self, jmx_path: str, threads: int, duration: int, ramp_up: int) -> bool:
        """Update thread count, duration, and ramp-up in JMX file to use parameterized values"""
        try:
            import xml.etree.ElementTree as ET
            
            # Parse the JMX file
            tree = ET.parse(jmx_path)
            root = tree.getroot()
            
            # Find all ThreadGroup elements and forcefully replace all settings
            modified = False
            for thread_group in root.iter('ThreadGroup'):
                # Create a list to track elements to remove and add
                elements_to_replace = []
                
                for i, prop in enumerate(thread_group):
                    prop_name = prop.get('name')
                    
                    # Collect elements that need to be changed from intProp/longProp to stringProp
                    if prop_name == 'ThreadGroup.num_threads':
                        elements_to_replace.append(('num_threads', i, '${__P(threads,1)}'))
                        modified = True
                    elif prop_name == 'ThreadGroup.duration':
                        elements_to_replace.append(('duration', i, '${__P(duration,60)}'))
                        modified = True
                    elif prop_name == 'ThreadGroup.ramp_time':
                        elements_to_replace.append(('ramp_time', i, '${__P(rampUp,1)}'))
                        modified = True
                    elif prop_name == 'ThreadGroup.scheduler':
                        prop.text = 'true'
                        modified = True
                    elif prop_name == 'ThreadGroup.main_controller':
                        for loop_prop in prop:
                            loop_prop_name = loop_prop.get('name')
                            if loop_prop_name == 'LoopController.continue_forever':
                                loop_prop.text = 'true'
                                modified = True
                            elif loop_prop_name == 'LoopController.loops':
                                loop_prop.text = '-1'
                                modified = True
                
                # Replace intProp/longProp with stringProp for parameterized values
                for param_type, index, value in reversed(elements_to_replace):
                    # Remove old element
                    old_elem = thread_group[index]
                    thread_group.remove(old_elem)
                    
                    # Create new stringProp element
                    new_elem = ET.Element('stringProp', name=old_elem.get('name'))
                    new_elem.text = value
                    
                    # Insert at the same position
                    thread_group.insert(index, new_elem)
            
            # Save if modified
            if modified:
                tree.write(jmx_path, encoding='utf-8', xml_declaration=True)
                logger.info(f"[OK] JMX file updated: parameterized threads/duration/rampUp, infinite loop enabled")
                return True
            else:
                logger.warning(f"[WARN] No ThreadGroup found in JMX file")
                return False
                
        except Exception as e:
            logger.error(f"Error updating JMX parameters: {e}")
            return False
    
    def execute_test(self, test_id: str, jmx_path: str, threads: int, duration: int, ramp_up: int) -> Optional[str]:
        """Execute JMeter test"""
        try:
            result_file = self.work_dir / test_id / 'results.jtl'
            log_file = self.work_dir / test_id / 'jmeter.log'
            
            # NOTE:
            #   The backend now fully applies global or per-thread-group overrides
            #   to the JMX before the agent downloads it. The previous behaviour of
            #   re-writing the JMX here (update_jmx_parameters) could corrupt
            #   multi-thread-group configurations. We therefore rely solely on the
            #   JMX as delivered by the backend and no longer mutate it locally.
            
            # Determine JMeter executable
            if platform.system() == 'Windows':
                jmeter_cmd = os.path.join(self.jmeter_home, 'bin', 'jmeter.bat')
            else:
                jmeter_cmd = os.path.join(self.jmeter_home, 'bin', 'jmeter')
            
            # Set JAVA_HOME for JMeter
            env = os.environ.copy()
            env['JAVA_HOME'] = self.java_home
            
            # Build JMeter command
            cmd = [
                jmeter_cmd,
                '-n',  # Non-GUI mode
                '-t', jmx_path,  # Test plan
                '-l', str(result_file),  # Results file
                '-j', str(log_file),  # JMeter log
                f'-Jthreads={threads}',  # Thread count
                f'-Jduration={duration}',  # Test duration in seconds
                f'-JrampUp={ramp_up}',  # Ramp-up time in seconds
                f'-Jagent_id={self.agent_id}',
                '-Jjmeter.save.saveservice.autoflush=true',  # Force immediate flush to file
                '-Jjmeter.save.saveservice.output_format=csv',  # CSV format
                '-Jjmeter.save.saveservice.print_field_names=true',  # Include headers
                '-Jjmeter.save.saveservice.assertion_results_failure_message=true'  # Include error details
            ]
            
            # Log test details
            jmx_filename = os.path.basename(jmx_path)
            logger.info(f"=" * 80)
            logger.info(f"STARTING TEST: {test_id}")
            logger.info(f"JMX File: {jmx_filename}")
            logger.info(f"Threads: {threads}")
            logger.info(f"Duration: {duration}s")
            logger.info(f"Ramp-up: {ramp_up}s")
            logger.info(f"Results: {result_file}")
            logger.info(f"Log: {log_file}")
            logger.info(f"-" * 80)
            logger.info(f"JMETER COMMAND:")
            logger.info(f" ")
            # Log command in a more readable format
            for i, part in enumerate(cmd):
                if i == 0:
                    logger.info(f"  {part} \\")
                elif i == len(cmd) - 1:
                    logger.info(f"    {part}")
                else:
                    logger.info(f"    {part} \\")
            logger.info(f"=" * 80)
            
            # Update test status
            self.update_test_status(test_id, 'running')
            
            # Start JMeter process
            start_time = time.time()
            process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,  # Merge stderr to stdout to capture all output
                text=True,
                env=env,
                bufsize=1,  # Line buffered
                universal_newlines=True
            )
            
            # Monitor process and capture live output
            logger.info("JMeter Output:")
            logger.info("-" * 80)
            
            last_metric_time = time.time()
            last_status_check = time.time()
            metric_interval = 5  # Send metrics every 5 seconds for more granular data
            status_check_interval = 3  # Check if test was cancelled every 3 seconds
            
            while process.poll() is None:
                # Read and log JMeter output in real-time
                if process.stdout:
                    line = process.stdout.readline()
                    if line:
                        line = line.strip()
                        # Log all output, highlight summary lines
                        if 'summary +' in line or 'summary =' in line:
                            logger.info(f"[SUMMARY] {line}")
                        elif line and not line.startswith('INFO'):
                            logger.info(f"[JMETER] {line}")
                
                current_time = time.time()
                
                # Check if test was cancelled by user
                if current_time - last_status_check >= status_check_interval:
                    if self.check_test_cancelled(test_id):
                        logger.warning(f"Test {test_id} was cancelled by user - terminating JMeter process")
                        process.terminate()
                        try:
                            process.wait(timeout=10)
                        except subprocess.TimeoutExpired:
                            logger.warning("JMeter process did not terminate gracefully, forcing kill")
                            process.kill()
                            process.wait()
                        logger.info("JMeter process terminated due to user cancellation")
                        self.current_test = None  # Clear current test
                        
                        # Send immediate heartbeat to update status to 'online'
                        self.heartbeat()
                        
                        logger.info("Agent is now available for new tests")
                        return None
                    last_status_check = current_time
                
                # Send metrics at configured interval
                if current_time - last_metric_time >= metric_interval:
                    self.send_metrics(test_id, result_file)
                    last_metric_time = current_time
                
                time.sleep(0.1)
            
            # Read any remaining output
            if process.stdout:
                remaining = process.stdout.read()
                if remaining:
                    for line in remaining.split('\n'):
                        line = line.strip()
                        if line:
                            if 'summary +' in line or 'summary =' in line:
                                logger.info(f"[SUMMARY] {line}")
                            elif not line.startswith('INFO'):
                                logger.info(f"[JMETER] {line}")
            
            duration = time.time() - start_time
            logger.info("-" * 80)
            
            if process.returncode == 0:
                logger.info(f"[OK] Test '{jmx_filename}' completed successfully in {duration:.2f}s")
                logger.info(f"[OK] Updating test status to 'completed'")
                self.update_test_status(test_id, 'completed')
                logger.info("=" * 80)
                logger.info("TEST COMPLETED SUCCESSFULLY")
                logger.info("=" * 80)
                return str(result_file)
            else:
                logger.error(f"[FAIL] Test '{jmx_filename}' failed with code {process.returncode}")
                logger.error(f"[FAIL] Updating test status to 'failed'")
                self.update_test_status(test_id, 'failed', f"Exit code: {process.returncode}")
                logger.info("=" * 80)
                logger.error("TEST FAILED")
                logger.info("=" * 80)
                return None
                
        except Exception as e:
            logger.error(f"Error executing test: {e}", exc_info=True)
            self.update_test_status(test_id, 'failed', str(e))
            self.current_test = None  # Clear current test on exception
            
            # Send immediate heartbeat to update status to 'online'
            self.heartbeat()
            
            logger.info("Agent is now available for new tests (after exception)")
            return None
    
    def check_test_cancelled(self, test_id: str) -> bool:
        """Check if test was cancelled by user"""
        try:
            headers = {'Authorization': f'Bearer {self.api_key}'} if self.api_key else {}
            response = requests.get(
                f'{self.backend_url}/api/tests/{test_id}/status',
                headers=headers,
                timeout=5
            )
            
            if response.status_code == 200:
                data = response.json()
                return data.get('status') == 'cancelled'
            else:
                return False
                
        except Exception as e:
            logger.debug(f"Error checking test status: {e}")
            return False
    
    def update_test_status(self, test_id: str, status: str, error: str = None):
        """Update test status on backend"""
        try:
            headers = {'Authorization': f'Bearer {self.api_key}'} if self.api_key else {}
            payload = {
                'status': status,
                'agentId': self.agent_id
            }
            
            if error:
                payload['error'] = error
            
            response = requests.put(
                f'{self.backend_url}/api/tests/{test_id}/status',
                json=payload,
                headers=headers,
                timeout=5
            )
            
            if response.status_code == 200:
                logger.info(f"[OK] Test status updated to '{status}'")
            else:
                logger.warning(f"Failed to update test status: {response.status_code}")
                
        except Exception as e:
            logger.error(f"Error updating test status: {e}")
    
    def send_metrics(self, test_id: str, result_file: Path):
        """Send real-time metrics from results file"""
        try:
            if not result_file.exists():
                return
            
            # Parse JTL file (CSV format)
            with open(result_file, 'r') as f:
                lines = f.readlines()
                
                # Skip if only header or empty
                if len(lines) <= 1:
                    return
                
                # Get recent lines since last read (or last 200 for initial read)
                # Store last read position to avoid re-reading same data
                if not hasattr(self, '_last_metrics_line'):
                    self._last_metrics_line = {}
                
                last_line_read = self._last_metrics_line.get(test_id, 1)
                recent_lines = lines[last_line_read:]
                
                # Update last read position
                self._last_metrics_line[test_id] = len(lines)
                
                # If no new data, skip
                if len(recent_lines) == 0:
                    return
                
                # Parse metrics from CSV
                # JMeter JTL format: timeStamp,elapsed,label,responseCode,responseMessage,threadName,dataType,success,failureMessage,bytes,sentBytes,grpThreads,allThreads,URL,Latency,IdleTime,Connect
                total_samples = 0
                total_response_time = 0
                min_response_time = float('inf')
                max_response_time = 0
                errors = 0
                active_threads = 0
                total_bytes = 0
                
                # Track per-label metrics for transaction table
                label_metrics = {}
                
                for line in recent_lines:
                    try:
                        parts = line.strip().split(',')
                        if len(parts) >= 13:
                            elapsed = int(parts[1])  # Response time
                            label = parts[2]  # Transaction label
                            success = parts[7].lower() == 'true'
                            threads = int(parts[12])  # allThreads
                            bytes_received = int(parts[9]) if parts[9] else 0  # bytes
                            
                            # Aggregate totals
                            total_samples += 1
                            total_response_time += elapsed
                            min_response_time = min(min_response_time, elapsed)
                            max_response_time = max(max_response_time, elapsed)
                            total_bytes += bytes_received
                            
                            if not success:
                                errors += 1
                            active_threads = max(active_threads, threads)
                            
                            # Track per-label metrics
                            if label not in label_metrics:
                                label_metrics[label] = {
                                    'samples': [],
                                    'pass': 0,
                                    'fail': 0
                                }
                            
                            label_metrics[label]['samples'].append(elapsed)
                            if success:
                                label_metrics[label]['pass'] += 1
                            else:
                                label_metrics[label]['fail'] += 1
                    except:
                        continue
                
                if total_samples == 0:
                    return
                
                # Calculate metrics with more detail
                avg_response_time = total_response_time / total_samples
                error_rate = (errors / total_samples) * 100
                throughput = total_samples  # Samples in this interval
                
                # Calculate per-label transaction statistics
                transactions = []
                for label, data in label_metrics.items():
                    samples = sorted(data['samples'])
                    count = len(samples)
                    if count > 0:
                        avg = sum(samples) / count
                        min_time = min(samples)
                        max_time = max(samples)
                        p90_index = int(count * 0.9)
                        p90 = samples[p90_index] if p90_index < count else samples[-1]
                        error_pct = (data['fail'] / count) * 100 if count > 0 else 0
                        
                        transactions.append({
                            'label': label,
                            'avg': round(avg, 2),
                            'min': min_time,
                            'max': max_time,
                            'p90': p90,
                            'pass': data['pass'],
                            'fail': data['fail'],
                            'errorRate': round(error_pct, 2)
                        })
                
                # Send to backend
                headers = {'Authorization': f'Bearer {self.api_key}'} if self.api_key else {}
                payload = {
                    'agentId': self.agent_id,
                    'responseTime': round(avg_response_time, 2),
                    'throughput': throughput,
                    'errorRate': round(error_rate, 2),
                    'activeThreads': active_threads,
                    'transactions': transactions
                }
                
                response = requests.post(
                    f'{self.backend_url}/api/tests/{test_id}/metrics',
                    json=payload,
                    headers=headers,
                    timeout=5
                )
                
                if response.status_code == 201:
                    logger.info(f"[METRICS] Sent: {throughput} samples, {avg_response_time:.0f}ms avg, {error_rate:.1f}% errors, {active_threads} threads")
                else:
                    logger.warning(f"[METRICS] Failed to send: {response.status_code} - {response.text}")
                    
        except Exception as e:
            logger.error(f"[METRICS] Error sending metrics: {e}")
    
    def upload_results(self, test_id: str, result_file: str) -> bool:
        """Upload test results to backend (supports large files)"""
        try:
            if not os.path.exists(result_file):
                logger.error(f"Result file not found: {result_file}")
                return False
            
            file_size = os.path.getsize(result_file)
            file_size_mb = file_size / (1024 * 1024)
            
            logger.info(f"Uploading results for test {test_id}")
            logger.info(f"JTL file size: {file_size_mb:.2f} MB")
            
            if file_size_mb > 100:
                logger.warning(f"Large file detected ({file_size_mb:.2f} MB) - upload may take several minutes")
            
            headers = {'Authorization': f'Bearer {self.api_key}'} if self.api_key else {}
            
            # Use streaming upload to avoid loading entire file in memory
            with open(result_file, 'rb') as f:
                files = {'result': ('results.jtl', f, 'text/csv')}
                data = {'agentId': self.agent_id}
                
                # Calculate timeout based on file size (at least 5 minutes for large files)
                upload_timeout = max(300, int(file_size_mb * 2))  # 2 seconds per MB minimum
                
                logger.info(f"Upload timeout set to {upload_timeout} seconds")
                
                response = requests.post(
                    f'{self.backend_url}/api/tests/{test_id}/results',
                    files=files,
                    data=data,
                    headers=headers,
                    timeout=upload_timeout
                )
            
            if response.status_code in [200, 201]:
                logger.info(f"[OK] Results uploaded successfully ({file_size_mb:.2f} MB)")
                return True
            else:
                logger.error(f"[FAIL] Failed to upload results: {response.status_code}")
                return False
                
        except requests.exceptions.Timeout:
            logger.error(f"Upload timed out - file may be too large or network is slow")
            return False
        except Exception as e:
            logger.error(f"Error uploading results: {e}")
            return False
    
    def cleanup_test(self, test_id: str):
        """Apply retention after a test completes.

        We keep recent test work directories for troubleshooting but
        automatically clean up:
        - Any folders older than work_dir_retention_days
        - Any excess folders beyond work_dir_max_folders, starting
          from the oldest.
        """
        try:
            logger.info(f"Applying work directory retention policy after test {test_id}")
            self._enforce_work_dir_retention()
        except Exception as e:
            logger.error(f"Error during work directory retention: {e}")

    def _enforce_work_dir_retention(self):
        """Enforce retention policy on the agent work directory."""
        try:
            if not self.work_dir.exists():
                return

            # Collect all test directories
            test_dirs = [d for d in self.work_dir.iterdir() if d.is_dir()]
            if not test_dirs:
                return

            now_ts = time.time()
            max_age_seconds = max(self.work_dir_retention_days, 0) * 86400

            # 1) Remove directories older than retention_days
            if max_age_seconds > 0:
                for d in list(test_dirs):
                    try:
                        age_seconds = now_ts - d.stat().st_mtime
                        if age_seconds > max_age_seconds:
                            logger.info(f"[RETENTION] Removing old work directory (>{self.work_dir_retention_days} days): {d}")
                            shutil.rmtree(d, ignore_errors=True)
                            test_dirs.remove(d)
                    except Exception as e:
                        logger.warning(f"[RETENTION] Failed to inspect/remove directory {d}: {e}")

            # 2) Enforce maximum folder count
            max_folders = max(self.work_dir_max_folders, 0)
            if max_folders and len(test_dirs) > max_folders:
                # Sort by modification time (newest first)
                test_dirs_sorted = sorted(test_dirs, key=lambda p: p.stat().st_mtime, reverse=True)
                to_keep = test_dirs_sorted[:max_folders]
                to_delete = test_dirs_sorted[max_folders:]

                for d in to_delete:
                    try:
                        logger.info(f"[RETENTION] Removing excess work directory (over limit {max_folders}): {d}")
                        shutil.rmtree(d, ignore_errors=True)
                    except Exception as e:
                        logger.warning(f"[RETENTION] Failed to remove directory {d}: {e}")

        except Exception as e:
            logger.error(f"[RETENTION] Unexpected error enforcing work dir policy: {e}")
    
    def run(self):
        """Main agent loop"""
        logger.info("")
        logger.info("=" * 80)
        logger.info("=" * 80)
        logger.info("  JMeter Load Generator Agent Starting")
        logger.info("=" * 80)
        logger.info("=" * 80)
        logger.info("")
        
        # Register with backend
        if not self.register():
            logger.error("Failed to register with backend. Retrying in 10 seconds...")
            time.sleep(10)
            return self.run()
        
        # Start heartbeat thread
        heartbeat_thread = threading.Thread(target=self._heartbeat_loop, daemon=True)
        heartbeat_thread.start()
        logger.info("")
        logger.info(f">>> Heartbeat thread started - sending status every {self.heartbeat_interval} seconds")

        if self.agent_mode == 'monitor':
            logger.info(">>> Agent running in MONITOR-ONLY mode (no tests will be executed)")
            logger.info(">>> This agent will report host CPU/Memory and status only.")
            logger.info("")
            # Just keep process alive while heartbeat thread runs
            try:
                while self.is_running:
                    time.sleep(60)
            except KeyboardInterrupt:
                logger.info("Received shutdown signal...")
                self.is_running = False
            logger.info("Agent shutting down...")
            return

        logger.info(">>> Agent is ready and waiting for test assignments...")
        logger.info("")
        
        # Main loop
        poll_count = 0
        while self.is_running:
            try:
                # Poll for tests
                poll_count += 1
                if poll_count % 12 == 1:  # Log every ~1 minute (12 * 5 seconds)
                    logger.info(f"[POLLING] Checking for test assignments... (poll #{poll_count})")
                test = self.poll_for_tests()
                
                if test:
                    self.current_test = test['id']
                    
                    # Send immediate heartbeat to update status to 'busy'
                    logger.info("[STATUS] Test assignment received - sending heartbeat to mark agent as 'busy'")
                    try:
                        self.heartbeat()
                        logger.info("[STATUS] Heartbeat sent successfully - agent should now show as 'busy'")
                    except Exception as hb_error:
                        logger.error(f"[STATUS] Failed to send heartbeat at test start: {hb_error}")
                    
                    logger.info("")
                    logger.info("#" * 80)
                    logger.info("#" + " " * 78 + "#")
                    logger.info(f"#  TEST ASSIGNMENT RECEIVED" + " " * 51 + "#")
                    logger.info("#" + " " * 78 + "#")
                    logger.info("#" * 80)
                    logger.info(f"Test ID: {test['id']}")
                    logger.info(f"Threads: {test.get('threads', 'N/A')}")
                    logger.info(f"Duration: {test.get('duration', 'N/A')}s")
                    logger.info(f"Script: {test.get('script', {}).get('name', 'N/A')}")
                    logger.info("#" * 80)
                    
                    # Download test files
                    jmx_path = self.download_test_files(test['id'])
                    
                    if jmx_path:
                        # Execute test
                        result_file = self.execute_test(
                            test['id'],
                            jmx_path,
                            test.get('threads', 100),
                            test.get('duration', 60),
                            test.get('rampUp', 1)
                        )
                        
                        if result_file:
                            # Upload results
                            self.upload_results(test['id'], result_file)
                            
                            # Cleanup
                            self.cleanup_test(test['id'])
                    
                    self.current_test = None
                    
                    # Send immediate heartbeat to update status to 'online'
                    logger.info("[STATUS] Test completed - sending heartbeat to mark agent as 'online'")
                    try:
                        self.heartbeat()
                        logger.info("[STATUS] Heartbeat sent successfully - agent should now show as 'online'")
                    except Exception as hb_error:
                        logger.error(f"[STATUS] Failed to send heartbeat after test completion: {hb_error}")
                    
                    logger.info(f"[OK] Test {test['id']} processing completed")
                    logger.info("Agent is ready for next test...")
                
                # Sleep before next poll
                time.sleep(self.poll_interval)
                
            except KeyboardInterrupt:
                logger.info("Received shutdown signal...")
                self.is_running = False
                break
            except Exception as e:
                logger.error(f"Unexpected error in main loop: {e}", exc_info=True)
                logger.info("Recovering from error, continuing agent operation...")
                # Clear current test if there was one
                if self.current_test:
                    logger.info(f"Clearing stuck test: {self.current_test}")
                    self.current_test = None
                    try:
                        self.heartbeat()
                    except:
                        pass
                time.sleep(10)
        
        logger.info("Agent shutting down...")
    
    def _heartbeat_loop(self):
        """Background thread for sending heartbeats"""
        logger.info(">>> Heartbeat thread starting...")
        heartbeat_count = 0
        while self.is_running:
            try:
                heartbeat_count += 1
                logger.debug(f"[HEARTBEAT LOOP] Sending heartbeat #{heartbeat_count}...")
                self.heartbeat()
                # Send heartbeat at configured interval (default 30 seconds)
                time.sleep(self.heartbeat_interval)
            except Exception as e:
                logger.error(f"Error in heartbeat loop: {e}", exc_info=True)
                time.sleep(self.heartbeat_interval)
        logger.warning(">>> Heartbeat thread stopped")


def main():
    """Main entry point"""
    print("""
    ╔════════════════════════════════════════════════════════╗
    ║      JMeter Load Generator Agent                       ║
    ║      Version 1.0.0                                     ║
    ╚════════════════════════════════════════════════════════╝
    """)
    
    agent = JMeterAgent()
    
    try:
        agent.run()
    except KeyboardInterrupt:
        logger.info("Agent stopped by user")
    except Exception as e:
        logger.error(f"Fatal error: {e}")
        sys.exit(1)


if __name__ == '__main__':
    main()
