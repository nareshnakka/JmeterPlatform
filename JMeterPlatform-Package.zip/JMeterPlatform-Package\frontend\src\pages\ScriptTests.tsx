import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Container,
  Typography,
  Button,
  Box,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Chip,
  IconButton,
  Tooltip,
  CircularProgress,
  Alert,
  AppBar,
  Toolbar,
  Checkbox,
} from '@mui/material';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import VisibilityIcon from '@mui/icons-material/Visibility';
import DeleteIcon from '@mui/icons-material/Delete';
import { api } from '../api/client';

interface Test {
  id: string;
  name: string;
  status: string;
  createdAt: string;
  startedAt: string | null;
  completedAt: string | null;
  threads: number;
  duration: number;
  rampUp: number;
  script: {
    id: string;
    name: string;
    scriptKey: string | null;
  };
  testAgents: Array<{
    agent: {
      id: string;
      name: string;
    };
  }>;
}

export default function ScriptTests() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [tests, setTests] = useState<Test[]>([]);
  const [selectedTests, setSelectedTests] = useState<string[]>([]);
  const [scriptName, setScriptName] = useState<string>('');
  const [scriptKey, setScriptKey] = useState<string>('');
  const [projectId, setProjectId] = useState<string>('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    loadTests();
  }, [id]);

  const loadTests = async () => {
    if (!id) return;
    
    try {
      setLoading(true);
      const data = await api.getScriptTests(id);
      setTests(data);
      
      if (data.length > 0) {
        setScriptName(data[0].script.name);
        setScriptKey(data[0].script.scriptKey || '');
        // Get project ID from first test
        const testDetail = await api.getTest(data[0].id);
        setProjectId(testDetail.project.id);
      }
      
      setError('');
    } catch (err: any) {
      setError(err.response?.data?.error || 'Failed to load tests');
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'success';
      case 'running':
        return 'primary';
      case 'failed':
        return 'error';
      case 'pending':
        return 'warning';
      default:
        return 'default';
    }
  };

  const formatDuration = (startedAt: string | null, completedAt: string | null) => {
    if (!startedAt) return '-';
    if (!completedAt) return 'Running...';
    
    const start = new Date(startedAt).getTime();
    const end = new Date(completedAt).getTime();
    const seconds = Math.floor((end - start) / 1000);
    
    if (seconds < 60) return `${seconds}s`;
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}m ${remainingSeconds}s`;
  };

  const handleSelectAll = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.checked) {
      setSelectedTests(tests.map(t => t.id));
    } else {
      setSelectedTests([]);
    }
  };

  const handleSelectTest = (testId: string) => {
    setSelectedTests(prev => 
      prev.includes(testId) 
        ? prev.filter(id => id !== testId)
        : [...prev, testId]
    );
  };

  const handleDeleteSelected = async () => {
    if (selectedTests.length === 0) return;
    
    if (!window.confirm(`Are you sure you want to delete ${selectedTests.length} test(s)?`)) {
      return;
    }

    try {
      await api.deleteTests(selectedTests);
      setSelectedTests([]);
      loadTests();
      setError('');
    } catch (err: any) {
      setError(err.response?.data?.error || 'Failed to delete tests');
    }
  };

  const handleDeleteTest = async (testId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    
    if (!window.confirm('Are you sure you want to delete this test?')) {
      return;
    }

    try {
      await api.deleteTest(testId);
      loadTests();
      setError('');
    } catch (err: any) {
      setError(err.response?.data?.error || 'Failed to delete test');
    }
  };

  if (loading) {
    return (
      <Container maxWidth={false} sx={{ mt: 4, mb: 4, textAlign: 'center' }}>
        <CircularProgress />
      </Container>
    );
  }

  return (
    <Box sx={{ background: 'linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%)', minHeight: '100vh', pb: 4 }}>
      <AppBar position="static" elevation={0} sx={{ background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)' }}>
        <Toolbar sx={{ justifyContent: 'space-between' }}>
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <IconButton
              edge="start"
              color="inherit"
              onClick={() => navigate(projectId ? `/projects/${projectId}` : '/projects')}
              sx={{ mr: 2 }}
            >
              <ArrowBackIcon />
            </IconButton>
            <Box>
              <Typography variant="h5" component="h1" sx={{ fontWeight: 700 }}>
                {scriptName}
              </Typography>
              {scriptKey && (
                <Typography variant="caption" sx={{ opacity: 0.9 }}>
                  Script Key: {scriptKey}
                </Typography>
              )}
            </Box>
          </Box>
        </Toolbar>
      </AppBar>

      <Container maxWidth={false} sx={{ mt: 4 }}>
        {error && (
          <Alert severity="error" sx={{ mb: 3 }}>
            {error}
          </Alert>
        )}

        <Box sx={{ mb: 3, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <Typography variant="h6" sx={{ fontWeight: 600, color: '#667eea' }}>
            Test History ({tests.length} tests)
          </Typography>
          {selectedTests.length > 0 && (
            <Button
              variant="contained"
              color="error"
              startIcon={<DeleteIcon />}
              onClick={handleDeleteSelected}
            >
              Delete {selectedTests.length} Selected
            </Button>
          )}
        </Box>

        {tests.length === 0 ? (
          <Paper sx={{ p: 4, textAlign: 'center' }}>
            <Typography color="text.secondary">
              No tests found for this script.
            </Typography>
          </Paper>
        ) : (
          <TableContainer component={Paper} sx={{ boxShadow: 3 }}>
            <Table>
              <TableHead sx={{ bgcolor: '#f5f5f5' }}>
                <TableRow>
                  <TableCell padding="checkbox">
                    <Checkbox
                      indeterminate={selectedTests.length > 0 && selectedTests.length < tests.length}
                      checked={tests.length > 0 && selectedTests.length === tests.length}
                      onChange={handleSelectAll}
                    />
                  </TableCell>
                  <TableCell sx={{ fontWeight: 700, color: '#667eea' }}>Test Name</TableCell>
                  <TableCell sx={{ fontWeight: 700, color: '#667eea' }}>Status</TableCell>
                  <TableCell sx={{ fontWeight: 700, color: '#667eea' }}>Configuration</TableCell>
                  <TableCell sx={{ fontWeight: 700, color: '#667eea' }}>Agents</TableCell>
                  <TableCell sx={{ fontWeight: 700, color: '#667eea' }}>Created</TableCell>
                  <TableCell sx={{ fontWeight: 700, color: '#667eea' }}>Duration</TableCell>
                  <TableCell align="right" sx={{ fontWeight: 700, color: '#667eea' }}>Actions</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {tests.map((test) => (
                  <TableRow
                    key={test.id}
                    sx={{
                      '&:hover': { bgcolor: '#f9f9f9' },
                      cursor: 'pointer',
                      bgcolor: selectedTests.includes(test.id) ? '#f0f0ff' : 'inherit'
                    }}
                    onClick={() => navigate(`/tests/${test.id}`)}
                  >
                    <TableCell padding="checkbox" onClick={(e) => e.stopPropagation()}>
                      <Checkbox
                        checked={selectedTests.includes(test.id)}
                        onChange={() => handleSelectTest(test.id)}
                      />
                    </TableCell>
                    <TableCell>
                      <Typography variant="body2" sx={{ fontWeight: 600 }}>
                        {test.name}
                      </Typography>
                    </TableCell>
                    <TableCell>
                      <Chip
                        label={test.status}
                        size="small"
                        color={getStatusColor(test.status) as any}
                      />
                    </TableCell>
                    <TableCell>
                      <Typography variant="caption" display="block">
                        {test.threads} threads
                      </Typography>
                      <Typography variant="caption" display="block" color="text.secondary">
                        {test.duration}s duration, {test.rampUp}s ramp-up
                      </Typography>
                    </TableCell>
                    <TableCell>
                      <Typography variant="caption">
                        {test.testAgents.length} agent(s)
                      </Typography>
                    </TableCell>
                    <TableCell>
                      <Typography variant="caption">
                        {new Date(test.createdAt).toLocaleString()}
                      </Typography>
                    </TableCell>
                    <TableCell>
                      <Typography variant="caption">
                        {formatDuration(test.startedAt, test.completedAt)}
                      </Typography>
                    </TableCell>
                    <TableCell align="right" onClick={(e) => e.stopPropagation()}>
                      <Tooltip title="View Details">
                        <IconButton
                          size="small"
                          onClick={() => navigate(`/tests/${test.id}`)}
                          sx={{ color: '#667eea' }}
                        >
                          <VisibilityIcon fontSize="small" />
                        </IconButton>
                      </Tooltip>
                      <Tooltip title="Delete Test">
                        <IconButton
                          size="small"
                          onClick={(e) => handleDeleteTest(test.id, e)}
                          sx={{ color: '#f44336' }}
                        >
                          <DeleteIcon fontSize="small" />
                        </IconButton>
                      </Tooltip>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        )}
      </Container>
    </Box>
  );
}
