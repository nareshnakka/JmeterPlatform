# Multi-Agent Metrics Display - Current Implementation

## Overview

This document explains how metrics are aggregated and displayed when using multiple agents in a distributed load test.

## Current Metrics Aggregation Strategy

### Live Dashboard (During Test Execution)

When multiple agents are running a test simultaneously, each agent sends metrics to the backend every few seconds. The system aggregates these metrics in real-time before displaying them on the dashboard.

#### Aggregation Logic

**Location:** `backend/src/routes/tests.ts` - `POST /:id/metrics` endpoint

**Process:**

1. **Metric Collection**: Each agent sends its current metrics:
   ```json
   {
     "agentId": "agent-1",
     "responseTime": 145,
     "throughput": 1500,
     "errorRate": 0.5,
     "activeThreads": 500,
     "transactions": [...]
   }
   ```

2. **Recent Metrics Retrieval**: Backend gets metrics from all agents in last 10 seconds

3. **Weighted Average Calculation**:
   - **Response Time**: Weighted by active threads from each agent
     ```
     Combined RT = Σ(Agent_RT × Agent_Threads) / Total_Threads
     ```
   
   - **Error Rate**: Weighted by active threads from each agent
     ```
     Combined Error% = Σ(Agent_Error% × Agent_Threads) / Total_Threads
     ```

4. **Direct Summation**:
   - **Throughput**: Sum of all agents' throughput (requests/sec)
     ```
     Total TP = Agent1_TP + Agent2_TP + Agent3_TP
     ```
   
   - **Active Threads**: Sum of all agents' threads
     ```
     Total Threads = Agent1_Threads + Agent2_Threads + Agent3_Threads
     ```

5. **Transaction Aggregation**:
   - Group by transaction label
   - Sum pass/fail counts
   - Average response times across agents

#### WebSocket Broadcast

After aggregation, the backend broadcasts a single combined metric to all connected clients:

```typescript
io.to(`test:${testId}`).emit('metrics', {
  timestamp: new Date(),
  responseTime: 145.23,      // Weighted average
  throughput: 4500,          // Sum
  errorRate: 0.35,           // Weighted average
  activeThreads: 1500,       // Sum
  transactions: [...],       // Aggregated by label
  agentCount: 3              // Number of agents
});
```

**Frontend receives ONE aggregated metric instead of separate metrics from each agent.**

### Example: 3 Agents Load Test

**Scenario:**
- Agent 1: 500 threads, 120ms avg RT, 1500 req/sec, 0.2% error
- Agent 2: 500 threads, 130ms avg RT, 1600 req/sec, 0.4% error  
- Agent 3: 500 threads, 125ms avg RT, 1400 req/sec, 0.5% error

**Dashboard Shows:**
- Total Threads: 1,500 (500+500+500)
- Avg Response Time: 125ms ((120×500 + 130×500 + 125×500) / 1500)
- Throughput: 4,500 req/sec (1500+1600+1400)
- Error Rate: 0.37% ((0.2×500 + 0.4×500 + 0.5×500) / 1500)
- Agent Count Badge: "🤖 3 agents"

### Live Dashboard Display Components

#### 1. Real-Time Metric Cards

Located at top of [TestDetail.tsx](../frontend/src/pages/TestDetail.tsx#L996-L1100)

```tsx
{test.status === 'running' && metrics.length > 0 && (
  <Grid container spacing={3}>
    <Grid item xs={12} md={3}>
      <Card>
        <CardContent>
          <Typography>Avg Response Time</Typography>
          <Typography variant="h4">
            {currentMetric.responseTime}ms
          </Typography>
        </CardContent>
      </Card>
    </Grid>
    
    <Grid item xs={12} md={3}>
      <Card>
        <CardContent>
          <Typography>Throughput</Typography>
          <Typography variant="h4">
            {currentMetric.throughput} req/s
          </Typography>
        </CardContent>
      </Card>
    </Grid>
    
    <Grid item xs={12} md={3}>
      <Card>
        <CardContent>
          <Typography>Error Rate</Typography>
          <Typography variant="h4">
            {currentMetric.errorRate}%
          </Typography>
        </CardContent>
      </Card>
    </Grid>
    
    <Grid item xs={12} md={3}>
      <Card>
        <CardContent>
          <Typography>Active Threads</Typography>
          <Typography variant="h4">
            {currentMetric.activeThreads}
          </Typography>
          {currentMetric.agentCount > 1 && (
            <Chip label={`${currentMetric.agentCount} agents`} size="small" />
          )}
        </CardContent>
      </Card>
    </Grid>
  </Grid>
)}
```

**Shows:** Aggregated metrics from all agents in real-time  
**Updates:** Every time new metrics received via WebSocket  
**Multi-Agent Indicator:** Badge showing agent count

#### 2. Live Charts

Located in [TestDetail.tsx](../frontend/src/pages/TestDetail.tsx#L1100-L1250)

**Response Time Chart:**
```tsx
<LineChart data={chartData}>
  <Line type="monotone" dataKey="responseTime" stroke="#667eea" />
  <XAxis dataKey="time" />
  <YAxis />
  <Tooltip />
  <Legend />
</LineChart>
```

- **X-Axis**: Time (HH:MM:SS)
- **Y-Axis**: Combined response time (ms) from all agents
- **Updates**: Real-time as aggregated metrics arrive

**Throughput Chart:**
```tsx
<LineChart data={chartData}>
  <Line type="monotone" dataKey="throughput" stroke="#4caf50" />
  <XAxis dataKey="time" />
  <YAxis />
</LineChart>
```

- **Shows**: Total throughput (sum of all agents)
- **Example**: 3 agents × 1500 req/s each = 4500 req/s total shown

#### 3. Live Transactions Table

Located in [TestDetail.tsx](../frontend/src/pages/TestDetail.tsx#L1250-L1350)

```tsx
<TableBody>
  {currentMetric.transactions?.map((txn) => (
    <TableRow key={txn.label}>
      <TableCell>{txn.label}</TableCell>
      <TableCell>{txn.avg}ms</TableCell>
      <TableCell>{txn.pass + txn.fail}</TableCell>
      <TableCell>{txn.pass}</TableCell>
      <TableCell>{txn.fail}</TableCell>
      <TableCell>{txn.errorRate}%</TableCell>
    </TableRow>
  ))}
</TableBody>
```

**Transaction Aggregation:**
- **Label**: Transaction name (e.g., "Login", "Search", "Checkout")
- **Avg**: Average response time across all agent samples for this transaction
- **Samples**: Sum of pass + fail from all agents
- **Pass**: Sum of successful samples from all agents
- **Fail**: Sum of failed samples from all agents
- **Error Rate**: (Total Fail / Total Samples) × 100

**Example:**
```
Agent 1 "Login": 100 pass, 2 fail, 120ms avg
Agent 2 "Login": 95 pass, 5 fail, 125ms avg
Agent 3 "Login": 98 pass, 2 fail, 118ms avg

Displayed:
Label: "Login"
Avg: 121ms ((120+125+118)/3)
Samples: 302 (100+95+98+2+5+2)
Pass: 293 (100+95+98)
Fail: 9 (2+5+2)
Error Rate: 2.98% (9/302×100)
```

#### 4. Live Progress Indicator

Located in [TestDetail.tsx](../frontend/src/pages/TestDetail.tsx#L946-L990)

```tsx
{test.status === 'running' && (
  <Box sx={{ width: '100%', mb: 3 }}>
    <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
      <Typography variant="body2">
        Test Progress
      </Typography>
      <Typography variant="body2">
        {calculateElapsedTime()} / {test.duration}s
      </Typography>
    </Box>
    <LinearProgress 
      variant="determinate" 
      value={calculateProgress()} 
      sx={{ height: 10, borderRadius: 5 }}
    />
  </Box>
)}
```

- **Progress Bar**: Based on total test duration (same for all agents)
- **Elapsed Time**: Time since test started
- **Does NOT show individual agent progress** (all agents run full duration)

### Completed Test Dashboard

After all agents complete, metrics display changes to show **aggregated final results**.

#### 1. Status Summary Cards

Located in [TestDetail.tsx](../frontend/src/pages/TestDetail.tsx#L716-L790)

```tsx
{test.status === 'completed' && (
  <Grid container spacing={3}>
    <Grid item xs={12} md={2.4}>
      <Card>
        <CardContent>
          <Typography>Total Samples</Typography>
          <Typography variant="h5">
            {result.totalSamples.toLocaleString()}
          </Typography>
        </CardContent>
      </Card>
    </Grid>
    
    <Grid item xs={12} md={2.4}>
      <Card>
        <CardContent>
          <Typography>Avg Response Time</Typography>
          <Typography variant="h5">
            {result.avgResponseTime}ms
          </Typography>
        </CardContent>
      </Card>
    </Grid>
    
    {/* Similar cards for throughput, error rate, etc. */}
  </Grid>
)}
```

**Aggregation Method:**

Calculated in `backend/src/routes/tests.ts` - `aggregateTestResults()` function:

```typescript
// Sum totals
const totalSamples = completedAgents.reduce((sum, ta) => 
  sum + (ta.totalSamples || 0), 0);

// Weighted average response time (by sample count)
const weightedResponseTime = completedAgents.reduce((sum, ta) => 
  sum + (ta.avgResponseTime || 0) * (ta.totalSamples || 0), 0);
const avgResponseTime = totalSamples > 0 
  ? weightedResponseTime / totalSamples 
  : 0;

// Sum throughput
const throughput = completedAgents.reduce((sum, ta) => 
  sum + (ta.throughput || 0), 0);

// Calculate percentiles from ALL metrics
const allMetrics = await prisma.testMetric.findMany({
  where: { testId: testId },
  orderBy: { responseTime: 'asc' }
});
const p90 = calculatePercentile(responseTimes, 90);
```

#### 2. Per-Agent Breakdown Table

Located in [TestDetail.tsx](../frontend/src/pages/TestDetail.tsx#L823-L940)

```tsx
{test.status === 'completed' && agentResults.length > 1 && (
  <Box sx={{ mb: 4 }}>
    <Typography variant="h6" gutterBottom>
      Per-Agent Results
    </Typography>
    <Alert severity="info" sx={{ mb: 2 }}>
      This test ran on {agentResults.length} agents. 
      Results shown above are aggregated from all agents.
    </Alert>
    
    <TableContainer component={Paper}>
      <Table>
        <TableHead>
          <TableRow>
            <TableCell>Agent</TableCell>
            <TableCell>Status</TableCell>
            <TableCell align="right">Samples</TableCell>
            <TableCell align="right">Avg RT (ms)</TableCell>
            <TableCell align="right">Min RT (ms)</TableCell>
            <TableCell align="right">Max RT (ms)</TableCell>
            <TableCell align="right">Throughput</TableCell>
            <TableCell align="right">Error %</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {agentResults.map((agentResult) => (
            <TableRow key={agentResult.id}>
              <TableCell>
                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                  <ComputerIcon sx={{ mr: 1 }} />
                  <Box>
                    <Typography variant="body2" fontWeight="bold">
                      {agentResult.agent.name}
                    </Typography>
                    <Typography variant="caption" color="text.secondary">
                      {agentResult.agent.location}
                    </Typography>
                  </Box>
                </Box>
              </TableCell>
              <TableCell>
                <Chip 
                  label={agentResult.status} 
                  size="small"
                  color={agentResult.status === 'completed' ? 'success' : 'default'}
                />
              </TableCell>
              <TableCell align="right">
                {agentResult.totalSamples?.toLocaleString()}
              </TableCell>
              <TableCell align="right">
                {agentResult.avgResponseTime?.toFixed(2)}
              </TableCell>
              <TableCell align="right">
                {agentResult.minResponseTime?.toFixed(2)}
              </TableCell>
              <TableCell align="right">
                {agentResult.maxResponseTime?.toFixed(2)}
              </TableCell>
              <TableCell align="right">
                {agentResult.throughput?.toFixed(2)}
              </TableCell>
              <TableCell align="right">
                <Typography 
                  color={agentResult.errorRate > 5 ? 'error' : 'text.primary'}
                  fontWeight={agentResult.errorRate > 5 ? 'bold' : 'normal'}
                >
                  {agentResult.errorRate?.toFixed(2)}%
                </Typography>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  </Box>
)}
```

**Shows:**
- Individual performance metrics from each agent
- Agent location (helps identify network/geographic issues)
- Per-agent error rates (detect problematic agents)
- Load distribution verification (should be roughly equal)

**Use Cases:**
1. **Debugging**: Identify if one agent performed poorly
2. **Verification**: Confirm load was distributed evenly
3. **Analysis**: Compare agent performance by location/network

#### 3. Percentile Metrics

Located in aggregated results display:

```tsx
<Grid item xs={12} md={2.4}>
  <Card>
    <CardContent>
      <Typography>90th Percentile</Typography>
      <Typography variant="h5">{result.p90}ms</Typography>
    </CardContent>
  </Card>
</Grid>

{/* Similar for p50, p95, p99 */}
```

**Calculation:**
- **Database**: All individual metrics stored with `label: agent-{agentId}`
- **Query**: Fetch ALL metrics from ALL agents
- **Sort**: Order by response time ascending
- **Calculate**: Find value at percentile position

**Example with 3 agents:**
```
Agent 1: 10,000 samples (RTs: 50-200ms)
Agent 2: 10,000 samples (RTs: 60-210ms)
Agent 3: 10,000 samples (RTs: 55-205ms)

Total samples: 30,000
P90 position: 27,000th sample
Result: Combined P90 from all 30,000 samples
```

**Accurate because:**
- Uses ALL individual samples, not agent averages
- Properly represents user experience across full test
- Accounts for variance between agents

## Data Flow Diagrams

### Live Metrics Flow

```
┌─────────────────────────────────────────────────────────────────┐
│                    Live Metrics Architecture                     │
└─────────────────────────────────────────────────────────────────┘

Agent 1 (500 threads)                    Backend Server
  ├─ Calculate metrics every 5s            ├─ Receive metrics from Agent 1
  └─ POST /tests/{id}/metrics ───────────► ├─ Receive metrics from Agent 2
                                           ├─ Receive metrics from Agent 3
Agent 2 (500 threads)                      │
  ├─ Calculate metrics every 5s            ├─ Fetch recent metrics (last 10s)
  └─ POST /tests/{id}/metrics ───────────► ├─ Aggregate by weighting/summing
                                           │
Agent 3 (500 threads)                      ├─ Calculate combined metrics:
  ├─ Calculate metrics every 5s            │   • RT: 125ms (weighted avg)
  └─ POST /tests/{id}/metrics ───────────► │   • TP: 4500 req/s (sum)
                                           │   • Threads: 1500 (sum)
                                           │   • Error: 0.37% (weighted avg)
                                           │
                                           └─ WebSocket broadcast ────────────►
                                           
                                           Frontend Dashboard
                                             ├─ Receive ONE aggregated metric
                                             ├─ Update metric cards
                                             ├─ Update charts
                                             ├─ Update transactions table
                                             └─ Show "3 agents" badge
```

### Completed Test Results Flow

```
┌─────────────────────────────────────────────────────────────────┐
│              Completed Test Results Architecture                 │
└─────────────────────────────────────────────────────────────────┘

Agent 1 completes
  ├─ Upload result.jtl (45MB)
  ├─ POST /tests/{id}/results
  └─ Store in TestAgent table ──────────► Backend
                                           ├─ Agent 1 marked completed
Agent 2 completes                          │
  ├─ Upload result.jtl (47MB)             ├─ Agent 2 marked completed
  ├─ POST /tests/{id}/results             │
  └─ Store in TestAgent table ──────────► │
                                           │
Agent 3 completes                          ├─ Agent 3 marked completed
  ├─ Upload result.jtl (46MB)             │
  ├─ POST /tests/{id}/results             ├─ ALL AGENTS COMPLETED ✓
  └─ Store in TestAgent table ──────────► │
                                           ├─ Aggregate results:
                                           │   ├─ Sum samples: 1,250,000
                                           │   ├─ Weighted avg RT: 145ms
                                           │   ├─ Sum throughput: 4,167/s
                                           │   ├─ Calculate percentiles
                                           │   │   from ALL 1.25M samples
                                           │   └─ Store in TestResult
                                           │
                                           ├─ Set status: "collating"
                                           │
                                           ├─ Start JTL merge job ────────────►
                                           │                                   │
                                           └─ WebSocket: test:completed ─────►│
                                           
                                           JTL Merge Job                       │
                                             ├─ Download 3 JTL files          │
                                             ├─ Merge into single file        │
                                             ├─ Upload merged.jtl (138MB)     │
                                             ├─ Update mergedJtlPath          │
                                             └─ Set status: "completed" ──────┤
                                           
                                           Frontend                            │
                                             ├─ Show aggregated results  ◄─────┘
                                             ├─ Show "Collating" banner
                                             ├─ Display per-agent table
                                             └─ Enable merged file download
```

## Key Metrics Explained

### Response Time (Weighted Average)

**Why Weighted?**

If Agent 1 has 100 threads and Agent 2 has 500 threads:
- Agent 2's response time should have 5× more influence
- Simple average would give equal weight (incorrect)
- Weighted average reflects actual user experience

**Formula:**
```
Weighted Avg RT = Σ(Agent_RT × Agent_Samples) / Total_Samples
```

**Example:**
```
Agent 1: 100ms avg, 10,000 samples
Agent 2: 200ms avg, 40,000 samples

Simple average: (100 + 200) / 2 = 150ms ❌ (wrong)
Weighted average: (100×10k + 200×40k) / 50k = 180ms ✓ (correct)
```

### Throughput (Direct Sum)

**Why Sum?**

Throughput represents total requests/second across entire system:
- Each agent contributes independently
- No weighting needed (already normalized to /second)

**Formula:**
```
Total Throughput = Agent1_TP + Agent2_TP + ... + AgentN_TP
```

**Example:**
```
Agent 1: 1,500 req/sec
Agent 2: 1,600 req/sec
Agent 3: 1,400 req/sec

Total: 4,500 req/sec ✓
```

### Error Rate (Weighted Average)

**Why Weighted?**

Similar to response time - agents with more samples should influence more:

**Formula:**
```
Weighted Error% = Σ(Agent_Error% × Agent_Samples) / Total_Samples
```

**Alternative (equivalent):**
```
Error% = (Total_Failed_Samples / Total_Samples) × 100
```

**Example:**
```
Agent 1: 0.2% error, 10,000 samples (20 failures)
Agent 2: 0.4% error, 40,000 samples (160 failures)

Total failures: 180
Total samples: 50,000
Error rate: (180 / 50,000) × 100 = 0.36% ✓
```

### Percentiles (Combined Dataset)

**Why Not Average Percentiles?**

Averaging P90 from each agent would be statistically incorrect:

**Wrong Approach:**
```
Agent 1 P90: 200ms
Agent 2 P90: 250ms
Agent 3 P90: 220ms

Average: (200+250+220)/3 = 223ms ❌ (incorrect)
```

**Correct Approach:**
```
Combine ALL samples from all agents: 30,000 total
Sort all 30,000 response times
Find 90th percentile of combined set
Result: 235ms ✓ (correct)
```

**Implementation:**
```typescript
const allMetrics = await prisma.testMetric.findMany({
  where: { testId: testId },
  orderBy: { responseTime: 'asc' }
});

const responseTimes = allMetrics.map(m => m.responseTime);
const p90 = calculatePercentile(responseTimes, 90);
```

## Frontend Components Summary

### Dashboard Page ([Dashboard.tsx](../frontend/src/pages/Dashboard.tsx))

**What it shows for multi-agent tests:**
1. ✓ Agent count badge ("🤖 3 agents")
2. ✓ Total threads ("1500 total threads")
3. ✓ Status ("Running", "Collating Results", "Completed")
4. ✓ Aggregated metrics in test list

**Does NOT show:** Individual agent status/progress

### Test Detail Page ([TestDetail.tsx](../frontend/src/pages/TestDetail.tsx))

**Live Dashboard (status = "running"):**
1. ✓ Aggregated metric cards (RT, TP, Error%, Threads)
2. ✓ Agent count badge
3. ✓ Real-time charts with combined data
4. ✓ Live transactions table (aggregated by label)
5. ✓ Progress bar (same for all agents)

**Completed Dashboard (status = "completed"):**
1. ✓ Aggregated summary cards
2. ✓ Percentile metrics (from combined dataset)
3. ✓ Per-agent breakdown table
4. ✓ Merged JTL file download
5. ✓ Historical charts (full test timeline)

**Collating Dashboard (status = "collating"):**
1. ✓ Info banner with spinner
2. ✓ Aggregated metrics already visible
3. ✓ Per-agent breakdown visible
4. ✗ Merged file not yet available

## Common Questions

### Q: Can I see individual agent metrics in real-time?

**A:** Not currently displayed in UI, but data is available in database.

The `TestMetric` table stores each agent's metrics with `label: agent-{agentId}`. You can query:

```sql
SELECT 
  timestamp,
  label as agentLabel,
  responseTime,
  threads
FROM test_metrics
WHERE testId = 'abc-123'
  AND label LIKE 'agent-%'
ORDER BY timestamp, label;
```

**Future Enhancement:** Could add a toggle to view per-agent live charts.

### Q: Why is response time sometimes higher in multi-agent tests?

**A:** This can happen due to:
1. **Backend Load**: More agents = more load on backend servers
2. **Network Saturation**: Exceeding network bandwidth
3. **Resource Contention**: Database/service bottlenecks
4. **Proper Behavior**: This is what you're testing for!

The weighted average correctly shows the degradation.

### Q: What if agents have different durations?

**A:** All agents run for the configured duration parameter:
- Agent 1: Starts 0s, runs 300s, completes at 300s
- Agent 2: Starts 2s, runs 300s, completes at 302s
- Agent 3: Starts 5s, runs 300s, completes at 305s

**Metrics aggregation:**
- Live metrics only include currently-running agents
- Final results include all completed agents
- Progress bar based on expected duration

### Q: Can I download individual agent JTL files?

**A:** Yes, they're stored in:
- **Database**: `TestAgent.resultFilePath`
- **MinIO**: `test-results/{testId}/agent-{n}.jtl`

**Access:** Download endpoint could be added to fetch specific agent file.

### Q: What happens if one agent fails?

**A:** The system gracefully handles partial failures:

1. **Other agents continue**: Unaffected agents complete normally
2. **Partial results**: Aggregation uses only completed agents
3. **Status**: Test marked as "completed" or "failed" based on majority
4. **Visibility**: Per-agent table shows which agents failed

**Example:**
```
Agent 1: ✓ Completed (10,000 samples)
Agent 2: ✓ Completed (10,000 samples)
Agent 3: ✗ Failed (0 samples)

Aggregated results: Based on 20,000 samples from Agents 1+2
Per-agent table: Shows Agent 3 with "failed" status
```

## Conclusion

The multi-agent metrics system provides:

1. **Real-Time Aggregation**: Live metrics combined using weighted averages and sums
2. **Accurate Representation**: Weighting ensures metrics reflect actual load distribution
3. **Complete Visibility**: Per-agent breakdown for detailed analysis
4. **Scalable Display**: Single aggregated view regardless of agent count
5. **Statistical Correctness**: Percentiles calculated from combined dataset

Users see a unified view of the distributed test while retaining the ability to drill down into per-agent performance when needed.
