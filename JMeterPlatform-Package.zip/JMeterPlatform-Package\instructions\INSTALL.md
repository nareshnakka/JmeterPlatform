# JMeter Platform - Installation Guide

Quick installation guide for the JMeter Performance Testing Platform.

## Universal Installer (Recommended)

The easiest way to install the platform is using the universal installer that lets you choose which components to install.

### Windows

```bash
# Run as Administrator
cd installers
universal-installer-windows.bat
```

### Linux

```bash
# Run with sudo
cd installers
chmod +x universal-installer-linux.sh
sudo ./universal-installer-linux.sh
```

## Installation Options

The universal installer will ask you to choose:

### 1. Server Only
- Backend API (Node.js + Express)
- Frontend Web UI (React)
- PostgreSQL Database
- Redis Cache
- MinIO Object Storage
- Best for: Central server installation

### 2. Agent Only
- JMeter execution agent
- JDK 11+
- Apache JMeter
- Best for: Distributed load generation nodes

### 3. Both Server + Agent
- Complete platform on one machine
- All server components + agent
- Best for: Development, testing, or single-machine deployments

## Installation Modes

Each component offers three installation modes:

### Express (Recommended)
- Quick setup with sensible defaults
- Minimal user input required
- Installation time: ~5-10 minutes

### Custom
- Configure each component
- Set custom ports, paths, credentials
- Installation time: ~10-15 minutes

### Developer
- Includes sample test data
- Debug mode enabled
- Development tools included
- Installation time: ~10-15 minutes

## What Gets Installed

### Server Installation Includes:
- ✅ Node.js 18+ (if not present)
- ✅ PostgreSQL 15+ (if not present)
- ✅ Redis 7+ (if not present)
- ✅ MinIO object storage
- ✅ Backend API server
- ✅ Frontend web application
- ✅ Windows Service / Systemd service
- ✅ Database schema and migrations
- ✅ Admin user account

### Agent Installation Includes:
- ✅ Python 3.8+ (if not present)
- ✅ JDK 11+ (if not present)
- ✅ Apache JMeter 5.5+ (if not present)
- ✅ JMeter agent service
- ✅ Windows Service / Systemd service
- ✅ Auto-connection to server

## Post-Installation

### Access the Platform

**Web Interface:**
```
http://localhost:5173
```

**Default Credentials:**
- Email: `admin@example.com`
- Password: `Admin@123`

### Verify Services

**Windows:**
```bash
# Check services in Services Manager (services.msc)
# Or use PowerShell:
Get-Service JMeterServer
Get-Service JMeterAgent
```

**Linux:**
```bash
# Check server status
systemctl status jmeter-server

# Check agent status
systemctl status jmeter-agent

# View logs
journalctl -u jmeter-server -f
journalctl -u jmeter-agent -f
```

### Server URLs

- **Frontend**: http://localhost:5173
- **Backend API**: http://localhost:3000
- **PostgreSQL**: localhost:5432
- **Redis**: localhost:6379
- **MinIO**: http://localhost:9000

### Configuration Files

**Server:**
- Backend: `backend/.env`
- Frontend: `frontend/.env`
- Database: PostgreSQL config

**Agent:**
- Configuration: `agent/.env`
- JMeter: Auto-detected or manual path

## Component-Specific Installers

If you prefer to run individual installers:

### Server Installation

**Windows:**
```bash
cd installers
server-installer-windows.bat
```

**Linux:**
```bash
cd installers
sudo ./server-installer-linux.sh
```

### Agent Installation

**Windows:**
```bash
cd installers
agent-installer-windows.bat
```

**Linux:**
```bash
cd installers
sudo ./agent-installer-linux.sh
```

## Manual Installation

For development or custom setups, see [GETTING_STARTED.md](GETTING_STARTED.md) for manual installation instructions.

## Troubleshooting

### Installation Fails

**Check administrator/root privileges:**
- Windows: Right-click → "Run as administrator"
- Linux: Use `sudo`

**Check disk space:**
- Minimum: 5 GB free space
- Recommended: 10+ GB

**Check network connectivity:**
- Required for downloading dependencies

### Services Won't Start

**Check logs:**
```bash
# Windows
Get-EventLog -LogName Application -Source JMeterServer -Newest 50

# Linux
journalctl -u jmeter-server -n 50
journalctl -u jmeter-agent -n 50
```

**Check ports are available:**
- 3000 (Backend API)
- 5173 (Frontend)
- 5432 (PostgreSQL)
- 6379 (Redis)
- 9000 (MinIO)

**Firewall:**
- Ensure ports are not blocked
- Add exceptions if needed

### Agent Can't Connect to Server

**Check server URL in agent config:**
```bash
# Edit agent/.env
SERVER_URL=http://your-server-ip:3000
```

**Verify network connectivity:**
```bash
# Test connection
curl http://your-server-ip:3000/health
```

**Check firewall rules:**
- Server port 3000 must be accessible
- WebSocket connections must be allowed

## Uninstallation

### Windows
```bash
# Stop services
Stop-Service JMeterServer
Stop-Service JMeterAgent

# Remove services
sc delete JMeterServer
sc delete JMeterAgent

# Delete installation directory
```

### Linux
```bash
# Stop and disable services
sudo systemctl stop jmeter-server jmeter-agent
sudo systemctl disable jmeter-server jmeter-agent

# Remove service files
sudo rm /etc/systemd/system/jmeter-server.service
sudo rm /etc/systemd/system/jmeter-agent.service

# Delete installation directory
sudo rm -rf /opt/jmeter-platform
```

## Support

For detailed documentation:
- [README.md](README.md) - Platform overview
- [GETTING_STARTED.md](GETTING_STARTED.md) - Developer setup
- [SETUP_WIZARD.md](SETUP_WIZARD.md) - Installer details
- [ARCHITECTURE.md](ARCHITECTURE.md) - System architecture

For issues and questions:
- GitHub Issues: [Report a problem](https://github.com/your-org/jmeter-platform/issues)
- Documentation: [Full docs](https://github.com/your-org/jmeter-platform/wiki)
