# API Reference

## Authentication

### POST /api/auth/register
Register a new user

**Request:**
```json
{
  "email": "user@example.com",
  "password": "password123",
  "role": "user"
}
```

**Response:** `201 Created`
```json
{
  "id": "uuid",
  "email": "user@example.com",
  "role": "user",
  "token": "jwt-token"
}
```

### POST /api/auth/login
Login user

**Request:**
```json
{
  "email": "user@example.com",
  "password": "password123"
}
```

**Response:** `200 OK`
```json
{
  "token": "jwt-token",
  "user": {
    "id": "uuid",
    "email": "user@example.com",
    "role": "user"
  }
}
```

## Scripts

### POST /api/scripts/upload
Upload JMX script

**Headers:**
```
Authorization: Bearer {token}
Content-Type: multipart/form-data
```

**Form Data:**
- `file`: JMX file
- `projectId`: Project UUID
- `name`: Script name

**Response:** `201 Created`
```json
{
  "id": "uuid",
  "name": "Load Test",
  "filePath": "scripts/project-id/script-id/v1/test.jmx",
  "version": 1
}
```

### GET /api/scripts
List all scripts

**Query Parameters:**
- `projectId`: Filter by project (optional)

**Response:** `200 OK`
```json
[
  {
    "id": "uuid",
    "name": "Load Test",
    "version": 1,
    "uploadedAt": "2026-01-25T10:00:00Z",
    "uploadedBy": "user@example.com"
  }
]
```

### POST /api/scripts/:id/dependencies
Upload dependency for script

**Form Data:**
- `file`: Dependency file (CSV, JAR, etc.)
- `type`: File type ('csv', 'jar', 'properties')

**Response:** `201 Created`

## Agents

### POST /api/agents/register
Register a load generator agent

**Request:**
```json
{
  "name": "agent-001",
  "hostname": "load-gen-1",
  "ipAddress": "192.168.1.100",
  "location": "us-east-1",
  "maxThreads": 1000
}
```

**Response:** `201 Created`
```json
{
  "id": "uuid",
  "name": "agent-001",
  "status": "online",
  "apiKey": "agent-api-key"
}
```

### GET /api/agents
List all agents

**Response:** `200 OK`
```json
[
  {
    "id": "uuid",
    "name": "agent-001",
    "hostname": "load-gen-1",
    "location": "us-east-1",
    "status": "online",
    "maxThreads": 1000,
    "lastHeartbeat": "2026-01-25T10:00:00Z"
  }
]
```

### PUT /api/agents/:id/heartbeat
Update agent heartbeat

**Response:** `200 OK`

### GET /api/agents/:id/pending-tests
Get pending tests for agent

**Response:** `200 OK`
```json
[
  {
    "id": "test-uuid",
    "scriptId": "script-uuid",
    "threads": 100,
    "duration": 300
  }
]
```

## Tests

### POST /api/tests/start
Start a new test

**Request:**
```json
{
  "projectId": "uuid",
  "scriptId": "uuid",
  "name": "Load Test - 100 users",
  "totalThreads": 100,
  "durationSeconds": 300,
  "agents": [
    {
      "agentId": "uuid",
      "threads": 50
    },
    {
      "agentId": "uuid",
      "threads": 50
    }
  ]
}
```

**Response:** `201 Created`
```json
{
  "id": "uuid",
  "status": "pending",
  "startedAt": "2026-01-25T10:00:00Z"
}
```

### GET /api/tests/:id/status
Get test status

**Response:** `200 OK`
```json
{
  "id": "uuid",
  "status": "running",
  "startedAt": "2026-01-25T10:00:00Z",
  "progress": 45,
  "agents": [
    {
      "agentId": "uuid",
      "name": "agent-001",
      "status": "running",
      "currentThreads": 50
    }
  ]
}
```

### POST /api/tests/:id/stop
Stop a running test

**Response:** `200 OK`

### GET /api/tests/:id/metrics/realtime
Get real-time metrics (Server-Sent Events)

**Response:** Stream of events
```
event: metrics
data: {"timestamp": 1234567890, "throughput": 150.5, "avgResponseTime": 234, "errorRate": 0.02}

event: metrics
data: {"timestamp": 1234567895, "throughput": 152.3, "avgResponseTime": 230, "errorRate": 0.01}
```

### POST /api/tests/:id/results
Upload test results (called by agents)

**Form Data:**
- `result`: JTL file
- `agentId`: Agent UUID

**Response:** `201 Created`

### GET /api/tests/:id/results
Get test results

**Response:** `200 OK`
```json
{
  "testId": "uuid",
  "status": "completed",
  "startedAt": "2026-01-25T10:00:00Z",
  "completedAt": "2026-01-25T10:05:00Z",
  "totalSamples": 15000,
  "errorCount": 150,
  "errorRate": 0.01,
  "avgResponseTime": 234.5,
  "minResponseTime": 45,
  "maxResponseTime": 1250,
  "throughput": 50.5,
  "percentiles": {
    "p50": 220,
    "p90": 450,
    "p95": 650,
    "p99": 980
  },
  "agentResults": [
    {
      "agentId": "uuid",
      "agentName": "agent-001",
      "samples": 7500,
      "errorCount": 75
    }
  ]
}
```

### GET /api/tests/:id/export/csv
Export test results to CSV

**Query Parameters:**
- `type`: Export type ('summary', 'detailed', 'metrics') - default: 'summary'

**Response:** `200 OK`
```
Content-Type: text/csv
Content-Disposition: attachment; filename="test-results-{testId}.csv"

timestamp,label,responseTime,success,errorMsg,bytes,sentBytes,latency,threads
2026-01-25 10:00:01,HTTP Request,234,true,,1024,512,230,100
2026-01-25 10:00:02,HTTP Request,245,true,,1024,512,241,100
...
```

### GET /api/tests/:id/export/json
Export test results to JSON

**Response:** `200 OK`
```
Content-Type: application/json
Content-Disposition: attachment; filename="test-results-{testId}.json"
```

### POST /api/tests/compare
Compare multiple tests

**Request:**
```json
{
  "testIds": ["uuid1", "uuid2", "uuid3"],
  "metrics": ["avgResponseTime", "throughput", "errorRate", "p95"]
}
```

**Response:** `200 OK`
```json
{
  "comparison": {
    "tests": [
      {
        "id": "uuid1",
        "name": "Test 1",
        "startedAt": "2026-01-25T10:00:00Z",
        "metrics": {
          "avgResponseTime": 234.5,
          "throughput": 50.5,
          "errorRate": 0.01,
          "p95": 650
        }
      },
      {
        "id": "uuid2",
        "name": "Test 2",
        "startedAt": "2026-01-24T15:00:00Z",
        "metrics": {
          "avgResponseTime": 189.3,
          "throughput": 65.2,
          "errorRate": 0.005,
          "p95": 520
        }
      }
    ],
    "summary": {
      "bestAvgResponseTime": "uuid2",
      "bestThroughput": "uuid2",
      "lowestErrorRate": "uuid2"
    }
  }
}
```

### POST /api/tests/comparisons
Save test comparison

**Request:**
```json
{
  "name": "Weekly Performance Comparison",
  "description": "Comparing last 3 test runs",
  "testIds": ["uuid1", "uuid2", "uuid3"]
}
```

**Response:** `201 Created`
```json
{
  "id": "comparison-uuid",
  "name": "Weekly Performance Comparison",
  "testIds": ["uuid1", "uuid2", "uuid3"],
  "createdAt": "2026-01-25T10:00:00Z"
}
```

### GET /api/tests/comparisons
List saved comparisons

**Response:** `200 OK`
```json
[
  {
    "id": "uuid",
    "name": "Weekly Performance Comparison",
    "testCount": 3,
    "createdAt": "2026-01-25T10:00:00Z"
  }
]
```

### GET /api/tests/comparisons/:id
Get comparison details

**Response:** `200 OK`

### GET /api/tests/:id/metrics
Get time-series metrics for test tracking

**Query Parameters:**
- `interval`: Time interval in seconds (default: 5)

**Response:** `200 OK`
```json
{
  "testId": "uuid",
  "metrics": [
    {
      "timestamp": "2026-01-25T10:00:00Z",
      "activeThreads": 100,
      "throughput": 50.5,
      "avgResponseTime": 234,
      "errorRate": 0.01
    },
    {
      "timestamp": "2026-01-25T10:00:05Z",
      "activeThreads": 100,
      "throughput": 51.2,
      "avgResponseTime": 230,
      "errorRate": 0.008
    }
  ]
}
```

### POST /api/tests/:id/tags
Add tags to test

**Request:**
```json
{
  "tags": ["production", "baseline", "v2.0"]
}
```

**Response:** `201 Created`

### GET /api/tests/:id/tags
Get test tags

**Response:** `200 OK`
```json
{
  "tags": ["production", "baseline", "v2.0"]
}
```

### POST /api/tests/:id/notes
Add note to test

**Request:**
```json
{
  "note": "Test completed successfully. Database optimization showed 30% improvement."
}
```

**Response:** `201 Created`

### GET /api/tests/:id/notes
Get test notes

**Response:** `200 OK`
```json
[
  {
    "id": "uuid",
    "userId": "user-uuid",
    "userName": "John Doe",
    "note": "Test completed successfully...",
    "createdAt": "2026-01-25T10:00:00Z"
  }
]
```

### GET /api/tests/search
Search and filter tests

**Query Parameters:**
- `projectId`: Filter by project
- `status`: Filter by status (pending, running, completed, failed)
- `tags`: Comma-separated tags
- `dateFrom`: Start date (ISO 8601)
- `dateTo`: End date (ISO 8601)
- `limit`: Results limit (default: 50)
- `offset`: Pagination offset

**Response:** `200 OK`
```json
{
  "tests": [...],
  "total": 150,
  "limit": 50,
  "offset": 0
}
```

## Projects

### POST /api/projects
Create a new project

**Request:**
```json
{
  "name": "E-commerce Load Tests"
}
```

**Response:** `201 Created`
```json
{
  "id": "uuid",
  "name": "E-commerce Load Tests",
  "ownerId": "user-uuid",
  "createdAt": "2026-01-25T10:00:00Z"
}
```

### GET /api/projects
List all projects

**Response:** `200 OK`
```json
[
  {
    "id": "uuid",
    "name": "E-commerce Load Tests",
    "testsCount": 25,
    "scriptsCount": 5,
    "createdAt": "2026-01-25T10:00:00Z"
  }
]
```

## WebSocket Events

### Connection
```javascript
const ws = new WebSocket('ws://localhost:3000/ws?token=jwt-token');
```

### Subscribe to test
```json
{
  "type": "subscribe",
  "testId": "uuid"
}
```

### Receive metrics
```json
{
  "type": "metrics",
  "testId": "uuid",
  "timestamp": 1234567890,
  "data": {
    "currentThreads": 100,
    "throughput": 150.5,
    "avgResponseTime": 234,
    "errorRate": 0.02,
    "activeConnections": 95
  }
}
```

### Receive status update
```json
{
  "type": "status",
  "testId": "uuid",
  "status": "completed",
  "message": "Test completed successfully"
}
```

## Error Responses

### 400 Bad Request
```json
{
  "error": "Validation error",
  "details": {
    "field": "email",
    "message": "Invalid email format"
  }
}
```

### 401 Unauthorized
```json
{
  "error": "Unauthorized",
  "message": "Invalid or expired token"
}
```

### 404 Not Found
```json
{
  "error": "Not found",
  "message": "Resource not found"
}
```

### 500 Internal Server Error
```json
{
  "error": "Internal server error",
  "message": "An unexpected error occurred"
}
```
