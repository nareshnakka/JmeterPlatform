import { createReadStream, createWriteStream, promises as fs } from 'fs';
import { pipeline } from 'stream/promises';
import * as readline from 'readline';
import { Client as MinioClient } from 'minio';
import { PrismaClient } from '@prisma/client';
import path from 'path';
import os from 'os';

/**
 * Merges multiple JTL files from different agents into a single combined JTL file
 * Handles large files efficiently using streams
 */
export async function mergeJtlFiles(
  minioClient: MinioClient,
  testId: string,
  agentJtlPaths: string[]
): Promise<string> {
  console.log(`[JTL Merge] Starting merge for test ${testId} with ${agentJtlPaths.length} agent files`);
  
  if (agentJtlPaths.length === 0) {
    throw new Error('No JTL files to merge');
  }
  
  // Single agent - just use that file directly
  if (agentJtlPaths.length === 1) {
    console.log(`[JTL Merge] Only one agent file, using directly: ${agentJtlPaths[0]}`);
    return agentJtlPaths[0];
  }
  
  const bucketName = process.env.MINIO_BUCKET || 'jmeter-results';
  const tempDir = path.join(os.tmpdir(), 'jtl-merge', testId);
  await fs.mkdir(tempDir, { recursive: true });
  
  try {
    // Download all agent JTL files to temp directory
    const tempFiles: string[] = [];
    for (let i = 0; i < agentJtlPaths.length; i++) {
      const agentPath = agentJtlPaths[i];
      const tempFile = path.join(tempDir, `agent-${i}.jtl`);
      
      console.log(`[JTL Merge] Downloading ${agentPath} from MinIO...`);
      await downloadFromMinio(minioClient, bucketName, agentPath, tempFile);
      tempFiles.push(tempFile);
    }
    
    // Create merged file in temp directory
    const mergedTempFile = path.join(tempDir, 'merged.jtl');
    await mergeJtlFilesStream(tempFiles, mergedTempFile);
    
    // Upload merged file to MinIO
    const mergedMinioPath = `test-results/${testId}/merged.jtl`;
    console.log(`[JTL Merge] Uploading merged file to MinIO: ${mergedMinioPath}`);
    
    const stats = await fs.stat(mergedTempFile);
    await minioClient.fPutObject(
      bucketName,
      mergedMinioPath,
      mergedTempFile,
      {
        'Content-Type': 'text/csv',
        'Content-Length': stats.size
      }
    );
    
    console.log(`[JTL Merge] Merge completed successfully, size: ${(stats.size / 1024 / 1024).toFixed(2)}MB`);
    
    // Clean up temp files
    await fs.rm(tempDir, { recursive: true, force: true });
    
    return mergedMinioPath;
  } catch (error) {
    // Clean up on error
    await fs.rm(tempDir, { recursive: true, force: true }).catch(() => {});
    throw error;
  }
}

/**
 * Download file from MinIO to local path
 */
async function downloadFromMinio(
  minioClient: MinioClient,
  bucket: string,
  objectPath: string,
  localPath: string
): Promise<void> {
  const dataStream = await minioClient.getObject(bucket, objectPath);
  const fileStream = createWriteStream(localPath);
  
  await pipeline(dataStream, fileStream);
}

/**
 * Merge multiple JTL files using streaming for memory efficiency
 * Preserves CSV header from first file only
 */
async function mergeJtlFilesStream(inputFiles: string[], outputFile: string): Promise<void> {
  const outputStream = createWriteStream(outputFile);
  let headerWritten = false;
  let totalLines = 0;
  
  try {
    for (let i = 0; i < inputFiles.length; i++) {
      const inputFile = inputFiles[i];
      console.log(`[JTL Merge] Processing file ${i + 1}/${inputFiles.length}: ${inputFile}`);
      
      const fileStream = createReadStream(inputFile);
      const rl = readline.createInterface({
        input: fileStream,
        crlfDelay: Infinity
      });
      
      let isFirstLine = true;
      let linesInFile = 0;
      
      for await (const line of rl) {
        if (isFirstLine) {
          // Write header only from first file
          if (!headerWritten) {
            outputStream.write(line + '\n');
            headerWritten = true;
          }
          isFirstLine = false;
        } else if (line.trim()) {
          // Write data lines from all files
          outputStream.write(line + '\n');
          linesInFile++;
          totalLines++;
        }
      }
      
      console.log(`[JTL Merge] Processed ${linesInFile.toLocaleString()} lines from agent ${i + 1}`);
    }
    
    outputStream.end();
    
    // Wait for write stream to finish
    await new Promise<void>((resolve, reject) => {
      outputStream.on('finish', () => resolve());
      outputStream.on('error', reject);
    });
    
    console.log(`[JTL Merge] Total lines merged: ${totalLines.toLocaleString()}`);
  } catch (error) {
    outputStream.destroy();
    throw error;
  }
}

/**
 * Start background job to merge JTL files
 * This runs asynchronously without blocking the response
 */
export function startJtlMergeJob(
  prisma: PrismaClient,
  minioClient: MinioClient,
  testId: string,
  agentJtlPaths: string[]
): void {
  // Run merge in background
  (async () => {
    try {
      // Update status to 'collating'
      await prisma.test.update({
        where: { id: testId },
        data: { status: 'collating' }
      });
      
      console.log(`[JTL Merge] Background job started for test ${testId}`);
      
      // Perform the merge
      const mergedPath = await mergeJtlFiles(minioClient, testId, agentJtlPaths);
      
      // Update test with merged file path and mark as completed
      await prisma.test.update({
        where: { id: testId },
        data: {
          status: 'completed',
          mergedJtlPath: mergedPath
        }
      });
      
      // Also update the TestResult with the merged path
      await prisma.testResult.updateMany({
        where: { testId },
        data: { resultFilePath: mergedPath }
      });
      
      console.log(`[JTL Merge] Background job completed for test ${testId}`);
    } catch (error) {
      console.error(`[JTL Merge] Background job failed for test ${testId}:`, error);
      
      // Mark test as completed even if merge fails (we still have individual agent files)
      await prisma.test.update({
        where: { id: testId },
        data: { status: 'completed' }
      }).catch(err => console.error('Failed to update test status after merge error:', err));
    }
  })();
}
