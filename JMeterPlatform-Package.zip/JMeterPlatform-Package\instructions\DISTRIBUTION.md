# JMeter Platform - Distribution Package

## Quick Start for End Users

### Windows Users

1. **Extract the ZIP file**
   ```
   Right-click → Extract All
   ```

2. **Run the installer as Administrator**
   ```
   Right-click INSTALL.bat → Run as administrator
   ```

3. **Follow the wizard**
   - Choose components (Server, Agent, or Both)
   - Select installation mode (Express recommended)
   - Wait for completion

4. **Access the platform**
   - Open browser: http://localhost:5173
   - Login: admin@example.com / Admin@123

---

### Linux Users

1. **Extract the archive**
   ```bash
   tar -xzf jmeter-platform-installer.tar.gz
   cd jmeter-platform-package
   ```

2. **Run the installer**
   ```bash
   chmod +x install.sh
   sudo ./install.sh
   ```

3. **Follow the wizard**
   - Choose components (Server, Agent, or Both)
   - Select installation mode (Express recommended)
   - Wait for completion

4. **Access the platform**
   - Open browser: http://localhost:5173
   - Login: admin@example.com / Admin@123

---

## What's Included

✅ Complete source code (Backend, Frontend, Agent)
✅ Installation wizards (Windows & Linux)
✅ Auto-installer for one-click setup
✅ All documentation
✅ Configuration templates
✅ Quick-start scripts

## System Requirements

### Minimum
- **OS**: Windows 10+ or Linux (Ubuntu 20.04+, CentOS 8+)
- **RAM**: 4 GB
- **Disk**: 5 GB free space
- **Internet**: Required for dependency downloads

### Recommended
- **RAM**: 8 GB+
- **Disk**: 10 GB+ free space
- **CPU**: 4+ cores

## Installation Modes

### Express (Recommended)
- Quick setup with sensible defaults
- Minimal user input
- ~5-10 minutes

### Custom
- Configure each component
- Custom ports, paths, credentials
- ~10-15 minutes

### Developer
- Includes sample data
- Debug mode enabled
- ~10-15 minutes

## Components

### Server (Backend + Frontend)
Installs:
- Node.js 18+
- PostgreSQL database
- Redis cache
- MinIO storage
- Web interface

**Ports Used**: 3000 (API), 5173 (Frontend), 5432 (DB), 6379 (Redis), 9000 (MinIO)

### Agent (JMeter Execution)
Installs:
- Python 3.8+
- JDK 11+
- Apache JMeter
- Execution agent

**Ports Used**: Agent connects to server on port 3000

### Both
Complete platform on one machine (Server + Agent)

## Post-Installation

### Verify Services

**Windows:**
```powershell
Get-Service JMeterServer
Get-Service JMeterAgent
```

**Linux:**
```bash
systemctl status jmeter-server
systemctl status jmeter-agent
```

### Access Web Interface
```
http://localhost:5173
```

Default credentials:
- Email: admin@example.com
- Password: Admin@123

### View Logs

**Windows:**
- Check installation directory logs folder

**Linux:**
```bash
journalctl -u jmeter-server -f
journalctl -u jmeter-agent -f
```

## Troubleshooting

### Installation Fails
- Ensure running as Administrator/root
- Check disk space (5+ GB required)
- Verify internet connection
- Check antivirus isn't blocking

### Service Won't Start
- Check ports are available (3000, 5173, 5432, 6379, 9000)
- Review logs for errors
- Verify firewall settings

### Can't Access Web Interface
- Ensure server service is running
- Check firewall rules
- Try http://127.0.0.1:5173 instead

## Uninstallation

### Windows
```powershell
# Stop services
Stop-Service JMeterServer, JMeterAgent

# Remove services
sc delete JMeterServer
sc delete JMeterAgent

# Delete installation folder
```

### Linux
```bash
# Stop and disable
sudo systemctl stop jmeter-server jmeter-agent
sudo systemctl disable jmeter-server jmeter-agent

# Remove services
sudo rm /etc/systemd/system/jmeter-*.service

# Delete installation
sudo rm -rf /opt/jmeter-platform
```

## Support

- Documentation: See included markdown files
- Issues: Report via GitHub
- Configuration: See SETUP_WIZARD.md

## License

See LICENSE file for details.

---

**For detailed documentation, see:**
- `README.md` - Platform overview
- `INSTALL.md` - Installation guide
- `GETTING_STARTED.md` - Quick start
- `SETUP_WIZARD.md` - Wizard details
