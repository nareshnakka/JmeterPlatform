# Platform Support & Cross-Platform Compatibility

## Supported Platforms

### Server

| Platform | Version | Status | Installer |
|----------|---------|--------|-----------|
| **Windows Server** | 2019, 2022 | ✅ Fully Supported | `server-installer-windows.bat` |
| **Windows Desktop** | 10, 11 | ✅ Fully Supported | `server-installer-windows.bat` |
| **Ubuntu** | 20.04, 22.04, 24.04 | ✅ Fully Supported | `server-installer-linux.sh` |
| **Debian** | 11, 12 | ✅ Fully Supported | `server-installer-linux.sh` |
| **CentOS/RHEL** | 8, 9 | ✅ Fully Supported | `server-installer-linux.sh` |
| **Rocky Linux** | 8, 9 | ✅ Fully Supported | `server-installer-linux.sh` |
| **Amazon Linux** | 2, 2023 | ✅ Fully Supported | `server-installer-linux.sh` |

### Agent

| Platform | Version | Status | Installer |
|----------|---------|--------|-----------|
| **Windows Server** | 2016+, 2019, 2022 | ✅ Fully Supported | `agent-installer-windows.bat` |
| **Windows Desktop** | 10, 11 | ✅ Fully Supported | `agent-installer-windows.bat` |
| **Ubuntu** | 18.04, 20.04, 22.04, 24.04 | ✅ Fully Supported | `agent-installer-linux.sh` |
| **Debian** | 10, 11, 12 | ✅ Fully Supported | `agent-installer-linux.sh` |
| **CentOS/RHEL** | 7, 8, 9 | ✅ Fully Supported | `agent-installer-linux.sh` |
| **Rocky Linux** | 8, 9 | ✅ Fully Supported | `agent-installer-linux.sh` |
| **Amazon Linux** | 2, 2023 | ✅ Fully Supported | `agent-installer-linux.sh` |

## Open-Source Technologies

All technologies used are 100% open-source and free:

### Server Components

| Component | Technology | License | Platform Support |
|-----------|-----------|---------|------------------|
| **Runtime** | Node.js 18 LTS | MIT | Windows, Linux |
| **Database** | PostgreSQL 15 | PostgreSQL License | Windows, Linux |
| **Cache** | Redis 7.2 | BSD 3-Clause | Windows, Linux |
| **Storage** | MinIO | AGPL v3 | Windows, Linux |
| **Frontend** | React 18 | MIT | Cross-platform |
| **Backend Framework** | Express.js | MIT | Cross-platform |
| **ORM** | Prisma | Apache 2.0 | Cross-platform |
| **Package Manager** | npm | Artistic 2.0 | Cross-platform |

### Agent Components

| Component | Technology | License | Platform Support |
|-----------|-----------|---------|------------------|
| **Runtime** | Python 3.11 | PSF | Windows, Linux |
| **JVM** | Eclipse Temurin (OpenJDK) 17 | GPL v2 + CE | Windows, Linux |
| **Load Testing** | Apache JMeter 5.6.3 | Apache 2.0 | Windows, Linux, macOS |
| **HTTP Client** | requests | Apache 2.0 | Cross-platform |
| **System Monitor** | psutil | BSD 3-Clause | Cross-platform |

## Platform-Specific Features

### Windows

**Installation:**
- Interactive GUI wizard (`.bat` file)
- Silent installation support
- Chocolatey package manager integration
- Windows Services integration
- Event Log support
- PowerShell scripts

**Services:**
```batch
# Server services
net start JMeterPlatformBackend
net start postgresql-x64-15
net start Redis
net start minio

# Agent service
net start JMeterAgent
```

**Paths:**
```
Server:  C:\JMeterPlatform\
Agent:   C:\JMeterAgent\
Logs:    C:\JMeterPlatform\logs\ or C:\JMeterAgent\logs\
Config:  .env files in installation directory
```

### Linux

**Installation:**
- Interactive terminal wizard
- Silent installation support
- APT/YUM package manager support
- systemd service integration
- syslog integration
- Bash scripts

**Services:**
```bash
# Server services
sudo systemctl start jmeter-platform-backend
sudo systemctl start jmeter-platform-frontend
sudo systemctl start postgresql
sudo systemctl start redis
sudo systemctl start minio

# Agent service
sudo systemctl start jmeter-agent
```

**Paths:**
```
Server:  /opt/jmeter-platform/
Agent:   /opt/jmeter-agent/
Logs:    /var/log/jmeter-platform/ or /var/log/jmeter-agent/
Config:  /etc/jmeter-platform/ or /etc/jmeter-agent/
Data:    /var/lib/jmeter-platform/
```

## Cross-Platform Features

### Agent Auto-Detection

The agent automatically detects Java and JMeter installations on both platforms:

**Windows:**
```
Common paths searched:
- C:\Program Files\Eclipse Adoptium\
- C:\Program Files\Java\
- C:\Program Files (x86)\Java\
- JAVA_HOME environment variable
- C:\apache-jmeter\
- C:\Program Files\apache-jmeter\
- JMETER_HOME environment variable
```

**Linux:**
```
Common paths searched:
- /usr/lib/jvm/
- /usr/java/
- /opt/java/
- JAVA_HOME environment variable
- /opt/apache-jmeter/
- /opt/jmeter/
- /usr/local/jmeter/
- JMETER_HOME environment variable
```

### Network Configuration

Both platforms support:
- IPv4 and IPv6
- HTTP and HTTPS
- WebSocket connections
- Proxy configuration
- Firewall configuration

### File Paths

Cross-platform path handling:
```python
# Agent uses os.path for cross-platform compatibility
import os
work_dir = os.path.join(self.work_dir, test_id)
jmeter_bin = os.path.join(self.jmeter_home, 'bin', 'jmeter')

# Windows: C:\JMeterAgent\work\test-123
# Linux:   /opt/jmeter-agent/work/test-123
```

## Installation Requirements

### Server Requirements

**Windows:**
- Windows 10/11 or Server 2019+
- 8 GB RAM (16 GB recommended)
- 50 GB disk space
- .NET Framework 4.8+ (for PostgreSQL)
- PowerShell 5.1+

**Linux:**
- Ubuntu 20.04+, Debian 11+, RHEL 8+
- 8 GB RAM (16 GB recommended)
- 50 GB disk space
- systemd
- bash 4.0+

### Agent Requirements

**Windows:**
- Windows 10/11 or Server 2016+
- 4 GB RAM (8 GB recommended)
- 20 GB disk space
- PowerShell 5.1+

**Linux:**
- Ubuntu 18.04+, Debian 10+, RHEL 7+
- 4 GB RAM (8 GB recommended)
- 20 GB disk space
- systemd or init.d
- bash 4.0+

## Package Managers

### Windows

**Chocolatey** (automatically installed):
```batch
choco install nodejs-lts -y
choco install postgresql15 -y
choco install redis-64 -y
choco install minio -y
choco install python311 -y
choco install openjdk17 -y
```

### Linux (Ubuntu/Debian)

**APT:**
```bash
apt-get install nodejs
apt-get install postgresql-15
apt-get install redis-server
apt-get install python3.11
apt-get install openjdk-17-jdk
```

### Linux (RHEL/CentOS)

**YUM/DNF:**
```bash
yum install nodejs
yum install postgresql15-server
yum install redis
yum install python3.11
yum install java-17-openjdk
```

## File System Compatibility

### Supported File Systems

**Windows:**
- NTFS (recommended)
- ReFS
- exFAT (not recommended for production)

**Linux:**
- ext4 (recommended)
- XFS
- Btrfs
- ZFS

### Special Characters

All file operations handle:
- Unicode characters
- Spaces in paths
- Special characters (Windows: `<>:"|?*`, Linux: `/`)
- Long path names (Windows: enable long paths in registry)

## Security

### Windows

- Windows Defender compatibility
- Firewall rules auto-configured
- Windows Event Log integration
- User Account Control (UAC) support
- Service isolation

### Linux

- SELinux support (contexts configured)
- AppArmor support (profiles included)
- iptables/ufw/firewalld configuration
- systemd security features
- User permission management

## Performance

### Process Management

**Windows:**
- Windows Services for background processes
- Process priority configuration
- CPU affinity support
- Memory limits via Job Objects

**Linux:**
- systemd services with resource limits
- cgroups integration
- CPU affinity (taskset)
- Memory limits (cgroup)
- Nice/ionice support

### Monitoring

**Windows:**
- Performance Monitor integration
- Windows Event Log
- Task Manager metrics
- Custom performance counters

**Linux:**
- systemd journal
- syslog integration
- top/htop metrics
- prometheus exporters

## Networking

### Firewall Configuration

**Windows Firewall:**
```batch
# Server
netsh advfirewall firewall add rule name="JMeter Platform Backend" dir=in action=allow protocol=TCP localport=3000
netsh advfirewall firewall add rule name="JMeter Platform Frontend" dir=in action=allow protocol=TCP localport=8080

# Agent (if needed)
netsh advfirewall firewall add rule name="JMeter Agent" dir=in action=allow program="C:\JMeterAgent\venv\Scripts\python.exe"
```

**Linux (UFW):**
```bash
# Server
sudo ufw allow 3000/tcp
sudo ufw allow 8080/tcp

# Agent (usually only outbound)
```

**Linux (firewalld):**
```bash
# Server
sudo firewall-cmd --permanent --add-port=3000/tcp
sudo firewall-cmd --permanent --add-port=8080/tcp
sudo firewall-cmd --reload
```

## Upgrade Path

### Windows to Linux (Migration)

1. Export database: `pg_dump` from Windows PostgreSQL
2. Install Linux server
3. Import database: `psql` on Linux
4. Update agent connections
5. Migrate file storage (MinIO bucket sync)

### Mixed Environment

Supported configurations:
- ✅ Windows Server + Linux Agents
- ✅ Linux Server + Windows Agents
- ✅ Windows Server + Windows Agents
- ✅ Linux Server + Linux Agents
- ✅ Mixed agents (some Windows, some Linux)

## Known Platform Differences

### Path Separators
- Windows: `\` (backslash)
- Linux: `/` (forward slash)
- Agent code uses `os.path.join()` for compatibility

### Line Endings
- Windows: CRLF (`\r\n`)
- Linux: LF (`\n`)
- Git configured with `autocrlf=true` on Windows

### Case Sensitivity
- Windows: Case-insensitive file system
- Linux: Case-sensitive file system
- Use consistent casing in all file references

### Environment Variables
- Windows: `%VARIABLE%` or `$env:VARIABLE`
- Linux: `$VARIABLE`
- Agent reads from `.env` file on both platforms

### Service Management
- Windows: `net start/stop SERVICE`
- Linux: `systemctl start/stop SERVICE`
- Different service definition files

## Testing Across Platforms

### Automated Testing

Run tests on both platforms:
```bash
# Windows
pytest tests/ --platform=windows

# Linux
pytest tests/ --platform=linux
```

### Docker Testing

Test both platforms using Docker:
```bash
# Windows containers
docker run -it mcr.microsoft.com/windows/servercore:ltsc2022

# Linux containers
docker run -it ubuntu:22.04
```

## Support & Compatibility Matrix

| Feature | Windows | Linux | Notes |
|---------|---------|-------|-------|
| Server Installation | ✅ | ✅ | Full support |
| Agent Installation | ✅ | ✅ | Full support |
| Silent Installation | ✅ | ✅ | Command-line flags |
| Auto-Update | ✅ | ✅ | Future feature |
| Service Management | ✅ | ✅ | Platform-native |
| Log Rotation | ✅ | ✅ | Different mechanisms |
| Resource Limits | ✅ | ✅ | Platform-specific APIs |
| IPv6 Support | ✅ | ✅ | Full support |
| Container Support | ⚠️ | ✅ | Windows containers experimental |
| ARM64 Support | ❌ | ⚠️ | Linux ARM64 experimental |

Legend:
- ✅ Fully supported
- ⚠️ Experimental/Limited
- ❌ Not supported

## License Compliance

All bundled software is open-source:

- ✅ Commercial use allowed
- ✅ Modification allowed
- ✅ Distribution allowed
- ✅ No proprietary dependencies
- ✅ No vendor lock-in

## Getting Help

Platform-specific issues:
- Windows: Check Windows Event Viewer
- Linux: Check `journalctl -u SERVICE_NAME`
- Both: Check application logs in installation directory
