import * as Minio from 'minio';
import * as fs from 'fs';
import * as path from 'path';

// Check if we should use local filesystem fallback
const USE_LOCAL_STORAGE = process.env.USE_LOCAL_STORAGE === 'true';
const LOCAL_STORAGE_DIR = process.env.LOCAL_STORAGE_DIR || './minio-data';

export const minioClient = new Minio.Client({
  endPoint: process.env.MINIO_ENDPOINT || 'localhost',
  port: parseInt(process.env.MINIO_PORT || '9000'),
  useSSL: process.env.MINIO_USE_SSL === 'true',
  accessKey: process.env.MINIO_ACCESS_KEY || 'minioadmin',
  secretKey: process.env.MINIO_SECRET_KEY || 'minioadmin'
});

export const BUCKET_NAME = process.env.MINIO_BUCKET || 'jmeter-files';

let minioAvailable = false;

export async function initializeMinIO(): Promise<void> {
  try {
    const exists = await minioClient.bucketExists(BUCKET_NAME);
    if (!exists) {
      await minioClient.makeBucket(BUCKET_NAME, 'us-east-1');
      console.log(`Bucket "${BUCKET_NAME}" created successfully`);
    }
    minioAvailable = true;
  } catch (error) {
    // MinIO not available - will use local storage fallback
    minioAvailable = false;
    
    // Create local storage directory
    if (!fs.existsSync(LOCAL_STORAGE_DIR)) {
      fs.mkdirSync(LOCAL_STORAGE_DIR, { recursive: true });
      console.log(`Created local storage directory: ${LOCAL_STORAGE_DIR}`);
    }
    
    throw error;
  }
}

export function isMinIOAvailable(): boolean {
  return minioAvailable;
}

export async function uploadFile(
  filePath: string,
  buffer: Buffer,
  contentType: string
): Promise<string> {
  // Use local filesystem if MinIO not available
  if (!minioAvailable || USE_LOCAL_STORAGE) {
    const fullPath = path.join(LOCAL_STORAGE_DIR, filePath);
    const dir = path.dirname(fullPath);
    
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    
    fs.writeFileSync(fullPath, buffer);
    return filePath;
  }
  
  // Use MinIO
  try {
    await minioClient.putObject(BUCKET_NAME, filePath, buffer, buffer.length, {
      'Content-Type': contentType
    });
    return filePath;
  } catch (error) {
    // Don't log full error stack - will be handled by caller
    throw error;
  }
}

export async function downloadFile(filePath: string): Promise<Buffer> {
  // Use local filesystem if MinIO not available
  if (!minioAvailable || USE_LOCAL_STORAGE) {
    const fullPath = path.join(LOCAL_STORAGE_DIR, filePath);
    if (!fs.existsSync(fullPath)) {
      throw new Error(`File not found: ${filePath}`);
    }
    return fs.readFileSync(fullPath);
  }
  
  // Use MinIO
  try {
    const stream = await minioClient.getObject(BUCKET_NAME, filePath);
    const chunks: Buffer[] = [];
    
    return new Promise((resolve, reject) => {
      stream.on('data', (chunk) => chunks.push(chunk));
      stream.on('end', () => resolve(Buffer.concat(chunks)));
      stream.on('error', reject);
    });
  } catch (error) {
    // Don't log full error stack - will be handled by caller
    throw error;
  }
}

export async function deleteFile(filePath: string): Promise<void> {
  // Use local filesystem if MinIO not available
  if (!minioAvailable || USE_LOCAL_STORAGE) {
    const fullPath = path.join(LOCAL_STORAGE_DIR, filePath);
    if (fs.existsSync(fullPath)) {
      fs.unlinkSync(fullPath);
    }
    return;
  }
  
  // Use MinIO
  try {
    await minioClient.removeObject(BUCKET_NAME, filePath);
  } catch (error) {
    // Don't log full error stack - will be handled by caller
    throw error;
  }
}
