# System Architecture

## Architecture Overview

This document details the architecture for the JMeter Testing Platform.

## Components

### 1. Frontend Application

**Purpose**: Web-based user interface for managing tests and viewing results

**Key Responsibilities**:
- User authentication and authorization
- Test script upload and management
- Load generator configuration
- Test execution control
- Real-time metrics visualization
- Result analysis and reporting

**Technology**: React + TypeScript + Material-UI

**Key Pages**:
- Dashboard (test overview, recent runs)
- Scripts (upload, manage JMX files)
- Load Generators (register, configure agents)
- Test Execution (start, monitor, control)
- Results (view, compare, export)
- Settings (user, projects, API keys)

### 2. Backend API Server

**Purpose**: Central orchestration and business logic

**Key Responsibilities**:
- RESTful API endpoints
- User and project management
- Test orchestration and coordination
- Agent registration and health checks
- Result aggregation and storage
- WebSocket for real-time updates

**Key Modules**:

```
backend/
├── auth/              # Authentication & authorization
├── users/             # User management
├── projects/          # Project/workspace management
├── scripts/           # JMX script management
├── agents/            # Load generator management
├── tests/             # Test execution orchestration
├── results/           # Result processing & storage
├── websocket/         # Real-time communication
└── storage/           # File storage abstraction
```

**API Endpoints**:
```
POST   /api/auth/login
POST   /api/auth/register
GET    /api/users/me
POST   /api/scripts/upload
GET    /api/scripts
DELETE /api/scripts/:id
POST   /api/agents/register
GET    /api/agents
PUT    /api/agents/:id/status
POST   /api/tests/start
GET    /api/tests/:id/status
POST   /api/tests/:id/stop
GET    /api/tests/:id/results
GET    /api/tests/:id/metrics/realtime
```

### 3. Load Generator Agent

**Purpose**: Execute JMeter tests on distributed machines

**Key Responsibilities**:
- Register with backend server
- Download test scripts and dependencies
- Execute JMeter in non-GUI mode
- Collect and stream metrics
- Report execution status
- Clean up resources

**Communication Flow**:
```
1. Agent starts → Register with backend
2. Backend assigns test → Agent downloads JMX + deps
3. Agent executes JMeter → Streams metrics
4. Test completes → Agent uploads results
5. Cleanup → Agent ready for next test
```

**Key Components**:
```python
class Agent:
    - heartbeat()          # Send health status
    - download_test()      # Get JMX and dependencies
    - execute_jmeter()     # Run test
    - stream_metrics()     # Send real-time data
    - upload_results()     # Send final results
    - cleanup()            # Clear temp files
```

### 4. Database (PostgreSQL)

**Schema Design**:

```sql
-- Users
CREATE TABLE users (
    id UUID PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(50),
    created_at TIMESTAMP DEFAULT NOW()
);

-- Projects
CREATE TABLE projects (
    id UUID PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    owner_id UUID REFERENCES users(id),
    created_at TIMESTAMP DEFAULT NOW()
);

-- Scripts
CREATE TABLE scripts (
    id UUID PRIMARY KEY,
    project_id UUID REFERENCES projects(id),
    name VARCHAR(255) NOT NULL,
    file_path VARCHAR(500) NOT NULL,
    version INTEGER DEFAULT 1,
    uploaded_by UUID REFERENCES users(id),
    uploaded_at TIMESTAMP DEFAULT NOW()
);

-- Dependencies
CREATE TABLE dependencies (
    id UUID PRIMARY KEY,
    script_id UUID REFERENCES scripts(id),
    name VARCHAR(255) NOT NULL,
    file_path VARCHAR(500) NOT NULL,
    type VARCHAR(50) -- 'csv', 'jar', 'properties'
);

-- Load Generators
CREATE TABLE agents (
    id UUID PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    hostname VARCHAR(255) NOT NULL,
    ip_address VARCHAR(50),
    location VARCHAR(100),
    status VARCHAR(50), -- 'online', 'offline', 'busy'
    max_threads INTEGER DEFAULT 1000,
    registered_at TIMESTAMP DEFAULT NOW(),
    last_heartbeat TIMESTAMP
);

-- Tests
CREATE TABLE tests (
    id UUID PRIMARY KEY,
    project_id UUID REFERENCES projects(id),
    script_id UUID REFERENCES scripts(id),
    name VARCHAR(255) NOT NULL,
    status VARCHAR(50), -- 'pending', 'running', 'completed', 'failed'
    started_by UUID REFERENCES users(id),
    started_at TIMESTAMP,
    completed_at TIMESTAMP,
    total_threads INTEGER,
    duration_seconds INTEGER
);

-- Test Agent Assignment
CREATE TABLE test_agents (
    id UUID PRIMARY KEY,
    test_id UUID REFERENCES tests(id),
    agent_id UUID REFERENCES agents(id),
    threads_assigned INTEGER,
    status VARCHAR(50)
);

-- Test Results (Summary)
CREATE TABLE test_results (
    id UUID PRIMARY KEY,
    test_id UUID REFERENCES tests(id),
    agent_id UUID REFERENCES agents(id),
    total_samples INTEGER,
    error_count INTEGER,
    avg_response_time FLOAT,
    min_response_time FLOAT,
    max_response_time FLOAT,
    p50_response_time FLOAT,
    p90_response_time FLOAT,
    p95_response_time FLOAT,
    p99_response_time FLOAT,
    throughput FLOAT,
    result_file_path VARCHAR(500),
    created_at TIMESTAMP DEFAULT NOW()
);

-- Test Metrics (Time-series data for tracking)
CREATE TABLE test_metrics (
    id UUID PRIMARY KEY,
    test_id UUID REFERENCES tests(id),
    timestamp TIMESTAMP NOT NULL,
    active_threads INTEGER,
    throughput FLOAT,
    avg_response_time FLOAT,
    error_rate FLOAT,
    cpu_percent FLOAT,
    memory_mb FLOAT,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Test Comparisons
CREATE TABLE test_comparisons (
    id UUID PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    test_ids UUID[] NOT NULL,
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP DEFAULT NOW()
);

-- Test Tags (for organization and filtering)
CREATE TABLE test_tags (
    id UUID PRIMARY KEY,
    test_id UUID REFERENCES tests(id),
    tag VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(test_id, tag)
);

-- Test Notes (for tracking and documentation)
CREATE TABLE test_notes (
    id UUID PRIMARY KEY,
    test_id UUID REFERENCES tests(id),
    user_id UUID REFERENCES users(id),
    note TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT NOW()
);
```

### 5. Message Queue (RabbitMQ/Redis)

**Queues**:

```
test.start          # New test execution requests
test.stop           # Stop test commands
metrics.stream      # Real-time metrics from agents
results.process     # Process completed test results
agent.heartbeat     # Agent health checks
```

**Message Flow**:
```
User → Backend → Queue → Agent
               ↓
            Database
               ↓
          WebSocket → Frontend
```

### 6. File Storage (MinIO/S3)

**Buckets**:
```
scripts/         # JMX files
dependencies/    # CSV, JAR, properties files
results/         # JTL result files
reports/         # HTML reports
temp/            # Temporary files during execution
```

**File Naming Convention**:
```
scripts/{project_id}/{script_id}/v{version}/test.jmx
dependencies/{script_id}/{filename}
results/{test_id}/{agent_id}/results.jtl
reports/{test_id}/index.html
```

## Data Flow

### Test Execution Flow

```
1. User uploads JMX script
   └─> Frontend → Backend API → Storage (S3)
   └─> Backend → Database (save metadata)

2. User selects load generators
   └─> Frontend → Backend → Database (query available agents)

3. User starts test
   └─> Frontend → Backend → Queue (test.start)
   └─> Backend → Database (create test record)
   └─> Queue → Agents (distribute test)

4. Agents execute test
   └─> Agent → Storage (download JMX + deps)
   └─> Agent → JMeter (execute)
   └─> Agent → Queue (stream metrics)
   └─> Queue → Backend → WebSocket → Frontend

5. Test completes
   └─> Agent → Storage (upload results)
   └─> Agent → Backend (notify completion)
   └─> Backend → Database (save results)
   └─> Backend → WebSocket → Frontend (update UI)
```

### Real-Time Metrics Flow

```
Agent (every 5s):
  └─> Collect current metrics
  └─> Publish to metrics.stream queue
  
Backend:
  └─> Consume from queue
  └─> Aggregate from multiple agents
  └─> Broadcast via WebSocket to connected clients
  
Frontend:
  └─> Receive WebSocket updates
  └─> Update charts and dashboards
```

## Security Considerations

### Authentication
- JWT tokens for API authentication
- Refresh token mechanism
- Token expiration: 1 hour (access), 7 days (refresh)

### Authorization
- Role-based access control (RBAC)
- Roles: Admin, User, Viewer
- Project-level permissions

### Agent Security
- Agent registration requires API key
- TLS for agent-backend communication
- Agent authentication tokens

### File Upload
- Validate file types (.jmx, .csv, .jar)
- Virus scanning (optional)
- File size limits
- Sanitize filenames

### Data Protection
- Encrypt sensitive data at rest
- HTTPS for all communications
- Input validation and sanitization
- Rate limiting on API endpoints

## Scalability Considerations

### Horizontal Scaling
- Backend: Stateless API servers (load balanced)
- Agents: Add more machines as needed
- Database: Read replicas for queries
- Queue: Cluster mode for RabbitMQ

### Performance Optimization
- Cache frequently accessed data (Redis)
- Lazy loading for large result sets
- Pagination for API responses
- CDN for static assets

### Monitoring
- Application monitoring (Prometheus + Grafana)
- Log aggregation (ELK stack)
- Agent health checks
- Database performance monitoring

## Deployment Architecture

```
┌─────────────────────────────────────────┐
│         Load Balancer (Nginx)           │
└──────────────┬──────────────────────────┘
               │
       ┌───────┴────────┐
       ▼                ▼
┌─────────────┐  ┌─────────────┐
│  Backend 1  │  │  Backend 2  │
└──────┬──────┘  └──────┬──────┘
       │                │
       └────────┬───────┘
                ▼
       ┌────────────────┐
       │   PostgreSQL   │
       │   (Primary)    │
       └────────────────┘
                │
       ┌────────┴────────┐
       ▼                 ▼
┌─────────────┐   ┌─────────────┐
│   RabbitMQ  │   │    MinIO    │
└──────┬──────┘   └─────────────┘
       │
   ┌───┴────┬────────┬─────────┐
   ▼        ▼        ▼         ▼
┌──────┐ ┌──────┐ ┌──────┐ ┌──────┐
│Agent1│ │Agent2│ │Agent3│ │AgentN│
└──────┘ └──────┘ └──────┘ └──────┘
```

## Next Steps
1. Set up development environment
2. Implement backend API (Phase 1)
3. Build frontend application (Phase 1)
4. Develop agent application (Phase 1)
5. Integration testing
6. Deploy MVP
