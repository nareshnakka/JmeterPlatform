# JMeter Platform - Setup Wizard

## Overview

Simple, wizard-based installation for both Server and Agent components with all dependencies included.

## Installation Packages

### Server Package
- Node.js runtime (bundled)
- PostgreSQL database (bundled)
- Redis cache (bundled)
- MinIO storage (bundled)
- Backend application
- Frontend application
- Setup wizard

### Agent Package
- Python runtime (bundled)
- OpenJDK (bundled)
- Apache JMeter (bundled)
- Agent application
- Setup wizard

## System Requirements

### Server
- **Windows**: Windows Server 2019+ or Windows 10+
- **Linux**: Ubuntu 20.04+, CentOS 8+, or Debian 11+
- **RAM**: 8 GB minimum, 16 GB recommended
- **Disk**: 50 GB minimum
- **CPU**: 4 cores minimum

### Agent
- **Windows**: Windows Server 2016+ or Windows 10+
- **Linux**: Ubuntu 18.04+, CentOS 7+, or Debian 10+
- **RAM**: 4 GB minimum, 8 GB recommended
- **Disk**: 20 GB minimum
- **CPU**: 2 cores minimum

## Open-Source Technologies Used

| Component | Technology | License |
|-----------|-----------|---------|
| Backend Runtime | Node.js | MIT |
| Frontend | React | MIT |
| Database | PostgreSQL | PostgreSQL License |
| Cache | Redis | BSD |
| Storage | MinIO | AGPL v3 |
| Agent Runtime | Python | PSF |
| Java Runtime | OpenJDK (Eclipse Temurin) | GPL v2 + CE |
| Load Testing | Apache JMeter | Apache 2.0 |
| Web Server | Nginx (optional) | BSD |

All technologies are 100% open-source and free to use!

## Quick Installation

### Server Installation

#### Windows
```cmd
# Download installer
jmeter-platform-server-setup-windows.exe

# Run installer (GUI wizard)
# Or silent install:
jmeter-platform-server-setup-windows.exe /S /D=C:\JMeterPlatform
```

#### Linux
```bash
# Download installer
wget https://releases.jmeter-platform.com/server-installer-linux.sh

# Run installer
sudo bash server-installer-linux.sh

# Or interactive wizard
sudo bash server-installer-linux.sh --interactive
```

### Agent Installation

#### Windows
```cmd
# Download installer
jmeter-platform-agent-setup-windows.exe

# Run installer (GUI wizard)
# Or silent install:
jmeter-platform-agent-setup-windows.exe /S /D=C:\JMeterAgent
```

#### Linux
```bash
# Download installer
wget https://releases.jmeter-platform.com/agent-installer-linux.sh

# Run installer
sudo bash agent-installer-linux.sh

# Or interactive wizard
sudo bash agent-installer-linux.sh --interactive
```

## Installation Process

### Server Setup Wizard (Step-by-Step)

**Step 1: Welcome**
- Introduction to JMeter Platform
- License agreement (open-source)
- System requirements check

**Step 2: Installation Type**
- Express (default settings)
- Custom (configure each component)
- Development (includes sample data)

**Step 3: Installation Location**
- Default: `C:\JMeterPlatform` (Windows) or `/opt/jmeter-platform` (Linux)
- Custom path selection

**Step 4: Database Configuration**
- PostgreSQL will be installed
- Set admin password
- Database name (default: jmeter_platform)
- Port (default: 5432)

**Step 5: Application Configuration**
- Server name
- Admin email and password
- Server port (default: 3000)
- Frontend port (default: 80 or 8080)

**Step 6: Network Configuration**
- Firewall rules configuration
- SSL/TLS certificate (optional)
- External access settings

**Step 7: Installation**
- Progress bar showing:
  - Installing dependencies
  - Configuring database
  - Setting up storage
  - Creating admin user
  - Starting services

**Step 8: Complete**
- Installation summary
- Access URL: http://localhost:8080
- Admin credentials
- Next steps guide

### Agent Setup Wizard (Step-by-Step)

**Step 1: Welcome**
- Introduction to Load Generator Agent
- System requirements check

**Step 2: Installation Type**
- Express (auto-detect everything)
- Custom (specify paths)

**Step 3: Installation Location**
- Default: `C:\JMeterAgent` (Windows) or `/opt/jmeter-agent` (Linux)
- Custom path selection

**Step 4: Java & JMeter**
- Auto-install OpenJDK (recommended)
- Or specify existing installation
- Auto-install JMeter (recommended)
- Or specify existing installation

**Step 5: Server Connection**
- Backend server URL
- Agent name (auto-generated)
- Agent location/region
- API key (if required)

**Step 6: Resource Limits**
- Maximum threads (default: 1000)
- Memory allocation
- CPU limits

**Step 7: Installation**
- Progress bar showing:
  - Installing OpenJDK
  - Installing JMeter
  - Configuring agent
  - Testing connection

**Step 8: Complete**
- Installation summary
- Agent registered successfully
- Service status
- Logs location

## Package Structure

### Server Package

```
jmeter-platform-server/
├── installer.exe / installer.sh
├── setup-wizard.js
├── bundled/
│   ├── node-v18.18.0/          # Node.js runtime
│   ├── postgresql-15/          # PostgreSQL database
│   ├── redis-7.2/              # Redis cache
│   ├── minio/                  # MinIO storage
│   └── nginx/                  # Web server (optional)
├── application/
│   ├── backend/                # Backend app (pre-built)
│   └── frontend/               # Frontend app (pre-built)
├── config/
│   ├── default-config.json
│   └── sample-data.sql
├── scripts/
│   ├── install.sh
│   ├── uninstall.sh
│   ├── start.sh
│   ├── stop.sh
│   └── service-install.sh
└── docs/
    ├── README.md
    └── QUICKSTART.md
```

### Agent Package

```
jmeter-platform-agent/
├── installer.exe / installer.sh
├── setup-wizard.py
├── bundled/
│   ├── python-3.11/            # Python runtime
│   ├── openjdk-17/             # OpenJDK
│   └── apache-jmeter-5.6.3/    # JMeter
├── agent/
│   ├── agent.py
│   ├── requirements.txt
│   └── config/
├── scripts/
│   ├── install.sh
│   ├── uninstall.sh
│   ├── start.sh
│   ├── stop.sh
│   └── service-install.sh
└── docs/
    ├── README.md
    └── QUICKSTART.md
```

## Post-Installation

### Server

**Access Web Interface:**
```
http://localhost:8080
or
http://your-server-ip:8080
```

**Default Credentials:**
- Username: admin@jmeter-platform.local
- Password: (set during installation)

**Start/Stop Services:**
```bash
# Windows
net start JMeterPlatform
net stop JMeterPlatform

# Linux
sudo systemctl start jmeter-platform
sudo systemctl stop jmeter-platform
```

**View Logs:**
```bash
# Windows
C:\JMeterPlatform\logs\

# Linux
/var/log/jmeter-platform/
```

### Agent

**Check Agent Status:**
```bash
# Windows
sc query JMeterAgent

# Linux
sudo systemctl status jmeter-agent
```

**View Agent Logs:**
```bash
# Windows
C:\JMeterAgent\logs\agent.log

# Linux
/var/log/jmeter-agent/agent.log
```

**Restart Agent:**
```bash
# Windows
net restart JMeterAgent

# Linux
sudo systemctl restart jmeter-agent
```

## Updating

### Server Update
```bash
# Download update package
# Windows
jmeter-platform-update-windows.exe

# Linux
sudo bash jmeter-platform-update-linux.sh
```

### Agent Update
```bash
# Download update package
# Windows
jmeter-agent-update-windows.exe

# Linux
sudo bash jmeter-agent-update-linux.sh
```

## Uninstallation

### Server
```bash
# Windows
C:\JMeterPlatform\uninstall.exe

# Linux
sudo bash /opt/jmeter-platform/uninstall.sh
```

### Agent
```bash
# Windows
C:\JMeterAgent\uninstall.exe

# Linux
sudo bash /opt/jmeter-agent/uninstall.sh
```

## Troubleshooting

### Installation Issues

**Problem: Port already in use**
- Change ports in setup wizard
- Or stop conflicting services

**Problem: Insufficient permissions**
- Run installer as Administrator (Windows)
- Use sudo (Linux)

**Problem: Installation fails**
- Check system requirements
- Review installation logs
- Disable antivirus temporarily

### Connection Issues

**Problem: Agent can't connect to server**
- Verify server URL
- Check firewall rules
- Test network connectivity: `telnet server-ip 3000`

**Problem: Can't access web interface**
- Check if services are running
- Verify port not blocked by firewall
- Try: `http://localhost:8080`

## Configuration Files

### Server Config
```
# Windows
C:\JMeterPlatform\config\server.conf

# Linux
/etc/jmeter-platform/server.conf
```

### Agent Config
```
# Windows
C:\JMeterAgent\config\agent.conf

# Linux
/etc/jmeter-agent/agent.conf
```

## Advanced Options

### Silent Installation (Automated)

**Server (Windows):**
```cmd
jmeter-platform-server-setup-windows.exe ^
  /S ^
  /D=C:\JMeterPlatform ^
  /AdminEmail=admin@company.com ^
  /AdminPassword=SecurePass123 ^
  /ServerPort=3000 ^
  /FrontendPort=8080
```

**Agent (Linux):**
```bash
sudo bash agent-installer-linux.sh \
  --silent \
  --install-dir=/opt/jmeter-agent \
  --server-url=http://jmeter-server:3000 \
  --agent-name=prod-agent-01 \
  --max-threads=2000
```

### Configuration via File

**Server (config.json):**
```json
{
  "database": {
    "host": "localhost",
    "port": 5432,
    "name": "jmeter_platform",
    "username": "jmeter",
    "password": "auto-generated"
  },
  "server": {
    "port": 3000,
    "host": "0.0.0.0"
  },
  "frontend": {
    "port": 8080
  },
  "admin": {
    "email": "admin@company.com",
    "password": "changeme"
  }
}
```

**Agent (config.json):**
```json
{
  "backend_url": "http://server:3000",
  "agent_name": "agent-001",
  "location": "datacenter-1",
  "max_threads": 1000,
  "java_home": "auto",
  "jmeter_home": "auto"
}
```

## Distribution

### Building Installers

See [BUILD_INSTALLER.md](BUILD_INSTALLER.md) for instructions on creating installation packages.

### Download Locations

**Official Releases:**
- GitHub Releases: https://github.com/your-org/jmeter-platform/releases
- Direct Download: https://downloads.jmeter-platform.com/

**Package Sizes:**
- Server (Windows): ~800 MB
- Server (Linux): ~600 MB
- Agent (Windows): ~500 MB
- Agent (Linux): ~400 MB

## Support

- Documentation: https://docs.jmeter-platform.com/
- Issues: https://github.com/your-org/jmeter-platform/issues
- Community: https://community.jmeter-platform.com/
