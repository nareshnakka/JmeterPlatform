-- CreateTable
CREATE TABLE "host_metrics" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "testId" TEXT NOT NULL,
    "agentId" TEXT NOT NULL,
    "timestamp" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "cpuPercent" REAL NOT NULL,
    "memoryPercent" REAL NOT NULL,
    CONSTRAINT "host_metrics_testId_fkey" FOREIGN KEY ("testId") REFERENCES "tests" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "host_metrics_agentId_fkey" FOREIGN KEY ("agentId") REFERENCES "agents" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateIndex
CREATE INDEX "host_metrics_testId_idx" ON "host_metrics"("testId");

-- CreateIndex
CREATE INDEX "host_metrics_agentId_idx" ON "host_metrics"("agentId");

-- CreateIndex
CREATE INDEX "host_metrics_timestamp_idx" ON "host_metrics"("timestamp");
