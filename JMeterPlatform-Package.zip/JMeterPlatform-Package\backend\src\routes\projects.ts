import { Router, Response } from 'express';
import { body, validationResult } from 'express-validator';
import { PrismaClient } from '@prisma/client';
import { authenticate, AuthRequest } from '../middleware/auth';

const router = Router();

// All routes require authentication
router.use(authenticate);

// Get all projects for current user
router.get('/', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const prisma: PrismaClient = req.app.get('prisma');
    
    const projects = await prisma.project.findMany({
      where: { userId: req.user!.id },
      include: {
        _count: {
          select: {
            scripts: true,
            tests: true
          }
        }
      },
      orderBy: { updatedAt: 'desc' }
    });
    
    res.json(projects);
  } catch (error) {
    console.error('Error fetching projects:', error);
    res.status(500).json({ error: 'Failed to fetch projects' });
  }
});

// Get single project
router.get('/:id', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const prisma: PrismaClient = req.app.get('prisma');
    
    const project = await prisma.project.findFirst({
      where: {
        id: req.params.id as string,
        userId: req.user!.id
      },
      include: {
        scripts: {
          include: {
            _count: {
              select: { dependencies: true }
            }
          }
        },
        tests: {
          take: 10,
          orderBy: { createdAt: 'desc' }
        }
      }
    });
    
    if (!project) {
      res.status(404).json({ error: 'Project not found' });

      return;
    }
    
    res.json(project);
  } catch (error) {
    console.error('Error fetching project:', error);
    res.status(500).json({ error: 'Failed to fetch project' });
  }
});

// Create project
router.post(
  '/',
  [
    body('name').trim().isLength({ min: 1, max: 255 }),
    body('description').optional().trim()
  ],
  async (req: AuthRequest, res: Response): Promise<void> => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        res.status(400).json({ errors: errors.array() });

        return;
      }
      
      const prisma: PrismaClient = req.app.get('prisma');
      const { name, description } = req.body;
      
      // Verify user exists before creating project
      if (!req.user?.id) {
        res.status(401).json({ error: 'User not authenticated' });
        return;
      }
      
      const userExists = await prisma.user.findUnique({
        where: { id: req.user.id }
      });
      
      if (!userExists) {
        res.status(404).json({ error: 'User not found' });
        return;
      }
      
      const project = await prisma.project.create({
        data: {
          name,
          description,
          userId: req.user.id
        }
      });
      
      res.status(201).json(project);
    } catch (error) {
      console.error('Error creating project:', error);
      res.status(500).json({ error: 'Failed to create project' });
    }
  }
);

// Update project
router.put('/:id', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const prisma: PrismaClient = req.app.get('prisma');
    const { name, description } = req.body;
    
    const project = await prisma.project.updateMany({
      where: {
        id: req.params.id as string,
        userId: req.user!.id
      },
      data: {
        name,
        description
      }
    });
    
    if (project.count === 0) {
      res.status(404).json({ error: 'Project not found' });

      return;
    }
    
    const updated = await prisma.project.findUnique({
      where: { id: req.params.id as string }
    });
    
    res.json(updated);
  } catch (error) {
    console.error('Error updating project:', error);
    res.status(500).json({ error: 'Failed to update project' });
  }
});

// Delete project
router.delete('/:id', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const prisma: PrismaClient = req.app.get('prisma');
    
    const result = await prisma.project.deleteMany({
      where: {
        id: req.params.id as string,
        userId: req.user!.id
      }
    });
    
    if (result.count === 0) {
      res.status(404).json({ error: 'Project not found' });

      return;
    }
    
    res.status(204).send();
  } catch (error) {
    console.error('Error deleting project:', error);
    res.status(500).json({ error: 'Failed to delete project' });
  }
});

export default router;

