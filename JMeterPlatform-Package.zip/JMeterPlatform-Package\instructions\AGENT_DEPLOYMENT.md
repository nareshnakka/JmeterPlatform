# Load Agent Deployment Guide

Complete guide for deploying JMeter load generator agents on any system.

## Overview

The load agent is a lightweight Python application that:
- Registers with your backend server
- Polls for test assignments
- Downloads test scripts and dependencies
- Executes JMeter tests
- Uploads results back to the platform

## Deployment Options

### 1. Localhost Agent (Development)

Perfect for testing and development on your local machine.

**Windows:**
```cmd
cd agent
start-agent.bat
```

**Linux/Mac:**
```bash
cd agent
chmod +x start-agent.sh
./start-agent.sh
```

**Configuration:**
```env
BACKEND_URL=http://localhost:3000
AGENT_NAME=localhost-dev
AGENT_LOCATION=localhost
```

### 2. Remote Server Agent

Deploy on dedicated servers for production testing.

#### Physical Server / VM

**Step 1: Prepare Server**
```bash
# Install Python
sudo apt-get update
sudo apt-get install -y python3 python3-pip python3-venv

# Install Java
sudo apt-get install -y default-jre

# Install JMeter
wget https://downloads.apache.org/jmeter/binaries/apache-jmeter-5.6.3.tgz
tar -xzf apache-jmeter-5.6.3.tgz
sudo mv apache-jmeter-5.6.3 /opt/jmeter
```

**Step 2: Deploy Agent**
```bash
# Copy agent files to server
scp -r agent/ user@server:/home/user/

# SSH into server
ssh user@server

# Navigate to agent directory
cd agent

# Setup and run
./start-agent.sh
```

**Step 3: Configure for Remote Backend**
```env
BACKEND_URL=http://your-backend-server:3000
AGENT_NAME=prod-server-01
AGENT_LOCATION=datacenter-us-east
MAX_THREADS=2000
```

#### Monitor-Only Agent on Infra Hosts (Frontend / Backend / DB)

Sometimes you only want to monitor a server's resource usage (CPU, memory, status)
without running JMeter tests on that machine. For example:
- Frontend web server
- Backend API server
- Database server

You can run the same agent in **monitor-only mode** on those hosts. In this mode:
- No Java or JMeter installation is required
- The agent **does not** execute tests
- It only registers with the backend and sends heartbeats every 30 seconds
- The Agents dashboard will show CPU/Memory and status per host

**Example .env for a monitor-only agent:**

Frontend host:
```env
BACKEND_URL=http://your-backend-server:3000
AGENT_NAME=frontend server
AGENT_LOCATION=frontend-host
AGENT_MODE=monitor
HEARTBEAT_INTERVAL=30
```

Backend host:
```env
BACKEND_URL=http://your-backend-server:3000
AGENT_NAME=backend server
AGENT_LOCATION=backend-host
AGENT_MODE=monitor
HEARTBEAT_INTERVAL=30
```

Database host:
```env
BACKEND_URL=http://your-backend-server:3000
AGENT_NAME=db server
AGENT_LOCATION=db-host
AGENT_MODE=monitor
HEARTBEAT_INTERVAL=30
```

Notes:
- `AGENT_MODE=monitor` tells the agent to skip Java/JMeter validation and never poll for tests.
- `HEARTBEAT_INTERVAL` (seconds) controls how often CPU/Memory data is sent (default: 30).
- These agents will appear in the Agents page like normal agents, but act purely as **host monitors**.

**Step 4: Run as Service (systemd)**

Create `/etc/systemd/system/jmeter-agent.service`:
```ini
[Unit]
Description=JMeter Load Generator Agent
After=network.target

[Service]
Type=simple
User=jmeter
WorkingDirectory=/home/jmeter/agent
ExecStart=/home/jmeter/agent/venv/bin/python /home/jmeter/agent/agent.py
Restart=always
RestartSec=10
Environment="PATH=/home/jmeter/agent/venv/bin:/usr/local/bin:/usr/bin:/bin"

[Install]
WantedBy=multi-user.target
```

Enable and start:
```bash
sudo systemctl daemon-reload
sudo systemctl enable jmeter-agent
sudo systemctl start jmeter-agent
sudo systemctl status jmeter-agent
```

View logs:
```bash
sudo journalctl -u jmeter-agent -f
```

### 3. Docker Deployment

Containerized agents for easy deployment and scaling.

#### Single Docker Agent

```bash
cd agent

# Build image
docker build -t jmeter-agent:latest .

# Run container
docker run -d \
  --name jmeter-agent-1 \
  --restart unless-stopped \
  -e BACKEND_URL=http://backend:3000 \
  -e AGENT_NAME=docker-agent-1 \
  -e AGENT_LOCATION=docker-host \
  -e MAX_THREADS=1000 \
  -v $(pwd)/work:/app/work \
  jmeter-agent:latest

# View logs
docker logs -f jmeter-agent-1
```

#### Multiple Agents with Docker Compose

**docker-compose.yml:**
```yaml
version: '3.8'

services:
  agent-1:
    build: .
    container_name: jmeter-agent-1
    environment:
      - BACKEND_URL=http://backend:3000
      - AGENT_NAME=docker-agent-1
      - AGENT_LOCATION=docker-compose
      - MAX_THREADS=1000
      # Optional: monitor-only agent (no tests executed)
      # - AGENT_MODE=monitor
      # - HEARTBEAT_INTERVAL=30
    volumes:
      - ./work/agent-1:/app/work
    restart: unless-stopped

  agent-2:
    build: .
    container_name: jmeter-agent-2
    environment:
      - BACKEND_URL=http://backend:3000
      - AGENT_NAME=docker-agent-2
      - AGENT_LOCATION=docker-compose
      - MAX_THREADS=1000
    volumes:
      - ./work/agent-2:/app/work
    restart: unless-stopped

  agent-3:
    build: .
    container_name: jmeter-agent-3
    environment:
      - BACKEND_URL=http://backend:3000
      - AGENT_NAME=docker-agent-3
      - AGENT_LOCATION=docker-compose
      - MAX_THREADS=1000
    volumes:
      - ./work/agent-3:/app/work
    restart: unless-stopped
```

Deploy:
```bash
docker-compose up -d
docker-compose logs -f
docker-compose ps
```

### 4. Cloud Deployment

#### AWS EC2

**Launch EC2 Instance:**
```bash
# Using AWS CLI
aws ec2 run-instances \
  --image-id ami-0c55b159cbfafe1f0 \
  --instance-type t3.large \
  --key-name your-key \
  --security-group-ids sg-xxx \
  --user-data file://setup-agent.sh
```

**setup-agent.sh:**
```bash
#!/bin/bash
apt-get update
apt-get install -y python3 python3-pip default-jre wget

# Install JMeter
wget https://downloads.apache.org/jmeter/binaries/apache-jmeter-5.6.3.tgz
tar -xzf apache-jmeter-5.6.3.tgz
mv apache-jmeter-5.6.3 /opt/jmeter

# Setup agent
cd /home/ubuntu
git clone https://your-repo/jmeter-platform.git
cd jmeter-platform/agent

# Configure
cat > .env << EOF
BACKEND_URL=http://your-backend:3000
AGENT_NAME=aws-ec2-$(ec2-metadata --instance-id | cut -d " " -f 2)
AGENT_LOCATION=us-east-1
MAX_THREADS=2000
JMETER_HOME=/opt/jmeter
EOF

# Install and run
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
nohup python3 agent.py > /var/log/jmeter-agent.log 2>&1 &
```

#### Azure VM

```bash
# Create VM
az vm create \
  --resource-group jmeter-rg \
  --name jmeter-agent-1 \
  --image UbuntuLTS \
  --size Standard_D2s_v3 \
  --admin-username azureuser \
  --generate-ssh-keys \
  --custom-data setup-agent.sh
```

#### Google Cloud Platform

```bash
# Create instance
gcloud compute instances create jmeter-agent-1 \
  --zone=us-central1-a \
  --machine-type=n1-standard-2 \
  --image-family=ubuntu-2004-lts \
  --image-project=ubuntu-os-cloud \
  --metadata-from-file startup-script=setup-agent.sh
```

#### Kubernetes

**deployment.yaml:**
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: jmeter-agents
  namespace: jmeter
spec:
  replicas: 5
  selector:
    matchLabels:
      app: jmeter-agent
  template:
    metadata:
      labels:
        app: jmeter-agent
    spec:
      containers:
      - name: agent
        image: your-registry/jmeter-agent:latest
        env:
        - name: BACKEND_URL
          value: "http://backend-service.jmeter.svc.cluster.local:3000"
        - name: AGENT_LOCATION
          value: "kubernetes"
        - name: MAX_THREADS
          value: "1000"
        - name: AGENT_NAME
          valueFrom:
            fieldRef:
              fieldPath: metadata.name
        resources:
          requests:
            memory: "2Gi"
            cpu: "1000m"
          limits:
            memory: "4Gi"
            cpu: "2000m"
        volumeMounts:
        - name: work
          mountPath: /app/work
      volumes:
      - name: work
        emptyDir: {}
---
apiVersion: v1
kind: Service
metadata:
  name: jmeter-agents
  namespace: jmeter
spec:
  selector:
    app: jmeter-agent
  ports:
  - port: 8080
    targetPort: 8080
  type: ClusterIP
```

Deploy:
```bash
kubectl create namespace jmeter
kubectl apply -f deployment.yaml
kubectl get pods -n jmeter
kubectl logs -n jmeter -l app=jmeter-agent -f
```

Scale agents:
```bash
kubectl scale deployment jmeter-agents --replicas=10 -n jmeter
```

### 5. Multi-Region Deployment

Deploy agents across multiple geographic regions for realistic load testing.

**Regions:**
- US East: 5 agents
- US West: 5 agents
- EU West: 5 agents
- Asia Pacific: 5 agents

**Configuration per region:**

US East:
```env
BACKEND_URL=http://central-backend:3000
AGENT_LOCATION=us-east-1
```

EU West:
```env
BACKEND_URL=http://central-backend:3000
AGENT_LOCATION=eu-west-1
```

Asia Pacific:
```env
BACKEND_URL=http://central-backend:3000
AGENT_LOCATION=ap-southeast-1
```

### 6. Auto-Scaling Agents

#### AWS Auto Scaling Group

```bash
# Create launch template
aws ec2 create-launch-template \
  --launch-template-name jmeter-agent-template \
  --version-description "JMeter Agent v1" \
  --launch-template-data '{
    "ImageId": "ami-xxx",
    "InstanceType": "t3.large",
    "UserData": "base64-encoded-setup-script",
    "IamInstanceProfile": {"Name": "jmeter-agent-role"}
  }'

# Create auto scaling group
aws autoscaling create-auto-scaling-group \
  --auto-scaling-group-name jmeter-agents \
  --launch-template LaunchTemplateName=jmeter-agent-template \
  --min-size 2 \
  --max-size 20 \
  --desired-capacity 5
```

#### Kubernetes Horizontal Pod Autoscaler

```yaml
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: jmeter-agent-hpa
  namespace: jmeter
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: jmeter-agents
  minReplicas: 2
  maxReplicas: 20
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 70
```

## Agent Management

### View All Agents

Access backend dashboard to see:
- Agent status (online, busy, offline)
- Last heartbeat time
- Current load
- Location
- Capacity

### Monitor Agent Health

```bash
# Check logs
tail -f agent.log

# System resources
htop
free -h
df -h

# Network connectivity
ping backend-server
curl http://backend-server:3000/health
```

### Update Agents

```bash
# Stop agent
pkill -f agent.py

# Update code
git pull

# Update dependencies
pip install -r requirements.txt

# Restart
python agent.py
```

### Remove Agent

```bash
# Stop agent
pkill -f agent.py

# Remove from backend (via API or UI)
curl -X DELETE http://backend:3000/api/agents/{agent-id}

# Clean up files
rm -rf agent/
```

## Security Best Practices

1. **Use HTTPS for backend communication**
   ```env
   BACKEND_URL=https://backend.example.com
   ```

2. **Implement API key rotation**
   - Backend should support key regeneration
   - Agents should automatically fetch new keys

3. **Network isolation**
   - Place agents in private subnet
   - Use VPN for communication
   - Configure security groups/firewall rules

4. **Secure credentials**
   - Don't commit `.env` files
   - Use secrets management (AWS Secrets Manager, HashiCorp Vault)
   - Encrypt sensitive data

5. **Regular updates**
   - Keep Python and dependencies updated
   - Update JMeter regularly
   - Patch OS vulnerabilities

## Troubleshooting

### Common Issues

**Issue: Agent can't connect to backend**
```bash
# Test connectivity
curl http://backend:3000/health
ping backend

# Check firewall
sudo ufw status
sudo iptables -L
```

**Issue: Out of memory during large tests**
```bash
# Increase JVM heap in JMeter
export HEAP="-Xms2g -Xmx8g"

# Add more RAM to server/container
```

**Issue: Agent offline after restart**
```bash
# Check if process is running
ps aux | grep agent.py

# Check logs
tail -n 100 agent.log

# Verify .env configuration
cat .env
```

## Performance Optimization

### Agent Machine Specs

| Test Size | CPU | RAM | Storage |
|-----------|-----|-----|---------|
| Small (100-500 users) | 2 cores | 4 GB | 20 GB |
| Medium (500-2000 users) | 4 cores | 8 GB | 50 GB |
| Large (2000-5000 users) | 8 cores | 16 GB | 100 GB |
| Extra Large (5000+ users) | 16 cores | 32 GB | 200 GB |

### Network Requirements

- **Bandwidth**: 100 Mbps minimum, 1 Gbps recommended
- **Latency**: Low latency to target application
- **Concurrent connections**: Ensure firewall allows sufficient connections

### JMeter Tuning

```bash
# Increase heap size (jmeter/bin/jmeter.sh)
HEAP="-Xms2g -Xmx8g -XX:MaxMetaspaceSize=512m"

# Disable unnecessary listeners
# Use Simple Data Writer instead of complex listeners
# Minimize logging during test execution
```

## Cost Optimization

### Cloud Costs

- Use spot/preemptible instances for agents
- Auto-scale based on demand
- Shut down agents when not in use
- Use reserved instances for base capacity

### Example AWS Pricing

- t3.large (2 vCPU, 8 GB RAM): ~$0.08/hour
- c5.xlarge (4 vCPU, 8 GB RAM): ~$0.17/hour
- For 10 agents running 8 hours/day: ~$25-50/day

## Next Steps

1. Deploy your first localhost agent
2. Test with a simple JMX script
3. Deploy to remote server
4. Scale to multiple agents
5. Implement monitoring and alerting
6. Automate deployment with IaC (Terraform, CloudFormation)
