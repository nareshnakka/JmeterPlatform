import axios, { AxiosInstance } from 'axios';

class ApiClient {
  private client: AxiosInstance;
  
  constructor() {
    this.client = axios.create({
      baseURL: import.meta.env.VITE_API_URL || 'http://localhost:3000',
      headers: {
        'Content-Type': 'application/json',
      },
    });
    
    // Add token to requests
    this.client.interceptors.request.use((config) => {
      const token = localStorage.getItem('token');
      if (token) {
        config.headers.Authorization = `Bearer ${token}`;
      }
      return config;
    });
    
    // Handle auth errors
    this.client.interceptors.response.use(
      (response) => response,
      (error) => {
        if (error.response?.status === 401) {
          localStorage.removeItem('token');
          window.location.href = '/login';
        }
        return Promise.reject(error);
      }
    );
  }
  
  // Auth
  async login(email: string, password: string) {
    const { data } = await this.client.post('/api/auth/login', { email, password });
    return data;
  }
  
  async register(email: string, password: string) {
    const { data } = await this.client.post('/api/auth/register', { email, password });
    return data;
  }
  
  async getMe() {
    const { data } = await this.client.get('/api/auth/me');
    return data;
  }
  
  // Projects
  async getProjects() {
    const { data } = await this.client.get('/api/projects');
    return data;
  }
  
  async getProject(id: string) {
    const { data } = await this.client.get(`/api/projects/${id}`);
    return data;
  }
  
  async createProject(project: { name: string; description?: string }) {
    const { data } = await this.client.post('/api/projects', project);
    return data;
  }
  
  async updateProject(id: string, project: { name: string; description?: string }) {
    const { data } = await this.client.put(`/api/projects/${id}`, project);
    return data;
  }
  
  async deleteProject(id: string) {
    await this.client.delete(`/api/projects/${id}`);
  }
  
  // Scripts
  async getProjectScripts(projectId: string) {
    const { data } = await this.client.get(`/api/scripts/project/${projectId}`);
    return data;
  }

  async getScriptThreadGroups(scriptId: string) {
    const { data } = await this.client.get(`/api/scripts/${scriptId}/thread-groups`);
    return data;
  }

  async updateScriptThreadGroups(scriptId: string, payload: {
    overrideEnabled: boolean;
    groups: { name: string; threads: number; rampUp: number; duration: number }[];
  }) {
    const { data } = await this.client.put(`/api/scripts/${scriptId}/thread-groups`, payload);
    return data;
  }

  async uploadScript(formData: FormData) {
    const { data } = await this.client.post('/api/scripts', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
    return data;
  }
  
  async addDependency(scriptId: string, formData: FormData) {
    const { data } = await this.client.post(`/api/scripts/${scriptId}/dependencies`, formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
    return data;
  }
  
  async downloadScriptZip(scriptId: string, fileName: string) {
    const response = await this.client.get(`/api/scripts/${scriptId}/download-zip`, {
      responseType: 'blob',
    });
    
    // Create download link
    const url = window.URL.createObjectURL(new Blob([response.data]));
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', fileName);
    document.body.appendChild(link);
    link.click();
    link.remove();
    window.URL.revokeObjectURL(url);
  }
  
  async replaceScript(scriptId: string, formData: FormData) {
    const { data } = await this.client.put(`/api/scripts/${scriptId}/replace`, formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
    return data;
  }
  
  async deleteScript(id: string) {
    await this.client.delete(`/api/scripts/${id}`);
  }
  
  // Agents
  async getAgents() {
    const { data } = await this.client.get('/api/agents');
    return data;
  }
  
  async getAgent(id: string) {
    const { data} = await this.client.get(`/api/agents/${id}`);
    return data;
  }
  
  async deleteAgent(id: string) {
    await this.client.delete(`/api/agents/${id}`);
  }
  
  async restartAgent(id: string) {
    const { data } = await this.client.post(`/api/agents/${id}/restart`);
    return data;
  }
  
  // Tests
  async getProjectTests(projectId: string) {
    const { data} = await this.client.get(`/api/tests/project/${projectId}`);
    return data;
  }

  async getScriptTests(scriptId: string) {
    const { data } = await this.client.get(`/api/tests/script/${scriptId}`);
    return data;
  }

  async getTests() {
    const { data } = await this.client.get('/api/tests');
    return data;
  }
  
  async getTest(id: string) {
    const { data } = await this.client.get(`/api/tests/${id}`);
    return data;
  }

  async getTestResults(id: string) {
    const { data } = await this.client.get(`/api/tests/${id}/results`);
    return data;
  }

  async aggregateTestResults(id: string) {
    const { data } = await this.client.post(`/api/tests/${id}/aggregate-results`);
    return data;
  }

  async getTestAgentResults(id: string) {
    const { data } = await this.client.get(`/api/tests/${id}/agent-results`);
    return data;
  }

  async getTestMetrics(id: string) {
    const { data } = await this.client.get(`/api/tests/${id}/metrics`);
    return data;
  }

  async getTestHostMetrics(id: string) {
    const { data } = await this.client.get(`/api/tests/${id}/host-metrics`);
    return data;
  }

  async getTestTransactions(id: string) {
    const { data } = await this.client.get(`/api/tests/${id}/transactions`);
    return data;
  }

  async getTestLogs(id: string) {
    const { data } = await this.client.get(`/api/tests/${id}/logs`);
    return data;
  }

  async getTestResponseCodes(id: string) {
    const { data } = await this.client.get(`/api/tests/${id}/response-codes`);
    return data;
  }

  async getTestLabels(id: string) {
    const { data } = await this.client.get(`/api/tests/${id}/labels`);
    return data;
  }

  async getTestLabelMetrics(id: string, labels: string[], granularity: string = 'auto', selectAll: boolean = false) {
    const params = new URLSearchParams();
    if (selectAll) {
      params.append('all', 'true');
    } else {
      labels.forEach(label => params.append('labels', label));
    }
    params.append('granularity', granularity);
    const { data } = await this.client.get(`/api/tests/${id}/label-metrics?${params.toString()}`);
    return data;
  }

  async deleteTest(id: string) {
    await this.client.delete(`/api/tests/${id}`);
  }

  async deleteTests(testIds: string[]) {
    await this.client.delete('/api/tests', { data: { testIds } });
  }
  
  async createTest(test: {
    projectId: string;
    scriptId: string;
    name: string;
    threads: number;
    duration: number;
    rampUp: number;
    agentIds: string[];
  }) {
    const { data } = await this.client.post('/api/tests', test);
    return data;
  }
  
  async startTest(
    id: string,
    payload?: {
      threadGroups?: { name: string; threads: number; rampUp: number; duration: number }[];
    }
  ) {
    const { data } = await this.client.post(`/api/tests/${id}/start`, payload || {});
    return data;
  }
  
  async stopTest(id: string) {
    const { data } = await this.client.post(`/api/tests/${id}/stop`);
    return data;
  }
  
  // Export
  async exportResults(testId: string, format: 'json' | 'csv', type: 'summary' | 'detailed' | 'metrics') {
    const response = await this.client.get(`/api/export/${testId}`, {
      params: { format, type },
      responseType: 'blob',
    });
    return response.data;
  }

  async downloadJtlFile(testId: string) {
    const response = await this.client.get(`/api/tests/${testId}/download-jtl`, {
      responseType: 'blob',
    });
    return response.data;
  }
  
  // Comparison
  async getComparisons() {
    const { data } = await this.client.get('/api/comparison');
    return data;
  }
  
  async getComparison(id: string) {
    const { data } = await this.client.get(`/api/comparison/${id}`);
    return data;
  }
  
  async createComparison(comparison: { name: string; testIds: string[] }) {
    const { data } = await this.client.post('/api/comparison', comparison);
    return data;
  }
  
  async deleteComparison(id: string) {
    await this.client.delete(`/api/comparison/${id}`);
  }
}

export const api = new ApiClient();
