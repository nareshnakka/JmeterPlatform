#!/bin/bash
# Quick Start Script for JMeter Platform

echo "========================================"
echo "  JMeter Platform - Quick Start"
echo "========================================"
echo ""

# Check if Docker is installed
if ! command -v docker &> /dev/null; then
    echo "❌ Docker is not installed. Please install Docker first."
    echo "   Visit: https://docs.docker.com/get-docker/"
    exit 1
fi

if ! command -v docker-compose &> /dev/null; then
    echo "❌ Docker Compose is not installed. Please install Docker Compose first."
    exit 1
fi

echo "✅ Docker found: $(docker --version)"
echo "✅ Docker Compose found: $(docker-compose --version)"
echo ""

# Setup environment files
echo "📝 Setting up environment files..."

if [ ! -f backend/.env ]; then
    cp backend/.env.example backend/.env
    echo "✅ Created backend/.env"
else
    echo "⚠️  backend/.env already exists (skipping)"
fi

if [ ! -f frontend/.env ]; then
    cp frontend/.env.example frontend/.env
    echo "✅ Created frontend/.env"
else
    echo "⚠️  frontend/.env already exists (skipping)"
fi

echo ""
echo "🐳 Starting Docker containers..."
docker-compose up -d

echo ""
echo "⏳ Waiting for services to be ready..."
sleep 10

# Check if services are running
if docker ps | grep -q jmeter-backend; then
    echo "✅ Backend is running"
else
    echo "❌ Backend failed to start. Check logs: docker logs jmeter-backend"
fi

if docker ps | grep -q jmeter-frontend; then
    echo "✅ Frontend is running"
else
    echo "❌ Frontend failed to start. Check logs: docker logs jmeter-frontend"
fi

if docker ps | grep -q jmeter-postgres; then
    echo "✅ PostgreSQL is running"
else
    echo "❌ PostgreSQL failed to start. Check logs: docker logs jmeter-postgres"
fi

echo ""
echo "========================================"
echo "  🎉 JMeter Platform is Ready!"
echo "========================================"
echo ""
echo "🌐 Frontend:      http://localhost:8080"
echo "🔌 Backend API:   http://localhost:3000"
echo "💾 MinIO Console: http://localhost:9001"
echo ""
echo "📖 Next steps:"
echo "   1. Open http://localhost:8080 in your browser"
echo "   2. Click 'Register' to create an account"
echo "   3. Login and explore the dashboard"
echo ""
echo "📊 View logs:"
echo "   docker logs jmeter-backend -f"
echo "   docker logs jmeter-frontend -f"
echo ""
echo "🛑 Stop services:"
echo "   docker-compose down"
echo ""
