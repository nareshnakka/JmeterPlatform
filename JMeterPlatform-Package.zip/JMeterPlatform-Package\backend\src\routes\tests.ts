import { Router, Request, Response } from 'express';
import { body, validationResult } from 'express-validator';
import { PrismaClient } from '@prisma/client';
import { Server } from 'socket.io';
import { authenticate, AuthRequest } from '../middleware/auth';
import multer from 'multer';
import { Client as MinioClient } from 'minio';
import { parse } from 'csv-parse/sync';
import { startJtlMergeJob } from '../utils/jtlMerger';
import { downloadFile } from '../config/minio';

const router = Router();

// Configure multer with file size limit (3GB max for large JTL files)
const upload = multer({ 
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 3 * 1024 * 1024 * 1024 // 3GB limit
  }
});

// Shared type for per-thread-group configuration
interface ThreadGroupOverrideConfig {
  name: string;
  threads: number;
  rampUp: number;
  duration: number;
}

// In-memory store for per-test (this-run-only) thread-group overrides.
// These are populated when a test is started with overrides from the UI
// and are NOT persisted to the database or script configuration.
const perTestThreadGroupOverrides = new Map<
  string,
  {
    groups: ThreadGroupOverrideConfig[];
  }
>();

// Helper function to aggregate results from multiple agents
async function aggregateTestResults(prisma: PrismaClient, testId: string, completedAgents: any[]) {
  const totalSamples = completedAgents.reduce((sum, ta) => sum + (ta.totalSamples || 0), 0);
  const successfulSamples = completedAgents.reduce((sum, ta) => sum + (ta.successfulSamples || 0), 0);
  const failedSamples = completedAgents.reduce((sum, ta) => sum + (ta.failedSamples || 0), 0);

  // Weighted average response time (weighted by sample count)
  const weightedResponseTime = completedAgents.reduce(
    (sum, ta) => sum + (ta.avgResponseTime || 0) * (ta.totalSamples || 0),
    0
  );
  const avgResponseTime = totalSamples > 0 ? weightedResponseTime / totalSamples : 0;

  // Min/max across all agents
  const minResponseTime =
    completedAgents.length > 0
      ? Math.min(...completedAgents.map((ta) => ta.minResponseTime ?? Infinity))
      : 0;
  const maxResponseTime =
    completedAgents.length > 0
      ? Math.max(...completedAgents.map((ta) => ta.maxResponseTime ?? 0))
      : 0;

  // Aggregate throughput and error rate across agents
  const throughput = completedAgents.reduce((sum, ta) => sum + (ta.throughput || 0), 0);
  const errorRate = totalSamples > 0 ? (failedSamples / totalSamples) * 100 : 0;

  // Compute percentiles from TestMetric entries
  const metrics = await prisma.testMetric.findMany({
    where: { testId },
    select: { responseTime: true },
    orderBy: { responseTime: 'asc' },
  });

  const getPercentile = (p: number): number => {
    if (!metrics || metrics.length === 0) return 0;
    const index = Math.floor(p * (metrics.length - 1));
    const value = metrics[index]?.responseTime;
    return typeof value === 'number' ? value : 0;
  };

  const p50 = getPercentile(0.5);
  const p90 = getPercentile(0.9);
  const p95 = getPercentile(0.95);
  const p99 = getPercentile(0.99);

  return {
    testId,
    totalSamples,
    successfulSamples,
    failedSamples,
    avgResponseTime,
    minResponseTime: Number.isFinite(minResponseTime) ? minResponseTime : 0,
    maxResponseTime,
    throughput,
    errorRate,
    p50,
    p90,
    p95,
    p99,
    resultFilePath: null as string | null,
  };
}

// JMX download for agents
router.get('/:id/jmx', async (req: Request, res: Response): Promise<void> => {
  try {
    const prisma: PrismaClient = req.app.get('prisma');

    const test = await prisma.test.findUnique({
      where: { id: req.params.id as string },
      include: { script: true },
    });

    if (!test || !test.script) {
      res.status(404).json({ error: 'Test not found' });
      return;
    }

    if (!test.script.filePath) {
      res.status(404).json({ error: 'Script file path not set' });
      return;
    }

    console.log(`[JMX Download] Downloading script JMX: ${test.script.filePath}`);

    let jmxBuffer: Buffer;
    try {
      jmxBuffer = await downloadFile(test.script.filePath);
    } catch (err) {
      console.error('[JMX Download] Error downloading JMX from storage:', err);
      res.status(404).json({ error: 'Script file not found in storage' });
      return;
    }

    let jmxContent = jmxBuffer.toString('utf-8');

    let overrideApplied = false;

    // Prefer per-test (this run only) overrides if present; otherwise fall back
    // to the script-level saved scenario configuration.
    let effectiveConfig: { overrideEnabled?: boolean; groups?: ThreadGroupOverrideConfig[] } | null = null;

    const perTestConfig = perTestThreadGroupOverrides.get(test.id);
    if (perTestConfig && Array.isArray(perTestConfig.groups) && perTestConfig.groups.length > 0) {
      effectiveConfig = {
        overrideEnabled: true,
        groups: perTestConfig.groups,
      };
      console.log(
        `[JMX Download] Using per-test thread-group overrides for test ${test.id} (${perTestConfig.groups.length} group(s))`
      );
    } else if (test.script.threadGroupConfig) {
      try {
        effectiveConfig = JSON.parse(test.script.threadGroupConfig) as {
          overrideEnabled?: boolean;
          groups?: ThreadGroupOverrideConfig[];
        };
      } catch (cfgError) {
        console.warn('[JMX Download] Failed to parse script thread group config:', cfgError);
      }
    }

    if (effectiveConfig?.overrideEnabled && Array.isArray(effectiveConfig.groups)) {
      console.log(
        `[JMX Download] Applying per-thread-group overrides for ${effectiveConfig.groups.length} group(s)`
      );

      const escapeRegex = (value: string) => value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

      const normalizedGroups: ThreadGroupOverrideConfig[] = [];
      for (const g of effectiveConfig.groups) {
        if (g && typeof g.name === 'string' && g.name.trim()) {
          normalizedGroups.push({
            name: g.name.trim(),
            threads: Math.max(1, parseInt(String(g.threads ?? 1), 10) || 1),
            rampUp: Math.max(0, parseInt(String(g.rampUp ?? 0), 10) || 0),
            duration: Math.max(1, parseInt(String(g.duration ?? 1), 10) || 1),
          });
        }
      }

      if (normalizedGroups.length > 0) {
        let updatedContent = jmxContent;

        for (const cfg of normalizedGroups) {
          const namePattern = escapeRegex(cfg.name);
          const tgRegex = new RegExp(
            `<ThreadGroup\\b([^>]*?(?:testname=\"${namePattern}\"|name=\"${namePattern}\")[^>]*)>([\\s\\S]*?)<\\/ThreadGroup>`,
            'g'
          );

          updatedContent = updatedContent.replace(tgRegex, (fullMatch, attrs, body) => {
            let newBody = body;

            const replaceNumericProp = (propName: string, value: number) => {
              const propPattern = new RegExp(
                `<(?:stringProp|intProp|longProp) name=\"${propName}\">[\\s\\S]*?<\\/(?:stringProp|intProp|longProp)>`,
                'g'
              );
              const replacement = `<stringProp name=\"${propName}\">${value}<\/stringProp>`;

              if (propPattern.test(newBody)) {
                newBody = newBody.replace(propPattern, replacement);
              } else {
                newBody = newBody.replace(
                  /<\/ThreadGroup>/,
                  `  <stringProp name=\"${propName}\">${value}<\/stringProp>\n      <\/ThreadGroup>`
                );
              }
            };

            const ensureBoolProp = (propName: string, value: boolean) => {
              const propPattern = new RegExp(
                `<boolProp name=\"${propName}\">[\\s\\S]*?<\\/boolProp>`,
                'g'
              );
              const replacement = `<boolProp name=\"${propName}\">${value ? 'true' : 'false'}<\/boolProp>`;

              if (propPattern.test(newBody)) {
                newBody = newBody.replace(propPattern, replacement);
              } else {
                newBody = newBody.replace(
                  /<\/ThreadGroup>/,
                  `  ${replacement}\n      <\/ThreadGroup>`
                );
              }
            };

            replaceNumericProp('ThreadGroup.num_threads', cfg.threads);
            replaceNumericProp('ThreadGroup.ramp_time', cfg.rampUp);
            replaceNumericProp('ThreadGroup.duration', cfg.duration);
            replaceNumericProp('ThreadGroup.delay', 0);
            ensureBoolProp('ThreadGroup.scheduler', true);

            return `<ThreadGroup${attrs}>${newBody}<\/ThreadGroup>`;
          });
        }

        if (updatedContent !== jmxContent) {
          jmxContent = updatedContent;
          overrideApplied = true;
          console.log('[JMX Download] Per-thread-group overrides applied successfully');
        } else {
          console.warn('[JMX Download] WARNING: No matching ThreadGroup elements found for overrides');
        }
      }
    }

    // If no per-thread-group override was applied, fall back to existing global test-level parameters.
    if (!overrideApplied) {
      console.log(
        `[JMX Download] Original JMX contains 'ThreadGroup.duration': ${jmxContent.includes('ThreadGroup.duration')}`
      );
      console.log(
        `[JMX Download] Original JMX contains 'ThreadGroup.scheduler': ${jmxContent.includes('ThreadGroup.scheduler')}`
      );

      // Update num_threads
      const numThreadsMatches = jmxContent.match(
        /(<stringProp name="ThreadGroup\.num_threads">)([^<]*)(<\/stringProp>)/g
      );
      console.log(
        `[JMX Download] Found ${numThreadsMatches ? numThreadsMatches.length : 0} num_threads properties`
      );
      jmxContent = jmxContent.replace(
        /(<stringProp name="ThreadGroup\.num_threads">)([^<]*)(<\/stringProp>)/g,
        `$1${test.threads}$3`
      );
      console.log(`[JMX Download] Updated num_threads to ${test.threads}`);

      // Update ramp_time
      jmxContent = jmxContent.replace(
        /(<stringProp name="ThreadGroup\.ramp_time">)([^<]*)(<\/stringProp>)/g,
        `$1${test.rampUp}$3`
      );
      console.log(`[JMX Download] Updated ramp_time to ${test.rampUp}`);

      // Update or add duration
      const durationRegex = /(<stringProp name="ThreadGroup\.duration">)([^<]*)(<\/stringProp>)/g;
      if (durationRegex.test(jmxContent)) {
        jmxContent = jmxContent.replace(durationRegex, `$1${test.duration}$3`);
        console.log(`[JMX Download] Updated existing duration to ${test.duration}`);
      } else {
        const beforeAdd = jmxContent.length;
        jmxContent = jmxContent.replace(
          /(\s*)<\/ThreadGroup>/,
          `\n          <stringProp name="ThreadGroup.duration">${test.duration}<\/stringProp>$1<\/ThreadGroup>`
        );
        if (jmxContent.length > beforeAdd) {
          console.log(`[JMX Download] Added duration property: ${test.duration}`);
        } else {
          console.error(
            `[JMX Download] CRITICAL: Failed to add duration property - test may run indefinitely!`
          );
        }
      }

      // Update or add delay
      const delayRegex = /(<stringProp name="ThreadGroup\.delay">)([^<]*)(<\/stringProp>)/g;
      if (delayRegex.test(jmxContent)) {
        jmxContent = jmxContent.replace(delayRegex, `$10$3`);
        console.log('[JMX Download] Updated delay to 0');
      } else {
        const beforeAdd = jmxContent.length;
        jmxContent = jmxContent.replace(
          /(<stringProp name="ThreadGroup\.duration">.*?<\/stringProp>)/,
          `$1\n          <stringProp name="ThreadGroup.delay">0<\/stringProp>`
        );
        if (jmxContent.length > beforeAdd) {
          console.log('[JMX Download] Added delay property: 0');
        }
      }

      // Enable scheduler (Specify Thread lifetime checkbox)
      const schedulerRegex = /(<boolProp name="ThreadGroup\.scheduler">)([^<]*)(<\/boolProp>)/g;
      if (schedulerRegex.test(jmxContent)) {
        jmxContent = jmxContent.replace(schedulerRegex, '$1true$3');
        console.log('[JMX Download] Updated scheduler to true');
      } else {
        const beforeAdd = jmxContent.length;
        jmxContent = jmxContent.replace(
          /(<\/ThreadGroup>)/,
          `        <boolProp name="ThreadGroup.scheduler">true<\/boolProp>\n      $1`
        );
        if (jmxContent.length > beforeAdd) {
          console.log('[JMX Download] Added scheduler property');
        } else {
          console.warn('[JMX Download] WARNING: Failed to add scheduler property');
        }
      }
    }

    res.setHeader('Content-Type', 'application/xml');
    res.setHeader('Content-Disposition', `attachment; filename="${test.script.name}"`);
    res.send(jmxContent);

    console.log('[JMX Download] Modified JMX file sent successfully');
  } catch (error) {
    console.error('[JMX Download] Error downloading JMX:', error);
    res.status(500).json({ error: 'Failed to download script' });
  }
});

// Get test dependencies for agent
router.get('/:id/dependencies', async (req: Request, res: Response): Promise<void> => {
  try {
    const prisma: PrismaClient = req.app.get('prisma');
    
    if (!prisma) {
      console.error('[Dependencies] Prisma client not initialized');
      res.json([]);
      return;
    }
    
    const dependencies = await prisma.dependency.findMany({
      where: {
        script: {
          tests: {
            some: { id: req.params.id as string }
          }
        }
      }
    }).catch((err: any) => {
      console.error('[Dependencies] Query error:', err);
      return [];
    });
    
    // Return empty array if no dependencies
    res.json(dependencies || []);
    
  } catch (error) {
    console.error('Error fetching dependencies:', error);
    res.json([]); // Return empty array instead of error
  }
});

// Get test status (for agent to check if cancelled)
router.get('/:id/status', async (req: Request, res: Response): Promise<void> => {
  try {
    const prisma: PrismaClient = req.app.get('prisma');
    
    const test = await prisma.test.findUnique({
      where: { id: req.params.id as string },
      select: { status: true }
    });
    
    if (!test) {
      res.status(404).json({ error: 'Test not found' });
      return;
    }
    
    res.json({ status: test.status });
    
  } catch (error) {
    console.error('Error fetching test status:', error);
    res.status(500).json({ error: 'Failed to fetch test status' });
  }
});

// Receive metrics from agent (during test execution)
router.post('/:id/metrics', async (req: Request, res: Response): Promise<void> => {
  try {
    const prisma: PrismaClient = req.app.get('prisma');
    const { agentId, responseTime, throughput, errorRate, activeThreads, transactions } = req.body;
    
    console.log(`[Metrics] Agent ${agentId} for test ${req.params.id as string}: RT=${responseTime}ms, TP=${throughput}, Err=${errorRate}%, Threads=${activeThreads}, Transactions=${transactions?.length || 0}`);
    
    // Store transaction-level metrics if provided
    if (transactions && Array.isArray(transactions) && transactions.length > 0) {
      const timestamp = new Date();
      for (const txn of transactions) {
        await prisma.testMetric.create({
          data: {
            testId: req.params.id as string,
            timestamp,
            label: txn.label,  // Store actual transaction label
            responseTime: txn.avg || 0,
            statusCode: 200,
            success: (txn.fail || 0) === 0,
            bytes: 0,
            threads: activeThreads || 0,
            latency: txn.avg || 0
          }
        });
      }
    }
    
    // Store per-agent metric with agent identifier for tracking
    const metric = await prisma.testMetric.create({
      data: {
        testId: req.params.id as string,
        timestamp: new Date(),
        label: `agent-${agentId}`,  // Store with agent ID for tracking
        responseTime: responseTime || 0,
        statusCode: 200,
        success: errorRate < 100,
        bytes: 0,
        threads: activeThreads || 0,
        latency: responseTime || 0
      }
    });
    
    // Get latest metrics from each agent (within last 10 seconds)
    const tenSecondsAgo = new Date(Date.now() - 10000);
    const recentMetrics = await prisma.testMetric.groupBy({
      by: ['label'],
      where: {
        testId: req.params.id as string,
        timestamp: { gte: tenSecondsAgo },
        label: { startsWith: 'agent-' }
      },
      _avg: {
        responseTime: true,
        threads: true
      },
      _sum: {
        threads: true
      },
      _max: {
        timestamp: true
      }
    });
    
    // Build per-agent latest metrics map
    const agentMetricsMap: Record<string, any> = {};
    for (const m of recentMetrics) {
      agentMetricsMap[m.label] = {
        avgResponseTime: m._avg.responseTime || 0,
        activeThreads: m._avg.threads || 0,
        lastUpdate: m._max.timestamp
      };
    }
    
    // Store current agent's metrics temporarily for aggregation
    if (!agentMetricsMap[`agent-${agentId}`]) {
      agentMetricsMap[`agent-${agentId}`] = {
        avgResponseTime: responseTime || 0,
        throughput: throughput || 0,
        errorRate: errorRate || 0,
        activeThreads: activeThreads || 0,
        transactions: transactions || []
      };
    } else {
      agentMetricsMap[`agent-${agentId}`].throughput = throughput || 0;
      agentMetricsMap[`agent-${agentId}`].errorRate = errorRate || 0;
      agentMetricsMap[`agent-${agentId}`].transactions = transactions || [];
    }
    
    // Aggregate metrics from all agents that reported recently
    let totalThroughput = 0;
    let totalActiveThreads = 0;
    let weightedResponseTime = 0;
    let weightedErrorRate = 0;
    let totalWeight = 0;
    const aggregatedTransactions: Record<string, any> = {};
    
    // Aggregate from all recent agent metrics
    Object.keys(agentMetricsMap).forEach(agentLabel => {
      const agentData = agentMetricsMap[agentLabel];
      const weight = agentData.activeThreads || 1;
      
      totalThroughput += agentData.throughput || 0;
      totalActiveThreads += agentData.activeThreads || 0;
      weightedResponseTime += (agentData.avgResponseTime || 0) * weight;
      weightedErrorRate += (agentData.errorRate || 0) * weight;
      totalWeight += weight;
      
      // Aggregate transactions by label
      if (agentData.transactions && Array.isArray(agentData.transactions)) {
        agentData.transactions.forEach((txn: any) => {
          if (!aggregatedTransactions[txn.label]) {
            aggregatedTransactions[txn.label] = {
              label: txn.label,
              samples: [],
              pass: 0,
              fail: 0
            };
          }
          aggregatedTransactions[txn.label].pass += txn.pass || 0;
          aggregatedTransactions[txn.label].fail += txn.fail || 0;
          aggregatedTransactions[txn.label].samples.push(txn.avg);
        });
      }
    });
    
    const aggregatedResponseTime = totalWeight > 0 ? weightedResponseTime / totalWeight : 0;
    const aggregatedErrorRate = totalWeight > 0 ? weightedErrorRate / totalWeight : 0;
    
    // Calculate aggregated transaction metrics
    const aggregatedTransactionList = Object.values(aggregatedTransactions).map((txn: any) => {
      const totalSamples = txn.pass + txn.fail;
      const avgResponseTime = txn.samples.length > 0 
        ? txn.samples.reduce((sum: number, val: number) => sum + val, 0) / txn.samples.length 
        : 0;
      
      return {
        label: txn.label,
        avg: parseFloat(avgResponseTime.toFixed(2)),
        pass: txn.pass,
        fail: txn.fail,
        errorRate: totalSamples > 0 ? parseFloat(((txn.fail / totalSamples) * 100).toFixed(2)) : 0
      };
    });
    
    console.log(`[Metrics] Aggregated from ${Object.keys(agentMetricsMap).length} agents: RT=${aggregatedResponseTime.toFixed(2)}ms, TP=${totalThroughput.toFixed(2)}, Err=${aggregatedErrorRate.toFixed(2)}%, Threads=${totalActiveThreads}`);
    
    // Emit AGGREGATED metrics to WebSocket for live dashboard
    const io: Server = req.app.get('io');
    if (io) {
      io.to(`test:${req.params.id as string}`).emit('metrics', {
        timestamp: metric.timestamp,
        responseTime: parseFloat(aggregatedResponseTime.toFixed(2)),
        throughput: parseFloat(totalThroughput.toFixed(2)),
        errorRate: parseFloat(aggregatedErrorRate.toFixed(2)),
        activeThreads: totalActiveThreads,
        transactions: aggregatedTransactionList,
        agentCount: Object.keys(agentMetricsMap).length
      });
      console.log(`[WebSocket] Emitted aggregated metrics from ${Object.keys(agentMetricsMap).length} agents to room test:${req.params.id as string}`);
    }
    
    res.status(201).json(metric);
    
  } catch (error) {
    console.error('Error storing metrics:', error);
    res.status(500).json({ error: 'Failed to store metrics' });
  }
});

// Update test status from agent
router.put('/:id/status', async (req: Request, res: Response): Promise<void> => {
  try {
    const prisma: PrismaClient = req.app.get('prisma');
    const { status, error } = req.body;
    
    console.log(`[Status Update] Test ${req.params.id as string} -> ${status}${error ? ` (error: ${error})` : ''}`);
    
    const updateData: any = {
      status: status
    };
    
    if (status === 'completed') {
      updateData.completedAt = new Date();
    } else if (status === 'running' && !updateData.startedAt) {
      updateData.startedAt = new Date();
    }
    
    if (error) {
      updateData.error = error;
    }
    
    const test = await prisma.test.update({
      where: { id: req.params.id as string },
      data: updateData
    });
    
    // Emit to WebSocket for real-time updates
    const io: Server = req.app.get('io');
    if (io) {
      io.to(`test:${req.params.id as string}`).emit('statusUpdate', {
        status: test.status,
        completedAt: test.completedAt
      });
    }

      // Clear any per-test overrides once the test reaches a terminal state
      if (['completed', 'failed', 'cancelled'].includes(status)) {
        perTestThreadGroupOverrides.delete(req.params.id as string);
      }
    
    res.json(test);
    
  } catch (error: any) {
    if (error.code === 'P2025') {
      // Test not found (probably deleted)
      console.log(`[Status Update] Test ${req.params.id as string} not found (may have been deleted)`);
      res.status(404).json({ error: 'Test not found' });
    } else {
      console.error('Error updating test status:', error);
      res.status(500).json({ error: 'Failed to update test status' });
    }
  }
});

// Submit test results (from agent)
router.post('/:id/results', (req: any, res: Response, next: any): void => {
  // Handle multer upload with custom error handling
  upload.single('result')(req, res, (err: any): void => {
    if (err) {
      if (err.code === 'LIMIT_FILE_SIZE') {
        console.error(`[Results Upload] File too large: ${err.message}`);
        res.status(413).json({ 
          error: 'File too large',
          message: 'JTL file exceeds 3GB limit. Consider splitting the test or reducing duration.',
          maxSize: '3GB'
        });
        return;
      }
      console.error(`[Results Upload] Upload error: ${err.message}`);
      res.status(500).json({ error: 'File upload failed', details: err.message });
      return;
    }
    next();
  });
}, async (req: any, res: Response): Promise<void> => {
  try {
    const prisma: PrismaClient = req.app.get('prisma');
    const io: Server = req.app.get('io');
    const minioClient: MinioClient = req.app.get('minio');
    const testId = req.params.id as string;
    const agentId = req.body.agentId;
    
    console.log(`[Results Upload] Received for test ${testId} from agent ${agentId}`);
    
    if (!agentId) {
      res.status(400).json({ error: 'agentId is required' });
      return;
    }
    
    let resultFilePath: string | undefined;
    
    // Upload JTL file to MinIO if provided (agent-specific path)
    if (req.file) {
      const bucketName = 'jmeter-results';
      const objectName = `${testId}/agent-${agentId}-results.jtl`;
      const fileSize = req.file.size;
      
      console.log(`[Results Upload] JTL file size: ${(fileSize / 1024 / 1024).toFixed(2)} MB`);
      
      try {
        // Ensure bucket exists
        const bucketExists = await minioClient.bucketExists(bucketName);
        if (!bucketExists) {
          await minioClient.makeBucket(bucketName, 'us-east-1');
          console.log(`[Results Upload] Created bucket: ${bucketName}`);
        }
        
        // Upload file to MinIO (streaming, handles large files)
        await minioClient.putObject(
          bucketName,
          objectName,
          req.file.buffer,
          req.file.size,
          { 'Content-Type': 'text/csv' }
        );
        
        resultFilePath = `${bucketName}/${objectName}`;
        console.log(`[Results Upload] JTL file uploaded to MinIO: ${resultFilePath}`);
        
        // For large files (>100MB), use sampling strategy instead of storing all metrics
        const isLargeFile = fileSize > 100 * 1024 * 1024; // 100MB threshold
        
        if (isLargeFile) {
          console.log(`[Results Upload] Large file detected (${(fileSize / 1024 / 1024).toFixed(2)} MB) - using sampling strategy`);
          
          // Don't parse and store individual metrics for large files
          // The summary metrics from agent are sufficient
          // Individual metrics can be downloaded from MinIO if needed for detailed analysis
          
        } else {
          // For smaller files, store sampled metrics for charting
          console.log(`[Results Upload] Processing metrics with sampling...`);
          
          const jtlContent = req.file.buffer.toString('utf-8');
          const lines = jtlContent.split('\n').filter((line: string) => line.trim());
          
          if (lines.length > 1) {
            // Parse CSV (skip header)
            const records = parse(jtlContent, {
              columns: true,
              skip_empty_lines: true,
              trim: true
            });
            
            // Sample metrics to avoid database bloat
            // Store every Nth record, or max 10,000 records
            const totalRecords = records.length;
            const maxStoredRecords = 10000;
            const samplingRate = Math.max(1, Math.ceil(totalRecords / maxStoredRecords));
            
            console.log(`[Results Upload] Total records: ${totalRecords}, sampling rate: 1/${samplingRate}`);
            
            const metricsToCreate = records
              .filter((_: any, index: number) => index % samplingRate === 0)
              .map((record: any) => ({
                testId: testId,
                timestamp: new Date(parseInt(record.timeStamp)),
                label: record.label || 'unknown',
                responseTime: parseFloat(record.elapsed || '0'),
                statusCode: parseInt(record.responseCode || '200'),
                success: record.success === 'true',
                bytes: parseInt(record.bytes || '0'),
                threads: parseInt(record.allThreads || '1'),
                latency: parseFloat(record.Latency || '0')
              }));
            
            // Batch insert metrics (in chunks)
            const chunkSize = 1000;
            for (let i = 0; i < metricsToCreate.length; i += chunkSize) {
              const chunk = metricsToCreate.slice(i, i + chunkSize);
              await prisma.testMetric.createMany({
                data: chunk
              });
            }
            
            console.log(`[Results Upload] Stored ${metricsToCreate.length} sampled metrics (from ${totalRecords} total) to database`);
          }
        }
        
      } catch (minioError) {
        console.error('[Results Upload] MinIO error:', minioError);
        // Continue even if MinIO fails
      }
    }
    
    // Parse summary results from request body
    const results = req.body;
    
    // Save results to the specific TestAgent record
    const testAgent = await prisma.testAgent.update({
      where: {
        testId_agentId: {
          testId: testId,
          agentId: agentId
        }
      },
      data: {
        status: 'completed',
        completedAt: new Date(),
        resultFilePath: resultFilePath,
        totalSamples: results.totalSamples || 0,
        successfulSamples: results.successfulSamples || 0,
        failedSamples: results.failedSamples || 0,
        avgResponseTime: results.avgResponseTime || 0,
        minResponseTime: results.minResponseTime || 0,
        maxResponseTime: results.maxResponseTime || 0,
        throughput: results.throughput || 0,
        errorRate: results.errorRate || 0
      },
      include: { agent: true }
    });
    
    console.log(`[Results Upload] Agent ${testAgent.agent.name} results saved: ${results.totalSamples} samples`);
    
    // Check if all agents have completed
    const allAgents = await prisma.testAgent.findMany({
      where: { testId: testId },
      include: { agent: true }
    });
    
    const completedAgents = allAgents.filter(ta => ta.status === 'completed');
    const allCompleted = completedAgents.length === allAgents.length;
    
    console.log(`[Results Upload] ${completedAgents.length}/${allAgents.length} agents completed`);
    
    if (allCompleted) {
      // All agents finished - aggregate results
      console.log(`[Results Upload] All agents completed - aggregating results`);
      
      const aggregatedResults = await aggregateTestResults(prisma, testId, completedAgents);
      
      // Create aggregated test result
      const testResult = await prisma.testResult.upsert({
        where: { testId: testId },
        create: aggregatedResults,
        update: aggregatedResults
      });
      
      console.log(`[Results Upload] Aggregated results: ${testResult.totalSamples} total samples, ${testResult.avgResponseTime.toFixed(2)}ms avg`);
      
      // Emit aggregated results via WebSocket
      io.to(`test:${testId}`).emit('test:results', testResult);
      io.to(`test:${testId}`).emit('test:completed', { testId, result: testResult });
      
      // Start background job to merge JTL files
      const agentJtlPaths = completedAgents
        .map(ta => ta.resultFilePath)
        .filter((path): path is string => !!path);
      
      if (agentJtlPaths.length > 0) {
        console.log(`[Results Upload] Starting background JTL merge for ${agentJtlPaths.length} agent files`);
        const minioClient: MinioClient = req.app.get('minioClient');
        startJtlMergeJob(prisma, minioClient, testId, agentJtlPaths);
      } else {
        // No JTL files to merge - just mark as completed
        await prisma.test.update({
          where: { id: testId },
          data: {
            status: 'completed',
            completedAt: new Date()
          }
        });
      }
    }
    
    res.json({ success: true, agentCompleted: true, allCompleted });
  } catch (error) {
    console.error('[Results Upload] Error submitting results:', error);
    res.status(500).json({ error: 'Failed to submit results' });
  }
});

// ==========================================
// AUTHENTICATED ENDPOINTS (require user login)
// ==========================================

router.use(authenticate);

// Get test results
router.get('/:id/results', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { id } = req.params;
    const prisma: PrismaClient = req.app.get('prisma');
    
    // First check if test exists
    const test = await prisma.test.findUnique({
      where: { id: id as string },
      select: { status: true }
    });
    
    if (!test) {
      res.status(404).json({ error: 'Test not found' });
      return;
    }
    
    const result = await prisma.testResult.findUnique({
      where: { testId: id as string }
    });
    
    if (!result) {
      console.log(`[Results] No results found for test ${id}, status: ${test.status}`);
      res.status(404).json({ 
        error: 'Test results not found',
        status: test.status,
        message: test.status === 'running' ? 'Test is still in progress' : 
                 test.status === 'collating' ? 'Test completed, collating results...' :
                 'Results not yet available'
      });
      return;
    }
    
    res.json(result);
  } catch (error) {
    console.error('Error fetching test results:', error);
    res.status(500).json({ error: 'Failed to fetch test results' });
  }
});

// Get per-agent results breakdown
router.get('/:id/agent-results', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { id } = req.params;
    const prisma: PrismaClient = req.app.get('prisma');
    
    const agentResults = await prisma.testAgent.findMany({
      where: { testId: id as string },
      include: {
        agent: {
          select: {
            id: true,
            name: true,
            location: true
          }
        }
      },
      orderBy: { agent: { name: 'asc' } }
    });
    
    res.json(agentResults);
  } catch (error) {
    console.error('Error fetching agent results:', error);
    res.status(500).json({ error: 'Failed to fetch agent results' });
  }
});

// Get all tests for current user
router.get('/', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const prisma: PrismaClient = req.app.get('prisma');
    
    const tests = await prisma.test.findMany({
      where: {
        project: {
          userId: req.user!.id
        }
      },
      include: {
        project: {
          select: {
            name: true,
            id: true
          }
        },
        script: {
          select: {
            name: true,
            id: true
          }
        },
        testAgents: {
          include: {
            agent: {
              select: {
                id: true,
                name: true,
                location: true
              }
            }
          }
        },
        results: true
      },
      orderBy: {
        createdAt: 'desc'
      }
    });
    
    res.json(tests);
  } catch (error) {
    console.error('Error fetching tests:', error);
    res.status(500).json({ error: 'Failed to fetch tests' });
  }
});

// Create test
router.post(
  '/',
  [
    body('projectId').isUUID(),
    body('scriptId').isUUID(),
    body('name').trim().isLength({ min: 1 }),
    body('threads').isInt({ min: 1 }),
    body('duration').isInt({ min: 1 }),
    body('rampUp').isInt({ min: 0 }),
    body('agentIds').isArray({ min: 1 })
  ],
  async (req: AuthRequest, res: Response): Promise<void> => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        res.status(400).json({ errors: errors.array() });

        return;
      }
      
      const prisma: PrismaClient = req.app.get('prisma');
      const { projectId, scriptId, name, threads, duration, rampUp, agentIds } = req.body;
      
      // Verify project ownership
      const project = await prisma.project.findFirst({
        where: { id: projectId, userId: req.user!.id }
      });
      
      if (!project) {
        res.status(404).json({ error: 'Project not found' });

        return;
      }
      
      // Verify agents exist and are online
      const agents = await prisma.agent.findMany({
        where: { id: { in: agentIds }, status: 'online' }
      });
      
      if (agents.length !== agentIds.length) {
        res.status(400).json({ error: 'One or more agents are unavailable' });

        return;
      }
      
      // Calculate threads per agent
      const threadsPerAgent = Math.floor(threads / agents.length);
      
      // Create test
      const test = await prisma.test.create({
        data: {
          projectId,
          scriptId,
          name,
          threads,
          duration,
          rampUp,
          status: 'pending',
          testAgents: {
            create: agents.map(agent => ({
              agentId: agent.id,
              threads: threadsPerAgent,
              status: 'pending'
            }))
          }
        },
        include: {
          testAgents: {
            include: { agent: true }
          }
        }
      });
      
      res.status(201).json(test);
    } catch (error) {
      console.error('Error creating test:', error);
      res.status(500).json({ error: 'Failed to create test' });
    }
  }
);

// Get response code summary from JTL file
router.get('/:id/response-codes', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const prisma: PrismaClient = req.app.get('prisma');
    const minioClient: MinioClient = req.app.get('minio');
    const testId = req.params.id as string;
    
    const test = await prisma.test.findFirst({
      where: { 
        id: testId,
        project: { userId: req.user!.id }
      },
      include: {
        results: true,
        testAgents: {
          where: { status: 'completed' },
          take: 1
        }
      }
    });
    
    if (!test) {
      res.status(404).json({ error: 'Test not found' });
      return;
    }
    
    if (test.status !== 'completed' && test.status !== 'collating') {
      res.status(400).json({ error: 'Test is not completed yet' });
      return;
    }
    
    // Prefer merged JTL, fallback to aggregated result, then first agent's file
    const jtlPath = test.mergedJtlPath || 
                    test.results?.resultFilePath || 
                    test.testAgents[0]?.resultFilePath;
    
    if (!jtlPath) {
      res.status(404).json({ error: 'JTL file not found for this test' });
      return;
    }
    
    try {
      // Parse the result file path
      const pathParts = jtlPath.split('/');
      const bucketName = pathParts[0];
      const objectName = pathParts.slice(1).join('/');
      
      console.log(`[Response Codes] Reading from MinIO: ${bucketName}/${objectName}`);
      
      // Get file from MinIO
      const dataStream = await minioClient.getObject(bucketName, objectName);
      
      // Count response codes
      const responseCodeCounts: Record<string, number> = {};
      
      const csvParser = require('csv-parser');
      
      await new Promise<void>((resolve, reject) => {
        dataStream
          .pipe(csvParser())
          .on('data', (row: any) => {
            const responseCode = row.responseCode || row.rc;
            if (responseCode) {
              responseCodeCounts[responseCode] = (responseCodeCounts[responseCode] || 0) + 1;
            }
          })
          .on('end', () => {
            console.log(`[Response Codes] Parsed response codes:`, responseCodeCounts);
            resolve();
          })
          .on('error', (err: Error) => {
            console.error('[Response Codes] Error parsing JTL:', err);
            reject(err);
          });
      });
      
      res.json(responseCodeCounts);
      
    } catch (minioError) {
      console.error('[Response Codes] Error reading from MinIO:', minioError);
      res.status(404).json({ error: 'JTL file not found in storage' });
    }
    
  } catch (error) {
    console.error('Error fetching response codes:', error);
    res.status(500).json({ error: 'Failed to fetch response codes' });
  }
});

// Get available labels from JTL file
router.get('/:id/labels', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const prisma: PrismaClient = req.app.get('prisma');
    const minioClient: MinioClient = req.app.get('minio');
    const testId = req.params.id as string;
    
    const test = await prisma.test.findFirst({
      where: { 
        id: testId,
        project: { userId: req.user!.id }
      },
      include: {
        results: true,
        testAgents: {
          where: { status: 'completed' },
          take: 1
        }
      }
    });
    
    if (!test) {
      res.status(404).json({ error: 'Test not found' });
      return;
    }
    
    // Prefer merged JTL, fallback to aggregated result, then first agent's file
    const jtlPath = test.mergedJtlPath || 
                    test.results?.resultFilePath || 
                    test.testAgents[0]?.resultFilePath;
    
    if (!jtlPath) {
      res.status(404).json({ error: 'JTL file not found for this test' });
      return;
    }
    
    try {
      const csvParser = require('csv-parser');
      
      const pathParts = jtlPath.split('/');
      const bucketName = pathParts[0];
      const objectName = pathParts.slice(1).join('/');
      
      console.log(`[Labels] Reading from: ${jtlPath}`);
      
      const dataStream = await minioClient.getObject(bucketName, objectName);
      
      const labels = new Set<string>();
      
      await new Promise<void>((resolve, reject) => {
        dataStream
          .pipe(csvParser())
          .on('data', (row: any) => {
            const label = row.label || row.Label;
            if (label) {
              labels.add(label);
            }
          })
          .on('end', () => {
            resolve();
          })
          .on('error', (err: Error) => {
            reject(err);
          });
      });
      
      res.json(Array.from(labels).sort());
      
    } catch (minioError) {
      console.error('[Labels] Error reading from MinIO:', minioError);
      res.status(404).json({ error: 'JTL file not found in storage' });
    }
    
  } catch (error) {
    console.error('Error fetching labels:', error);
    res.status(500).json({ error: 'Failed to fetch labels' });
  }
});

// Get label metrics time series
router.get('/:id/label-metrics', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const prisma: PrismaClient = req.app.get('prisma');
    const minioClient: MinioClient = req.app.get('minio');
    const testId = req.params.id as string;
    
    const test = await prisma.test.findFirst({
      where: { 
        id: testId,
        project: { userId: req.user!.id }
      },
      include: {
        results: true,
        testAgents: {
          where: { status: 'completed' },
          take: 1
        }
      }
    });
    
    if (!test) {
      res.status(404).json({ error: 'Test not found' });
      return;
    }
    
    // Prefer merged JTL, fallback to aggregated result, then first agent's file
    const jtlPath = test.mergedJtlPath || 
                    test.results?.resultFilePath || 
                    test.testAgents[0]?.resultFilePath;
    
    if (!jtlPath) {
      res.status(404).json({ error: 'JTL file not found for this test' });
      return;
    }
    
    const fetchAll = req.query.all === 'true';
    
    let selectedLabels: string[] = [];
    
    if (!fetchAll) {
      selectedLabels = Array.isArray(req.query.labels) 
        ? req.query.labels.map(String) 
        : req.query.labels 
          ? [String(req.query.labels)] 
          : [];
      
      console.log(`[Label Metrics] Received ${selectedLabels.length} selected labels:`, selectedLabels);
      
      if (selectedLabels.length === 0) {
        res.json({ series: [], timestamps: [] });
        return;
      }
    } else {
      console.log(`[Label Metrics] Fetching all labels`);
    }
    
    const granularity = (req.query.granularity as string) || 'auto';
    
    try {
      const csvParser = require('csv-parser');
      
      const pathParts = jtlPath.split('/');
      const bucketName = pathParts[0];
      const objectName = pathParts.slice(1).join('/');
      
      console.log(`[Label Metrics] Reading from: ${jtlPath}`);
      
      const dataStream = await minioClient.getObject(bucketName, objectName);
      
      const dataPoints: Array<{ timestamp: number; label: string; elapsed: number }> = [];
      const uniqueLabels = new Set<string>();
      
      await new Promise<void>((resolve, reject) => {
        dataStream
          .pipe(csvParser())
          .on('data', (row: any) => {
            const label = row.label || row.Label;
            const timestamp = parseInt(row.timeStamp || row.timestamp);
            const elapsed = parseInt(row.elapsed || row.Latency);
            
            // If fetchAll, include all labels, otherwise filter by selectedLabels
            const shouldInclude = fetchAll || selectedLabels.includes(label);
            
            if (label && shouldInclude && !isNaN(timestamp) && !isNaN(elapsed)) {
              dataPoints.push({ timestamp, label, elapsed });
              if (fetchAll) {
                uniqueLabels.add(label);
              }
            }
          })
          .on('end', () => {
            if (fetchAll) {
              selectedLabels = Array.from(uniqueLabels).sort();
              console.log(`[Label Metrics] Fetched all labels (${selectedLabels.length}):`, selectedLabels);
            }
            console.log(`[Label Metrics] Parsed ${dataPoints.length} data points`);
            resolve();
          })
          .on('error', (err: Error) => {
            reject(err);
          });
      });
      
      if (dataPoints.length === 0) {
        res.json({ series: [], timestamps: [] });
        return;
      }
      
      // Sort by timestamp
      dataPoints.sort((a, b) => a.timestamp - b.timestamp);
      
      const minTimestamp = dataPoints[0].timestamp;
      const maxTimestamp = dataPoints[dataPoints.length - 1].timestamp;
      const duration = maxTimestamp - minTimestamp;
      
      // Calculate bucket size based on granularity
      let bucketSize: number; // in milliseconds
      
      if (granularity === 'auto') {
        // Aim for ~200-400 data points
        const targetPoints = 300;
        bucketSize = Math.ceil(duration / targetPoints / 1000) * 1000;
        
        // Round to nearest sensible interval
        if (bucketSize < 1000) bucketSize = 1000; // 1s
        else if (bucketSize < 10000) bucketSize = 10000; // 10s
        else if (bucketSize < 30000) bucketSize = 30000; // 30s
        else if (bucketSize < 60000) bucketSize = 60000; // 1min
        else if (bucketSize < 300000) bucketSize = 300000; // 5min
        else if (bucketSize < 600000) bucketSize = 600000; // 10min
        else if (bucketSize < 1200000) bucketSize = 1200000; // 20min
        else if (bucketSize < 1800000) bucketSize = 1800000; // 30min
        else bucketSize = 3600000; // 1hr
      } else {
        const granularityMap: Record<string, number> = {
          '1s': 1000,
          '10s': 10000,
          '30s': 30000,
          '1min': 60000,
          '5min': 300000,
          '10min': 600000,
          '20min': 1200000,
          '30min': 1800000,
          '1hr': 3600000
        };
        bucketSize = granularityMap[granularity] || 60000;
      }
      
      // Group data into buckets
      const buckets: Record<number, Record<string, { sum: number; count: number }>> = {};
      
      dataPoints.forEach(({ timestamp, label, elapsed }) => {
        const bucketKey = Math.floor((timestamp - minTimestamp) / bucketSize) * bucketSize + minTimestamp;
        
        if (!buckets[bucketKey]) {
          buckets[bucketKey] = {};
        }
        
        if (!buckets[bucketKey][label]) {
          buckets[bucketKey][label] = { sum: 0, count: 0 };
        }
        
        buckets[bucketKey][label].sum += elapsed;
        buckets[bucketKey][label].count++;
      });
      
      // Convert to time series format
      const timestamps = Object.keys(buckets).map(Number).sort((a, b) => a - b);
      const series: Record<string, number[]> = {};
      
      selectedLabels.forEach(label => {
        series[label as string] = timestamps.map(ts => {
          const bucket = buckets[ts][label as string];
          return bucket ? Math.round(bucket.sum / bucket.count) : null as any;
        });
      });
      
      res.json({
        timestamps: timestamps.map(ts => new Date(ts).toISOString()),
        series,
        granularity: granularity === 'auto' ? `${bucketSize / 1000}s` : granularity
      });
      
    } catch (minioError) {
      console.error('[Label Metrics] Error reading from MinIO:', minioError);
      res.status(404).json({ error: 'JTL file not found in storage' });
    }
    
  } catch (error) {
    console.error('Error fetching label metrics:', error);
    res.status(500).json({ error: 'Failed to fetch label metrics' });
  }
});

// Get test by ID
router.get('/:id', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const prisma: PrismaClient = req.app.get('prisma');
    const testId = req.params.id as string;
    
    const test = await prisma.test.findFirst({
      where: { id: testId },
      include: {
        project: true,
        script: {
          include: { dependencies: true }
        },
        testAgents: {
          include: { agent: true }
        },
        results: true,
        tags: true,
        notes: { orderBy: { createdAt: 'desc' } }
      }
    });
    
    if (!test || test.project.userId !== req.user!.id) {
      res.status(404).json({ error: 'Test not found' });

      return;
    }
    
    res.json(test);
  } catch (error) {
    console.error('Error fetching test:', error);
    res.status(500).json({ error: 'Failed to fetch test' });
  }
});

// Start test
router.post('/:id/start', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const prisma: PrismaClient = req.app.get('prisma');
    const io: Server = req.app.get('io');
    const testId = req.params.id as string;
    
    const test = await prisma.test.findFirst({
      where: { id: testId },
      include: {
        project: true,
        testAgents: { include: { agent: true } }
      }
    });
    
    if (!test || test.project.userId !== req.user!.id) {
      res.status(404).json({ error: 'Test not found' });

      return;
    }

    // Capture any per-test (this-run-only) thread-group overrides sent from the UI
    const { threadGroups } = (req.body || {}) as {
      threadGroups?: Array<{
        name: string;
        threads?: number;
        rampUp?: number;
        duration?: number;
      }>;
    };

    if (Array.isArray(threadGroups) && threadGroups.length > 0) {
      const normalizedGroups: ThreadGroupOverrideConfig[] = [];
      for (const g of threadGroups) {
        if (!g || typeof g.name !== 'string' || !g.name.trim()) continue;
        const name = g.name.trim();
        const threadsVal = Math.max(
          1,
          parseInt(String(g.threads ?? test.threads ?? 1), 10) || 1
        );
        const rampUpVal = Math.max(
          0,
          parseInt(String(g.rampUp ?? test.rampUp ?? 0), 10) || 0
        );
        const durationVal = Math.max(
          1,
          parseInt(String(g.duration ?? test.duration ?? 1), 10) || 1
        );
        normalizedGroups.push({
          name,
          threads: threadsVal,
          rampUp: rampUpVal,
          duration: durationVal,
        });
      }

      if (normalizedGroups.length > 0) {
        perTestThreadGroupOverrides.set(testId, { groups: normalizedGroups });
        console.log(
          `[Start Test] Stored per-test thread-group overrides for test ${testId}: ${normalizedGroups.length} group(s)`
        );
      } else {
        perTestThreadGroupOverrides.delete(testId);
      }
    } else {
      perTestThreadGroupOverrides.delete(testId);
    }
    
    if (test.status !== 'pending') {
      res.status(400).json({ error: 'Test cannot be started' });

      return;
    }
    
    // Check if agents are online
    const onlineAgents = test.testAgents.filter(ta => ta.agent.status === 'online');
    if (onlineAgents.length === 0) {
      res.status(400).json({ error: 'No online agents available for this test' });

      return;
    }
    
    // Update test status
    const updatedTest = await prisma.test.update({
      where: { id: testId },
      data: {
        status: 'running',
        startedAt: new Date(),
        testAgents: {
          updateMany: {
            where: { testId: testId },
            data: { status: 'pending' }
          }
        }
      },
      include: {
        testAgents: { include: { agent: true } }
      }
    });
    
    // Emit WebSocket event
    io.to(`test:${test.id}`).emit('test:status', {
      testId: test.id,
      status: 'running',
      startedAt: updatedTest.startedAt
    });
    
    console.log(`✅ Test ${test.id} started - ${onlineAgents.length} agents will pick it up`);
    
    res.json(updatedTest);
  } catch (error) {
    console.error('Error starting test:', error);
    res.status(500).json({ error: 'Failed to start test' });
  }
});

// Stop test
router.post('/:id/stop', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const prisma: PrismaClient = req.app.get('prisma');
    const io: Server = req.app.get('io');
    const testId = req.params.id as string;
    
    const test = await prisma.test.findFirst({
      where: { id: testId },
      include: { project: true }
    });
    
    if (!test || test.project.userId !== req.user!.id) {
      res.status(404).json({ error: 'Test not found' });

      return;
    }
    
    const updatedTest = await prisma.test.update({
      where: { id: testId },
      data: {
        status: 'cancelled',
        completedAt: new Date()
      }
    });
    
    io.to(`test:${test.id}`).emit('test:status', {
      testId: test.id,
      status: 'cancelled',
      completedAt: updatedTest.completedAt
    });
    
    res.json(updatedTest);
  } catch (error) {
    console.error('Error stopping test:', error);
    res.status(500).json({ error: 'Failed to stop test' });
  }
});

// Get tests for project
router.get('/project/:projectId', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const prisma: PrismaClient = req.app.get('prisma');
    
    const project = await prisma.project.findFirst({
      where: { id: req.params.projectId as string, userId: req.user!.id }
    });
    
    if (!project) {
      res.status(404).json({ error: 'Project not found' });

      return;
    }
    
    const tests = await prisma.test.findMany({
      where: { projectId: req.params.projectId as string },
      include: {
        script: true,
        results: true,
        _count: { select: { testAgents: true } }
      },
      orderBy: { createdAt: 'desc' }
    });
    
    res.json(tests);
  } catch (error) {
    console.error('Error fetching tests:', error);
    res.status(500).json({ error: 'Failed to fetch tests' });
  }
});

// Get tests for a specific script
router.get('/script/:scriptId', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const prisma: PrismaClient = req.app.get('prisma');
    
    // Verify user has access to this script
    const script = await prisma.script.findFirst({
      where: { 
        id: req.params.scriptId as string,
        project: { userId: req.user!.id }
      },
      include: { project: true }
    });
    
    if (!script) {
      res.status(404).json({ error: 'Script not found' });
      return;
    }
    
    const tests = await prisma.test.findMany({
      where: { scriptId: req.params.scriptId as string },
      include: {
        script: true,
        results: true,
        testAgents: {
          include: { agent: true }
        },
        _count: { select: { testAgents: true } }
      },
      orderBy: { createdAt: 'desc' }
    });
    
    res.json(tests);
  } catch (error) {
    console.error('Error fetching script tests:', error);
    res.status(500).json({ error: 'Failed to fetch script tests' });
  }
});

// Get test metrics (for live dashboard)
router.get('/:id/metrics', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const prisma: PrismaClient = req.app.get('prisma');
    
    const test = await prisma.test.findFirst({
      where: { 
        id: req.params.id as string,
        project: { userId: req.user!.id }
      }
    });
    
    if (!test) {
      res.status(404).json({ error: 'Test not found' });
      return;
    }
    
    // Get metrics aggregated by timestamp (every 5 seconds)
    const metrics = await prisma.testMetric.findMany({
      where: { testId: req.params.id as string },
      orderBy: { timestamp: 'asc' },
      select: {
        id: true,
        timestamp: true,
        label: true,
        responseTime: true,
        success: true,
        threads: true
      }
    });
    
    // Aggregate metrics by 5-second intervals for cleaner charts
    const aggregated: any[] = [];
    const intervalMs = 5000; // 5 seconds
    
    if (metrics.length > 0) {
      const startTime = new Date(metrics[0].timestamp).getTime();
      const intervals = new Map();
      
      metrics.forEach(metric => {
        const time = new Date(metric.timestamp).getTime();
        const interval = Math.floor((time - startTime) / intervalMs);
        
        if (!intervals.has(interval)) {
          intervals.set(interval, {
            timestamp: new Date(startTime + interval * intervalMs),
            responseTimes: [],
            successes: 0,
            failures: 0,
            bytes: 0,
            threads: metric.threads,
            count: 0
          });
        }
        
        const data = intervals.get(interval);
        if (data) {
          data.responseTimes.push(metric.responseTime);
          data.successes += metric.success ? 1 : 0;
          data.failures += metric.success ? 0 : 1;
          data.count += 1;
        }
      });
      
      intervals.forEach((data) => {
        const avgResponseTime = data.responseTimes.reduce((a: number, b: number) => a + b, 0) / data.responseTimes.length;
        const throughput = data.count / 5; // requests per second
        const errorRate = (data.failures / data.count) * 100;
        
        aggregated.push({
          timestamp: data.timestamp,
          responseTime: avgResponseTime,
          throughput: throughput,
          errorRate: errorRate,
          activeThreads: data.threads
        });
      });
    }
    
    res.json({
      aggregated,
      raw: metrics  // Include raw metrics for time-based filtering
    });
  } catch (error) {
    console.error('Error fetching metrics:', error);
    res.status(500).json({ error: 'Failed to fetch metrics' });
  }
});

// Get host resource metrics for a test
router.get('/:id/host-metrics', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const prisma: PrismaClient = req.app.get('prisma');
    
    const test = await prisma.test.findFirst({
      where: { 
        id: req.params.id as string,
        project: { userId: req.user!.id }
      }
    });
    
    if (!test) {
      res.status(404).json({ error: 'Test not found' });
      return;
    }
    
    // Get host metrics ordered by timestamp
    const hostMetrics = await prisma.hostMetric.findMany({
      where: { testId: req.params.id as string },
      orderBy: { timestamp: 'asc' },
      include: {
        agent: {
          select: {
            id: true,
            name: true,
            metadata: true
          }
        }
      }
    });
    
    // Parse agent metadata to get hostname
    const metricsWithAgentInfo = hostMetrics.map(metric => {
      const agentMetadata = metric.agent.metadata ? JSON.parse(metric.agent.metadata) : {};
      return {
        id: metric.id,
        timestamp: metric.timestamp,
        cpuPercent: metric.cpuPercent,
        memoryPercent: metric.memoryPercent,
        agentId: metric.agentId,
        agentName: metric.agent.name,
        agentHostname: agentMetadata.hostname || metric.agent.name
      };
    });
    
    res.json(metricsWithAgentInfo);
  } catch (error) {
    console.error('Error fetching host metrics:', error);
    res.status(500).json({ error: 'Failed to fetch host metrics' });
  }
});

// Get transaction statistics from stored metrics
router.get('/:id/transactions', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const prisma: PrismaClient = req.app.get('prisma');
    
    const metrics = await prisma.testMetric.findMany({
      where: { 
        testId: req.params.id as string,
        label: { 
          not: { 
            startsWith: 'agent-'  // Exclude agent-tracking metrics
          }
        }
      },
      orderBy: { timestamp: 'asc' }
    });
    
    // Calculate per-label statistics
    const labelStats = new Map<string, {
      samples: number[];
      pass: number;
      fail: number;
    }>();
    
    metrics.forEach((metric: any) => {
      if (!labelStats.has(metric.label)) {
        labelStats.set(metric.label, {
          samples: [],
          pass: 0,
          fail: 0
        });
      }
      
      const stats = labelStats.get(metric.label)!;
      stats.samples.push(metric.responseTime);
      if (metric.success) {
        stats.pass++;
      } else {
        stats.fail++;
      }
    });
    
    // Build transaction array
    const transactions = Array.from(labelStats.entries()).map(([label, stats]) => {
      const sorted = stats.samples.sort((a, b) => a - b);
      const count = sorted.length;
      const avg = sorted.reduce((a, b) => a + b, 0) / count;
      const min = sorted[0];
      const max = sorted[count - 1];
      const p90Index = Math.floor(count * 0.9);
      const p90 = sorted[p90Index];
      const errorRate = count > 0 ? (stats.fail / count) * 100 : 0;
      
      return {
        label,
        avg: Math.round(avg * 100) / 100,
        min,
        max,
        p90,
        pass: stats.pass,
        fail: stats.fail,
        errorRate: Math.round(errorRate * 100) / 100
      };
    });
    
    res.json(transactions);
  } catch (error) {
    console.error('Error fetching transactions:', error);
    res.status(500).json({ error: 'Failed to fetch transactions' });
  }
});

// Get test logs (agent execution logs)
router.get('/:id/logs', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const prisma: PrismaClient = req.app.get('prisma');
    const testId = req.params.id as string;
    
    const test = await prisma.test.findFirst({
      where: { 
        id: testId,
        project: { userId: req.user!.id }
      },
      include: {
        testAgents: {
          include: {
            agent: true
          }
        }
      }
    });
    
    if (!test) {
      res.status(404).json({ error: 'Test not found' });
      return;
    }
    
    // Return test execution logs
    const logs = [
      {
        timestamp: test.createdAt,
        level: 'info',
        message: `Test "${test.name}" created`,
        agent: 'system'
      }
    ];
    
    if (test.startedAt) {
      logs.push({
        timestamp: test.startedAt,
        level: 'info',
        message: `Test started with ${test.threads} threads, ${test.duration}s duration`,
        agent: 'system'
      });
      
      test.testAgents.forEach(ta => {
        logs.push({
          timestamp: test.startedAt!,
          level: 'info',
          message: `Assigned to agent: ${ta.agent.name} (${ta.threads} threads)`,
          agent: ta.agent.name
        });
        
        if (ta.status === 'running') {
          logs.push({
            timestamp: new Date(),
            level: 'success',
            message: `Agent ${ta.agent.name} is executing test`,
            agent: ta.agent.name
          });
        } else if (ta.status === 'completed') {
          logs.push({
            timestamp: test.completedAt || new Date(),
            level: 'success',
            message: `Agent ${ta.agent.name} completed execution`,
            agent: ta.agent.name
          });
        }
      });
    }
    
    if (test.completedAt) {
      logs.push({
        timestamp: test.completedAt,
        level: test.status === 'failed' ? 'error' : 'success',
        message: `Test ${test.status}`,
        agent: 'system'
      });
    }
    
    // Sort by timestamp
    logs.sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
    
    res.json(logs);
  } catch (error) {
    console.error('Error fetching logs:', error);
    res.status(500).json({ error: 'Failed to fetch logs' });
  }
});

// Download JTL file for completed test
router.get('/:id/download-jtl', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const prisma: PrismaClient = req.app.get('prisma');
    const minioClient: MinioClient = req.app.get('minio');
    const testId = req.params.id as string;
    
    const test = await prisma.test.findFirst({
      where: { 
        id: testId,
        project: { userId: req.user!.id }
      },
      include: {
        results: true,
        testAgents: {
          include: {
            agent: true
          }
        }
      }
    });
    
    if (!test) {
      res.status(404).json({ error: 'Test not found' });
      return;
    }
    
    if (test.status !== 'completed') {
      res.status(400).json({ error: 'Test is not completed yet' });
      return;
    }
    
    // For multi-agent tests, prefer merged JTL file if available
    let jtlPath = test.mergedJtlPath;
    let isMultiAgent = test.testAgents.length > 1;
    
    // Fallback to single result file if no merged file
    if (!jtlPath && test.results?.resultFilePath) {
      jtlPath = test.results.resultFilePath;
    }
    
    // Fallback to first agent's result file
    if (!jtlPath && test.testAgents.length > 0 && test.testAgents[0].resultFilePath) {
      jtlPath = test.testAgents[0].resultFilePath;
    }
    
    if (!jtlPath) {
      res.status(404).json({ error: 'JTL file not found for this test' });
      return;
    }
    
    try {
      // Parse the result file path (format: bucket/path/to/file.jtl)
      const pathParts = jtlPath.split('/');
      const bucketName = pathParts[0];
      const objectName = pathParts.slice(1).join('/');
      
      const fileType = isMultiAgent && test.mergedJtlPath ? 'merged' : 'single';
      console.log(`[JTL Download] Downloading ${fileType} JTL from MinIO: ${bucketName}/${objectName}`);
      
      // Stream file from MinIO
      const dataStream = await minioClient.getObject(bucketName, objectName);
      
      const filename = isMultiAgent && test.mergedJtlPath 
        ? `test-${test.id}-merged-results.jtl`
        : `test-${test.id}-results.jtl`;
      
      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      
      dataStream.pipe(res);
      console.log(`[JTL Download] ${fileType} JTL file streamed successfully for test ${test.id}`);
    } catch (minioError) {
      console.error('[JTL Download] Error downloading from MinIO:', minioError);
      res.status(404).json({ error: 'JTL file not found in storage' });
    }
    
  } catch (error) {
    console.error('Error downloading JTL file:', error);
    res.status(500).json({ error: 'Failed to download JTL file' });
  }
});

// Delete test(s)
router.delete('/', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const prisma: PrismaClient = req.app.get('prisma');
    const { testIds } = req.body; // Can be single ID or array of IDs
    
    const ids = Array.isArray(testIds) ? testIds : [testIds];
    
    if (!ids.length) {
      res.status(400).json({ error: 'No test IDs provided' });
      return;
    }
    
    console.log(`[Delete Tests] Request to delete ${ids.length} test(s)`);
    
    // Verify all tests belong to user's projects
    const tests = await prisma.test.findMany({
      where: { 
        id: { in: ids },
        project: { userId: req.user!.id }
      },
      include: { project: true }
    });
    
    if (tests.length !== ids.length) {
      console.log(`[Delete Tests] Unauthorized or not found. Found ${tests.length} of ${ids.length}`);
      res.status(404).json({ error: 'One or more tests not found' });
      return;
    }
    
    // Delete all metrics and test agents first (cascade should handle this, but being explicit)
    await prisma.testMetric.deleteMany({
      where: { testId: { in: ids } }
    });
    
    await prisma.testAgent.deleteMany({
      where: { testId: { in: ids } }
    });
    
    // Delete the tests
    await prisma.test.deleteMany({
      where: { id: { in: ids } }
    });
    
    console.log(`[Delete Tests] Successfully deleted ${ids.length} test(s)`);
    res.status(204).send();
  } catch (error) {
    console.error('[Delete Tests] Error:', error);
    res.status(500).json({ error: 'Failed to delete tests' });
  }
});

// Delete single test
router.delete('/:id', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const prisma: PrismaClient = req.app.get('prisma');
    const testId = req.params.id as string;
    
    console.log(`[Delete Test] Request for test ID: ${testId}`);
    
    // Verify test belongs to user's project
    const test = await prisma.test.findFirst({
      where: { 
        id: testId,
        project: { userId: req.user!.id }
      },
      include: { project: true }
    });
    
    if (!test) {
      console.log(`[Delete Test] Test not found or unauthorized: ${testId}`);
      res.status(404).json({ error: 'Test not found' });
      return;
    }
    
    // Delete metrics and test agents first
    await prisma.testMetric.deleteMany({
      where: { testId: testId }
    });
    
    await prisma.testAgent.deleteMany({
      where: { testId: testId }
    });
    
    // Delete the test
    await prisma.test.delete({
      where: { id: testId }
    });
    
    console.log(`[Delete Test] Successfully deleted test: ${testId}`);
    res.status(204).send();
  } catch (error) {
    console.error('[Delete Test] Error:', error);
    res.status(500).json({ error: 'Failed to delete test' });
  }
});

export default router;

