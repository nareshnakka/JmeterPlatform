import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Container,
  Typography,
  Button,
  Card,
  CardContent,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  IconButton,
  Box,
  Alert,
  CircularProgress,
  AppBar,
  Toolbar,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Chip,
  Tooltip,
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import FolderIcon from '@mui/icons-material/Folder';
import DescriptionIcon from '@mui/icons-material/Description';
import PlayArrowIcon from '@mui/icons-material/PlayArrow';
import VisibilityIcon from '@mui/icons-material/Visibility';
import { api } from '../api/client';
import { useNotification } from '../components/Notification';

interface Project {
  id: string;
  name: string;
  description: string | null;
  createdAt: string;
  updatedAt: string;
  _count?: {
    scripts: number;
    tests: number;
  };
}

export default function Projects() {
  const navigate = useNavigate();
  const { showNotification } = useNotification();
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [dialogError, setDialogError] = useState('');
  const [openDialog, setOpenDialog] = useState(false);
  const [editingProject, setEditingProject] = useState<Project | null>(null);
  const [formData, setFormData] = useState({ name: '', description: '' });

  useEffect(() => {
    loadProjects();
  }, []);

  const loadProjects = async () => {
    try {
      setLoading(true);
      const data = await api.getProjects();
      setProjects(data);
      setError('');
    } catch (err: any) {
      setError(err.response?.data?.error || 'Failed to load projects');
    } finally {
      setLoading(false);
    }
  };

  const handleOpenDialog = (project?: Project) => {
    if (project) {
      setEditingProject(project);
      setFormData({ name: project.name, description: project.description || '' });
    } else {
      setEditingProject(null);
      setFormData({ name: '', description: '' });
    }
    setDialogError('');
    setOpenDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
    setEditingProject(null);
    setFormData({ name: '', description: '' });
    setDialogError('');
  };

  const handleSubmit = async () => {
    if (!formData.name.trim()) {
      setDialogError('Project name is required');
      return;
    }

    try {
      setDialogError('');
      if (editingProject) {
        await api.updateProject(editingProject.id, formData);
        showNotification(`✏️ Project "${formData.name}" updated successfully!`, 'success');
      } else {
        await api.createProject(formData);
        showNotification(`✅ Project "${formData.name}" created successfully!`, 'success');
      }
      handleCloseDialog();
      loadProjects();
      setError('');
    } catch (err: any) {
      const errorMessage = err.response?.data?.error || err.message || 'Failed to save project';
      setDialogError(errorMessage);
      showNotification(`❌ ${errorMessage}`, 'error');
      console.error('Project save error:', err);
    }
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm('Are you sure you want to delete this project? This will delete all associated scripts and tests.')) {
      return;
    }
    try {
      await api.deleteProject(id);
      loadProjects();
      showNotification('🗑️ Project deleted successfully!', 'success');
    } catch (err: any) {
      setError(err.response?.data?.error || 'Failed to delete project');
      showNotification('❌ Failed to delete project', 'error');
    }
  };

  if (loading) {
    return (
      <Container maxWidth={false} sx={{ mt: 4, mb: 4, textAlign: 'center' }}>
        <CircularProgress />
      </Container>
    );
  }

  return (
    <Box sx={{ background: 'linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%)', minHeight: '100vh', pb: 4 }}>
      <AppBar position="static" elevation={0} sx={{ background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)' }}>
        <Toolbar sx={{ justifyContent: 'space-between' }}>
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <FolderIcon sx={{ mr: 2, fontSize: 32 }} />
            <Typography variant="h5" component="h1" sx={{ fontWeight: 700 }}>
              📁 Projects
            </Typography>
          </Box>
          <Button
            variant="contained"
            startIcon={<AddIcon />}
            onClick={() => handleOpenDialog()}
            sx={{ 
              bgcolor: 'white', 
              color: '#667eea',
              fontWeight: 600,
              '&:hover': { bgcolor: '#f5f5f5' }
            }}
          >
            New Project
          </Button>
        </Toolbar>
      </AppBar>

      <Container maxWidth={false} sx={{ mt: 4 }}>
        {error && (
          <Alert severity="error" sx={{ mb: 3, borderRadius: 2 }} onClose={() => setError('')}>
            {error}
          </Alert>
        )}

        {projects.length === 0 ? (
          <Card sx={{ borderRadius: 3, boxShadow: 3 }}>
            <CardContent sx={{ textAlign: 'center', py: 10 }}>
              <FolderIcon sx={{ fontSize: 80, color: '#667eea', mb: 3, opacity: 0.6 }} />
              <Typography variant="h4" gutterBottom sx={{ fontWeight: 700 }}>
                No projects yet
              </Typography>
              <Typography color="text.secondary" variant="body1" sx={{ mb: 4 }}>
                Create your first project to start organizing your JMeter tests
              </Typography>
              <Button
                variant="contained"
                size="large"
                startIcon={<AddIcon />}
                onClick={() => handleOpenDialog()}
                sx={{ 
                  background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                  px: 4,
                  py: 1.5,
                  boxShadow: '0 4px 12px rgba(102, 126, 234, 0.4)',
                  '&:hover': { boxShadow: '0 6px 20px rgba(102, 126, 234, 0.6)' }
                }}
              >
                Create Project
              </Button>
            </CardContent>
          </Card>
        ) : (
          <TableContainer component={Paper} sx={{ borderRadius: 3, boxShadow: 3 }}>
            <Table>
              <TableHead>
                <TableRow sx={{ bgcolor: '#f5f7fa' }}>
                  <TableCell sx={{ fontWeight: 700, fontSize: '0.95rem' }}>Project Name</TableCell>
                  <TableCell sx={{ fontWeight: 700, fontSize: '0.95rem' }}>Description</TableCell>
                  <TableCell align="center" sx={{ fontWeight: 700, fontSize: '0.95rem' }}>Scripts</TableCell>
                  <TableCell align="center" sx={{ fontWeight: 700, fontSize: '0.95rem' }}>Tests</TableCell>
                  <TableCell sx={{ fontWeight: 700, fontSize: '0.95rem' }}>Created</TableCell>
                  <TableCell align="right" sx={{ fontWeight: 700, fontSize: '0.95rem' }}>Actions</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {projects.map((project) => (
                  <TableRow 
                    key={project.id}
                    sx={{ 
                      '&:hover': { bgcolor: '#f5f5f5' },
                      transition: 'background-color 0.2s'
                    }}
                  >
                    <TableCell>
                      <Box 
                        sx={{ 
                          display: 'flex', 
                          alignItems: 'center',
                          cursor: 'pointer',
                          '&:hover': { opacity: 0.7 }
                        }}
                        onClick={() => navigate(`/projects/${project.id}`)}
                      >
                        <FolderIcon sx={{ color: '#667eea', mr: 1.5 }} />
                        <Typography variant="body1" sx={{ fontWeight: 600 }}>
                          {project.name}
                        </Typography>
                      </Box>
                    </TableCell>
                    <TableCell>
                      <Typography variant="body2" color="text.secondary">
                        {project.description || 'No description'}
                      </Typography>
                    </TableCell>
                    <TableCell align="center">
                      <Chip
                        icon={<DescriptionIcon />}
                        label={project._count?.scripts || 0}
                        size="small"
                        onClick={() => navigate(`/projects/${project.id}`)}
                        sx={{ 
                          bgcolor: '#e3f2fd', 
                          color: '#1976d2', 
                          fontWeight: 600,
                          cursor: 'pointer',
                          '&:hover': { bgcolor: '#bbdefb' }
                        }}
                      />
                    </TableCell>
                    <TableCell align="center">
                      <Chip
                        icon={<PlayArrowIcon />}
                        label={project._count?.tests || 0}
                        size="small"
                        sx={{ bgcolor: '#e8f5e9', color: '#388e3c', fontWeight: 600 }}
                      />
                    </TableCell>
                    <TableCell>
                      <Typography variant="caption" color="text.secondary">
                        {new Date(project.createdAt).toLocaleDateString()}
                      </Typography>
                    </TableCell>
                    <TableCell align="right">
                      <Tooltip title="View Details">
                        <IconButton
                          size="small"
                          onClick={() => navigate(`/projects/${project.id}`)}
                          sx={{ color: '#667eea', mr: 1 }}
                        >
                          <VisibilityIcon />
                        </IconButton>
                      </Tooltip>
                      <Tooltip title="Edit">
                        <IconButton
                          size="small"
                          onClick={() => handleOpenDialog(project)}
                          sx={{ color: '#2196f3', mr: 1 }}
                        >
                          <EditIcon />
                        </IconButton>
                      </Tooltip>
                      <Tooltip title="Delete">
                        <IconButton
                          size="small"
                          onClick={() => handleDelete(project.id)}
                          sx={{ color: '#f44336' }}
                        >
                          <DeleteIcon />
                        </IconButton>
                      </Tooltip>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        )}
      </Container>

      {/* Create/Edit Project Dialog */}
      <Dialog open={openDialog} onClose={handleCloseDialog} maxWidth="sm" fullWidth>
        <DialogTitle sx={{ background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)', color: 'white', fontWeight: 700 }}>
          {editingProject ? '✏️ Edit Project' : '✨ New Project'}
        </DialogTitle>
        <DialogContent sx={{ mt: 2 }}>
          {dialogError && (
            <Alert severity="error" sx={{ mb: 2 }} onClose={() => setDialogError('')}>
              {dialogError}
            </Alert>
          )}
          <TextField
            autoFocus
            margin="dense"
            label="Project Name"
            fullWidth
            required
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            error={!!dialogError && dialogError.includes('name')}
            sx={{
              '& .MuiOutlinedInput-root': {
                '&:hover fieldset': { borderColor: '#667eea' },
                '&.Mui-focused fieldset': { borderColor: '#667eea' },
              }
            }}
          />
          <TextField
            margin="dense"
            label="Description"
            fullWidth
            multiline
            rows={3}
            value={formData.description}
            onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            sx={{
              '& .MuiOutlinedInput-root': {
                '&:hover fieldset': { borderColor: '#667eea' },
                '&.Mui-focused fieldset': { borderColor: '#667eea' },
              }
            }}
          />
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button onClick={handleCloseDialog} sx={{ color: '#666' }}>Cancel</Button>
          <Button
            onClick={handleSubmit}
            variant="contained"
            disabled={!formData.name.trim()}
            sx={{ 
              background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
              fontWeight: 600
            }}
          >
            {editingProject ? 'Update' : 'Create'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
