import { useEffect, useState } from 'react';
import {
  Container,
  Typography,
  Card,
  CardContent,
  Grid,
  Box,
  Chip,
  Alert,
  CircularProgress,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  AppBar,
  Toolbar,
  LinearProgress,
  IconButton,
  Tooltip,
} from '@mui/material';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import ErrorIcon from '@mui/icons-material/Error';
import ComputerIcon from '@mui/icons-material/Computer';
import MemoryIcon from '@mui/icons-material/Memory';
import StorageIcon from '@mui/icons-material/Storage';
import SpeedIcon from '@mui/icons-material/Speed';
import RestartAltIcon from '@mui/icons-material/RestartAlt';
import { api } from '../api/client';

interface Agent {
  id: string;
  name: string;
  hostname: string;
  ipAddress: string;
  port: number;
  platform: string;
  cores: number;
  memory: number;
  status: string;
  currentLoad: number;
  lastSeen: string;
  createdAt: string;
}

export default function Agents() {
  const [agents, setAgents] = useState<Agent[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [restartingAgents, setRestartingAgents] = useState<Set<string>>(new Set());

  const handleRestartAgent = async (agentId: string) => {
    try {
      setRestartingAgents(prev => new Set(prev).add(agentId));
      await api.restartAgent(agentId);
      setError('');
      // Agent will restart and status will update via polling
      setTimeout(() => {
        setRestartingAgents(prev => {
          const next = new Set(prev);
          next.delete(agentId);
          return next;
        });
      }, 10000); // Clear restarting state after 10 seconds
    } catch (err: any) {
      setError(err.response?.data?.error || 'Failed to restart agent');
      setRestartingAgents(prev => {
        const next = new Set(prev);
        next.delete(agentId);
        return next;
      });
    }
  };

  useEffect(() => {
    loadAgents();
    const interval = setInterval(loadAgents, 30000); // Refresh every 30 seconds
    return () => clearInterval(interval);
  }, []);

  const loadAgents = async () => {
    try {
      const data = await api.getAgents();
      setAgents(data);
      setError('');
    } catch (err: any) {
      setError(err.response?.data?.error || 'Failed to load agents');
    } finally {
      setLoading(false);
    }
  };

  const isOnline = (lastSeen: string) => {
    const lastSeenDate = new Date(lastSeen);
    const now = new Date();
    const diffSeconds = (now.getTime() - lastSeenDate.getTime()) / 1000;
    return diffSeconds < 60; // Online if heartbeat within last 60 seconds
  };

  const getStatusColor = (agent: Agent) => {
    if (!isOnline(agent.lastSeen)) return 'error';
    if (agent.status === 'busy') return 'warning';
    if (agent.currentLoad > 80) return 'warning';
    return 'success';
  };

  const getStatusText = (agent: Agent) => {
    if (!isOnline(agent.lastSeen)) return 'Offline';
    if (agent.status === 'busy') return 'Running Test';
    if (agent.currentLoad > 80) return 'High Load';
    return 'Online';
  };

  const calculateStats = () => {
    const online = agents.filter(a => isOnline(a.lastSeen)).length;
    const totalCores = agents.reduce((sum, a) => sum + a.cores, 0);
    const totalMemory = agents.reduce((sum, a) => sum + a.memory, 0);
    const avgLoad = agents.length > 0 
      ? agents.reduce((sum, a) => sum + a.currentLoad, 0) / agents.length 
      : 0;

    return { online, totalCores, totalMemory, avgLoad };
  };

  const stats = calculateStats();

  if (loading) {
    return (
      <Container maxWidth={false} sx={{ mt: 4, mb: 4, textAlign: 'center' }}>
        <CircularProgress />
      </Container>
    );
  }

  return (
    <Box sx={{ background: 'linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%)', minHeight: '100vh', pb: 4 }}>
      <AppBar position="static" elevation={0} sx={{ background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)' }}>
        <Toolbar>
          <ComputerIcon sx={{ mr: 2, fontSize: 32 }} />
          <Typography variant="h5" component="h1" sx={{ fontWeight: 700 }}>
            ⚡ Load Generator Agents
          </Typography>
        </Toolbar>
      </AppBar>

      <Container maxWidth={false} sx={{ mt: 4 }}>
        {error && (
          <Alert severity="error" sx={{ mb: 3, borderRadius: 2 }} onClose={() => setError('')}>
            {error}
          </Alert>
        )}

        {/* Stats Cards */}
        <Grid container spacing={3} sx={{ mb: 4 }}>
          <Grid item xs={12} sm={6} md={3}>
            <Card sx={{ 
              borderRadius: 3,
              borderLeft: '4px solid #667eea',
              transition: 'all 0.3s',
              '&:hover': { transform: 'translateY(-4px)', boxShadow: 6 },
              height: '100%'
            }}>
              <CardContent>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                  <ComputerIcon sx={{ fontSize: 32, color: '#667eea', mr: 1 }} />
                  <Typography color="text.secondary" variant="body2">
                    Total Agents
                  </Typography>
                </Box>
                <Typography variant="h3" sx={{ fontWeight: 700, color: '#667eea' }}>
                  {agents.length}
                </Typography>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <Card sx={{ 
              borderRadius: 3,
              borderLeft: '4px solid #4caf50',
              transition: 'all 0.3s',
              '&:hover': { transform: 'translateY(-4px)', boxShadow: 6 },
              height: '100%'
            }}>
              <CardContent>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                  <CheckCircleIcon sx={{ fontSize: 32, color: '#4caf50', mr: 1 }} />
                  <Typography color="text.secondary" variant="body2">
                    Online
                  </Typography>
                </Box>
                <Typography variant="h3" sx={{ fontWeight: 700, color: '#4caf50' }}>
                  {stats.online}
                </Typography>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <Card sx={{ 
              borderRadius: 3,
              borderLeft: '4px solid #ff9800',
              transition: 'all 0.3s',
              '&:hover': { transform: 'translateY(-4px)', boxShadow: 6 },
              height: '100%'
            }}>
              <CardContent>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                  <MemoryIcon sx={{ fontSize: 32, color: '#ff9800', mr: 1 }} />
                  <Typography color="text.secondary" variant="body2">
                    Total CPU Cores
                  </Typography>
                </Box>
                <Typography variant="h3" sx={{ fontWeight: 700, color: '#ff9800' }}>
                  {stats.totalCores}
                </Typography>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <Card sx={{ 
              borderRadius: 3,
              borderLeft: '4px solid #2196f3',
              transition: 'all 0.3s',
              '&:hover': { transform: 'translateY(-4px)', boxShadow: 6 },
              height: '100%'
            }}>
              <CardContent>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                  <StorageIcon sx={{ fontSize: 32, color: '#2196f3', mr: 1 }} />
                  <Typography color="text.secondary" variant="body2">
                    Total Memory
                  </Typography>
                </Box>
                <Typography variant="h3" sx={{ fontWeight: 700, color: '#2196f3' }}>
                  {(stats.totalMemory / 1024).toFixed(1)}
                </Typography>
                <Typography variant="caption" color="text.secondary">GB</Typography>
              </CardContent>
            </Card>
          </Grid>
        </Grid>

        {/* Agents Table */}
        {agents.length === 0 ? (
          <Card sx={{ borderRadius: 3, boxShadow: 3 }}>
            <CardContent sx={{ textAlign: 'center', py: 8 }}>
              <ComputerIcon sx={{ fontSize: 80, color: '#667eea', mb: 2, opacity: 0.6 }} />
              <Typography variant="h5" gutterBottom sx={{ fontWeight: 600 }}>
                No agents registered
              </Typography>
              <Typography color="text.secondary" variant="body1">
                Start an agent using the installer scripts to begin load testing
              </Typography>
            </CardContent>
          </Card>
        ) : (
          <TableContainer component={Paper} sx={{ borderRadius: 3, boxShadow: 3 }}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Status</TableCell>
                <TableCell>Agent Name</TableCell>
                <TableCell>Hostname</TableCell>
                <TableCell>IP Address</TableCell>
                <TableCell>Platform</TableCell>
                <TableCell align="right">CPU Cores</TableCell>
                <TableCell align="right">Memory (GB)</TableCell>
                <TableCell align="right">Load (%)</TableCell>
                <TableCell>Last Seen</TableCell>
                <TableCell align="center">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {agents.map((agent) => (
                <TableRow key={agent.id} hover>
                  <TableCell>
                    <Chip
                      icon={isOnline(agent.lastSeen) ? <CheckCircleIcon /> : <ErrorIcon />}
                      label={getStatusText(agent)}
                      color={getStatusColor(agent)}
                      size="small"
                    />
                  </TableCell>
                  <TableCell>
                    <Typography variant="body2" fontWeight="bold">
                      {agent.name}
                    </Typography>
                  </TableCell>
                  <TableCell>
                    <Box>
                      <Typography variant="body2" fontWeight="bold">
                        {agent.hostname}
                      </Typography>
                      <Typography variant="caption" color="text.secondary">
                        Port {agent.port}
                      </Typography>
                    </Box>
                  </TableCell>
                  <TableCell>{agent.ipAddress}</TableCell>
                  <TableCell>
                    <Chip label={agent.platform} size="small" variant="outlined" />
                  </TableCell>
                  <TableCell align="right">{agent.cores}</TableCell>
                  <TableCell align="right">{(agent.memory / 1024).toFixed(1)}</TableCell>
                  <TableCell align="right">
                    <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end' }}>
                      <Typography variant="body2">{agent.currentLoad}%</Typography>
                      <Box
                        sx={{
                          ml: 1,
                          width: 60,
                          height: 8,
                          bgcolor: 'grey.300',
                          borderRadius: 1,
                          overflow: 'hidden',
                        }}
                      >
                        <Box
                          sx={{
                            width: `${agent.currentLoad}%`,
                            height: '100%',
                            bgcolor: agent.currentLoad > 80 ? 'error.main' : 'success.main',
                            transition: 'width 0.3s ease',
                          }}
                        />
                      </Box>
                    </Box>
                  </TableCell>
                  <TableCell>
                    <Typography variant="body2">
                      {new Date(agent.lastSeen).toLocaleString()}
                    </Typography>
                  </TableCell>
                  <TableCell align="center">
                    <Tooltip title="Restart Agent">
                      <IconButton
                        size="small"
                        color="primary"
                        onClick={() => handleRestartAgent(agent.id)}
                        disabled={restartingAgents.has(agent.id)}
                      >
                        {restartingAgents.has(agent.id) ? (
                          <CircularProgress size={20} />
                        ) : (
                          <RestartAltIcon />
                        )}
                      </IconButton>
                    </Tooltip>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      )}

        <Box sx={{ mt: 3, textAlign: 'center', bgcolor: 'white', py: 2, borderRadius: 2 }}>
          <Typography variant="body2" color="text.secondary" sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <SpeedIcon sx={{ mr: 1, fontSize: 18 }} />
            Auto-refreshing every 30 seconds
          </Typography>
        </Box>
      </Container>
    </Box>
  );
}
