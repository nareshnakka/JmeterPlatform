# Complete Auto-Installer - Quick Reference

## What These Installers Do

These are **single-file complete installers** that automatically set up the entire JMeter Platform on a fresh system.

## Files Created

1. **COMPLETE-INSTALLER-WINDOWS.bat** - Windows complete installer
2. **COMPLETE-INSTALLER-LINUX.sh** - Linux complete installer

## What Gets Installed Automatically

✅ **Dependencies:**
- Node.js 18 LTS
- PostgreSQL 15
- Redis 7
- Python 3.11
- Java JDK 17
- Apache JMeter 5.6

✅ **Platform Components:**
- Backend API
- Frontend Web UI
- JMeter Agent
- Database schema
- All npm/pip packages

✅ **Services:**
- Windows: Startup scripts
- Linux: Systemd services (auto-start on boot)

## How to Use

### Windows Installation

1. **Copy file to target server:**
   ```
   COMPLETE-INSTALLER-WINDOWS.bat
   ```

2. **Copy your source code folders alongside the installer:**
   ```
   backend/
   frontend/
   agent/
   COMPLETE-INSTALLER-WINDOWS.bat
   ```

3. **Run as Administrator:**
   - Right-click `COMPLETE-INSTALLER-WINDOWS.bat`
   - Select "Run as administrator"
   - Follow prompts

4. **Done!** Platform is installed and ready at:
   - Frontend: http://localhost:5173
   - Backend: http://localhost:3000

### Linux Installation

1. **Copy file to target server:**
   ```bash
   scp COMPLETE-INSTALLER-LINUX.sh user@server:/tmp/
   ```

2. **Copy your source code folders:**
   ```bash
   scp -r backend frontend agent user@server:/tmp/
   ```

3. **Run on server:**
   ```bash
   cd /tmp
   chmod +x COMPLETE-INSTALLER-LINUX.sh
   sudo bash COMPLETE-INSTALLER-LINUX.sh
   ```

4. **Done!** Platform is installed and running as services

## Installation Time

- **Express installation:** 15-30 minutes
- Depends on internet speed for downloading dependencies

## System Requirements

### Minimum
- **Windows:** Windows Server 2016+ or Windows 10+
- **Linux:** Ubuntu 20.04+, CentOS 8+, or equivalent
- **RAM:** 4 GB
- **Disk:** 10 GB free space
- **Internet:** Required for downloads

### Recommended
- **RAM:** 8+ GB
- **Disk:** 20+ GB
- **CPU:** 4+ cores

## What to Copy to New Server

### Option 1: Copy Installer + Source Code (Recommended)
```
COMPLETE-INSTALLER-WINDOWS.bat  (or .sh for Linux)
backend/                        (your source code)
frontend/                       (your source code)
agent/                          (your source code)
```

### Option 2: Create Package First
Run `create-package.bat` on your current system, then copy:
```
jmeter-platform-installer.zip   (contains installer + source)
```

## Post-Installation

### Windows
```bash
# Start platform
C:\JMeterPlatform\start-platform.bat

# Access
http://localhost:5173
```

### Linux
```bash
# Check services
systemctl status jmeter-backend
systemctl status jmeter-frontend
systemctl status jmeter-agent

# View logs
journalctl -u jmeter-backend -f

# Access
http://server-ip:5173
```

## Default Credentials

- **Email:** admin@example.com
- **Password:** Admin@123

## Installed Locations

### Windows
- Installation: `C:\JMeterPlatform\`
- Backend: `C:\JMeterPlatform\backend\`
- Frontend: `C:\JMeterPlatform\frontend\`
- Agent: `C:\JMeterPlatform\agent\`
- JMeter: `C:\JMeterPlatform\jmeter\`

### Linux
- Installation: `/opt/jmeter-platform/`
- Backend: `/opt/jmeter-platform/backend/`
- Frontend: `/opt/jmeter-platform/frontend/`
- Agent: `/opt/jmeter-platform/agent/`
- JMeter: `/opt/jmeter-platform/jmeter/`

## Firewall Ports

If installing on a server, open these ports:
- **3000** - Backend API
- **5173** - Frontend Web UI
- **5432** - PostgreSQL (internal)
- **6379** - Redis (internal)

## Troubleshooting

### Installation Fails

**Check requirements:**
- Administrator/root access
- Internet connection
- Sufficient disk space

**View logs during installation:**
- Installation creates detailed logs in temp directory

### Services Won't Start

**Windows:**
```bash
# Check what's running
tasklist | findstr node
tasklist | findstr python
```

**Linux:**
```bash
# Check service status
systemctl status jmeter-backend -l
journalctl -u jmeter-backend -n 50
```

## What Makes This Different

✅ **Single file** - Just copy one installer + source code
✅ **Zero configuration** - Fully automated
✅ **All dependencies** - Installs everything needed
✅ **Production ready** - Services auto-start
✅ **Fresh system compatible** - Works on new servers

## Summary

**To install on a new server:**

1. Copy these files:
   - `COMPLETE-INSTALLER-WINDOWS.bat` (or LINUX.sh)
   - `backend/` folder
   - `frontend/` folder  
   - `agent/` folder

2. Run installer as admin/root

3. Wait 15-30 minutes

4. Access http://localhost:5173

**That's it! Complete automated installation.**
