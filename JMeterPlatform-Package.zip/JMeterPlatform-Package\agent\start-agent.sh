#!/bin/bash
# Linux/Mac startup script for JMeter Agent

echo "========================================"
echo "JMeter Load Generator Agent - Linux/Mac"
echo "========================================"
echo ""

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "ERROR: Python 3 is not installed"
    echo "Please install Python 3.9 or higher"
    exit 1
fi

# Check if virtual environment exists
if [ ! -d "venv" ]; then
    echo "Creating virtual environment..."
    python3 -m venv venv
fi

# Activate virtual environment
echo "Activating virtual environment..."
source venv/bin/activate

# Install dependencies
if [ ! -d "venv/lib/python3.9/site-packages/requests" ] && [ ! -d "venv/lib/python3.10/site-packages/requests" ] && [ ! -d "venv/lib/python3.11/site-packages/requests" ]; then
    echo "Installing dependencies..."
    pip install -r requirements.txt
fi

# Check if .env file exists
if [ ! -f ".env" ]; then
    echo "WARNING: .env file not found"
    echo "Creating .env from .env.example..."
    cp .env.example .env
    echo ""
    echo "Please edit .env file with your configuration before running the agent"
    exit 1
fi

# Start the agent in a restart loop
echo ""
echo "Starting JMeter Agent..."
echo "Press Ctrl+C to stop the agent"
echo ""

while true; do
    python3 agent.py
    EXIT_CODE=$?
    
    if [ $EXIT_CODE -eq 0 ]; then
        echo ""
        echo "Agent exited normally - restarting in 2 seconds..."
        sleep 2
    else
        echo ""
        echo "Agent exited with error code $EXIT_CODE"
        echo "Stopping agent..."
        exit $EXIT_CODE
    fi
done
