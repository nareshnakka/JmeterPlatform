-- AlterTable
ALTER TABLE "scripts" ADD COLUMN "scenarioName" TEXT;
