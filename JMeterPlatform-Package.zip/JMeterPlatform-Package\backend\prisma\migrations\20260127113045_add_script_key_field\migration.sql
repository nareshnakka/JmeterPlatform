-- AlterTable
ALTER TABLE "scripts" ADD COLUMN "scriptKey" TEXT;

-- CreateIndex
CREATE INDEX "scripts_projectId_scriptKey_idx" ON "scripts"("projectId", "scriptKey");
