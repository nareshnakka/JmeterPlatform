const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient();
const testId = 'f92ba758-0386-4583-8da9-f44b72d81875'; // The test ID from earlier

async function checkTest() {
  try {
    const test = await prisma.test.findUnique({
      where: { id: testId },
      include: {
        results: true,
        metrics: {
          take: 10,
          orderBy: { timestamp: 'desc' }
        }
      }
    });
    
    if (!test) {
      console.log('Test not found!');
      return;
    }
    
    console.log(`Test: ${test.name}`);
    console.log(`Status: ${test.status}`);
    console.log(`\nResults:`);
    console.log(JSON.stringify(test.results, null, 2));
    console.log(`\nMetrics count: ${test.metrics.length}`);
    
    await prisma.$disconnect();
  } catch (error) {
    console.error('Error:', error);
    await prisma.$disconnect();
  }
}

checkTest();
