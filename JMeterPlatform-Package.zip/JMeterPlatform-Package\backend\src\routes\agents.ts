import { Router, Request, Response } from 'express';
import { PrismaClient } from '@prisma/client';

const router = Router();

// Register agent (public endpoint)
router.post('/register', async (req: Request, res: Response): Promise<void> => {
  try {
    const prisma: PrismaClient = req.app.get('prisma');
    const { name, hostname, ipAddress, location, maxThreads, platform, cpuCount, totalMemoryMb, mode } = req.body;
    
    console.log('[Agent Register] Received:', { name, hostname, ipAddress, platform, cpuCount, totalMemoryMb });
    
    // Store hardware details in metadata as JSON
    const metadata = JSON.stringify({
      hostname: hostname || 'unknown',
      ipAddress: ipAddress || 'unknown',
      platform: platform || 'unknown',
      cores: cpuCount || 0,
      memory: totalMemoryMb || 0,
      port: 5000, // default agent port
      // Distinguish between load-generating and monitor-only agents
      mode: mode || 'load',
    });
    
    // Check if agent already exists
    let agent = await prisma.agent.findUnique({ where: { name } });
    
    if (agent) {
      // Update existing agent
      agent = await prisma.agent.update({
        where: { name },
        data: {
          status: 'online',
          maxThreads: maxThreads || agent.maxThreads,
          location: location || agent.location,
          metadata,
          lastSeen: new Date()
        }
      });
    } else {
      // Create new agent
      agent = await prisma.agent.create({
        data: {
          name,
          location: location || 'unknown',
          maxThreads: maxThreads || 1000,
          status: 'online',
          metadata,
          lastSeen: new Date()
        }
      });
    }
    
    // Parse metadata for response
    const agentData = agent.metadata ? JSON.parse(agent.metadata) : {};
    res.json({ 
      ...agent,
      hostname: agentData.hostname,
      ipAddress: agentData.ipAddress,
      platform: agentData.platform,
      cores: agentData.cores,
      memory: agentData.memory,
      port: agentData.port,
      mode: agentData.mode || 'load',
    });
  } catch (error) {
    console.error('Error registering agent:', error);
    res.status(500).json({ error: 'Failed to register agent' });
  }
});

// Heartbeat (public endpoint) - accepts both POST and PUT
router.put('/:id/heartbeat', async (req: Request, res: Response): Promise<void> => {
  try {
    const prisma: PrismaClient = req.app.get('prisma');
    const { status, cpuPercent, memoryPercent, currentTest, currentLoad } = req.body;
    
    console.log(`[Heartbeat] Agent ${req.params.id} - Status: ${status || 'online'}, Test: ${currentTest || 'None'}, CPU: ${cpuPercent}%, Memory: ${memoryPercent}%`);
    
    const agent = await prisma.agent.update({
      where: { id: req.params.id as string },
      data: {
        status: status || 'online',
        currentLoad: currentLoad || 0,
        lastSeen: new Date()
      }
    });
    
    // Save host metrics if test is running
    if (currentTest && (cpuPercent !== undefined || memoryPercent !== undefined)) {
      await prisma.hostMetric.create({
        data: {
          testId: currentTest,
          agentId: req.params.id as string,
          cpuPercent: cpuPercent || 0,
          memoryPercent: memoryPercent || 0,
          timestamp: new Date()
        }
      });
    }
    
    res.json(agent);
  } catch (error) {
    console.error('Error updating heartbeat:', error);
    res.status(500).json({ error: 'Failed to update heartbeat' });
  }
});

// Legacy POST endpoint for backward compatibility
router.post('/:id/heartbeat', async (req: Request, res: Response): Promise<void> => {
  try {
    const prisma: PrismaClient = req.app.get('prisma');
    const { status, cpuPercent, memoryPercent, currentTest, currentLoad } = req.body;
    
    const agent = await prisma.agent.update({
      where: { id: req.params.id as string },
      data: {
        status: status || 'online',
        currentLoad: currentLoad || 0,
        lastSeen: new Date()
      }
    });
    
    // Save host metrics if test is running
    if (currentTest && (cpuPercent !== undefined || memoryPercent !== undefined)) {
      await prisma.hostMetric.create({
        data: {
          testId: currentTest,
          agentId: req.params.id as string,
          cpuPercent: cpuPercent || 0,
          memoryPercent: memoryPercent || 0,
          timestamp: new Date()
        }
      });
    }
    
    res.json(agent);
  } catch (error) {
    console.error('Error updating heartbeat:', error);
    res.status(500).json({ error: 'Failed to update heartbeat' });
  }
});

// Get all agents
router.get('/', async (req: Request, res: Response): Promise<void> => {
  try {
    const prisma: PrismaClient = req.app.get('prisma');
    
    const agents = await prisma.agent.findMany({
      orderBy: { name: 'asc' }
    });
    
    // Mark agents as offline if no heartbeat in last 60 seconds
    const now = new Date();
    const offlineAgents = agents.filter(a => {
      const diff = now.getTime() - a.lastSeen.getTime();
      return diff > 60000 && a.status !== 'offline';
    });
    
    // Update offline agents
    for (const agent of offlineAgents) {
      await prisma.agent.update({
        where: { id: agent.id },
        data: { status: 'offline' }
      });
    }
    
    // Fetch updated list
    const updatedAgents = await prisma.agent.findMany({
      orderBy: { name: 'asc' }
    });
    
    // Parse metadata and flatten hardware details for frontend
    const agentsWithDetails = updatedAgents.map(agent => {
      const metadata = agent.metadata ? JSON.parse(agent.metadata) : {};
      return {
        ...agent,
        hostname: metadata.hostname || agent.name,
        ipAddress: metadata.ipAddress || 'unknown',
        platform: metadata.platform || 'unknown',
        cores: metadata.cores || 0,
        memory: metadata.memory || 0,
        port: metadata.port || 5000,
        mode: metadata.mode || 'load',
      };
    });
    
    res.json(agentsWithDetails);
  } catch (error) {
    console.error('Error fetching agents:', error);
    res.status(500).json({ error: 'Failed to fetch agents' });
  }
});

// Get agent details
router.get('/:id', async (req: Request, res: Response): Promise<void> => {
  try {
    const prisma: PrismaClient = req.app.get('prisma');
    
    const agent = await prisma.agent.findUnique({
      where: { id: req.params.id as string },
      include: {
        testAgents: {
          include: {
            test: {
              select: {
                id: true,
                name: true,
                status: true,
                createdAt: true
              }
            }
          },
          orderBy: { test: { createdAt: 'desc' } },
          take: 10
        }
      }
    });
    
    if (!agent) {
      res.status(404).json({ error: 'Agent not found' });

      return;
    }
    
    res.json(agent);
  } catch (error) {
    console.error('Error fetching agent:', error);
    res.status(500).json({ error: 'Failed to fetch agent' });
  }
});

// Delete agent
router.delete('/:id', async (req: Request, res: Response): Promise<void> => {
  try {
    const prisma: PrismaClient = req.app.get('prisma');
    
    await prisma.agent.delete({
      where: { id: req.params.id as string }
    });
    
    res.status(204).send();
  } catch (error) {
    console.error('Error deleting agent:', error);
    res.status(500).json({ error: 'Failed to delete agent' });
  }
});

// Get pending tests for agent (polled by agent)
router.get('/:id/pending-tests', async (req: Request, res: Response): Promise<void> => {
  try {
    const prisma: PrismaClient = req.app.get('prisma');
    const agentId = req.params.id as string;
    
    // Find tests assigned to this agent that are in 'running' status
    const testAgents = await prisma.testAgent.findMany({
      where: {
        agentId: agentId,
        status: 'pending',
        test: {
          status: 'running'
        }
      },
      include: {
        test: {
          include: {
            script: true,
            project: true
          }
        }
      },
      orderBy: { test: { startedAt: 'asc' } },
      take: 1
    });
    
    if (testAgents.length === 0) {
      res.json([]);
      return;
    }
    
    const testAgent = testAgents[0];
    
    // Update testAgent status to 'running'
    await prisma.testAgent.update({
      where: { id: testAgent.id },
      data: { status: 'running' }
    });
    
    // Return test details
    res.json([{
      id: testAgent.test.id,
      name: testAgent.test.name,
      threads: testAgent.threads,
      duration: testAgent.test.duration,
      rampUp: testAgent.test.rampUp,
      scriptId: testAgent.test.scriptId,
      scriptPath: testAgent.test.script.filePath
    }]);
    
  } catch (error) {
    console.error('Error fetching pending tests:', error);
    res.status(500).json({ error: 'Failed to fetch pending tests' });
  }
});

// Restart agent command
router.post('/:id/restart', async (req: Request, res: Response): Promise<void> => {
  try {
    const prisma: PrismaClient = req.app.get('prisma');
    const agentId = req.params.id as string;
    
    const agent = await prisma.agent.findUnique({
      where: { id: agentId }
    });
    
    if (!agent) {
      res.status(404).json({ error: 'Agent not found' });
      return;
    }
    
    // Update agent metadata to include restart command
    let metadata: any = {};
    try {
      metadata = agent.metadata ? JSON.parse(agent.metadata) : {};
    } catch (e) {
      metadata = {};
    }
    
    metadata.restartRequested = true;
    metadata.restartRequestedAt = new Date().toISOString();
    
    await prisma.agent.update({
      where: { id: agentId },
      data: { metadata: JSON.stringify(metadata) }
    });
    
    res.json({ message: 'Restart command sent to agent' });
    
  } catch (error) {
    console.error('Error sending restart command:', error);
    res.status(500).json({ error: 'Failed to send restart command' });
  }
});

// Check for restart command (agent polls this)
router.get('/:id/restart-status', async (req: Request, res: Response): Promise<void> => {
  try {
    const prisma: PrismaClient = req.app.get('prisma');
    const agentId = req.params.id as string;
    
    const agent = await prisma.agent.findUnique({
      where: { id: agentId }
    });
    
    if (!agent) {
      res.status(404).json({ error: 'Agent not found' });
      return;
    }
    
    let metadata: any = {};
    try {
      metadata = agent.metadata ? JSON.parse(agent.metadata) : {};
    } catch (e) {
      metadata = {};
    }
    
    const restartRequested = metadata.restartRequested === true;
    
    // Clear restart flag after agent reads it
    if (restartRequested) {
      metadata.restartRequested = false;
      await prisma.agent.update({
        where: { id: agentId },
        data: { metadata: JSON.stringify(metadata) }
      });
    }
    
    res.json({ restartRequested });
    
  } catch (error) {
    console.error('Error checking restart status:', error);
    res.status(500).json({ error: 'Failed to check restart status' });
  }
});

export default router;

