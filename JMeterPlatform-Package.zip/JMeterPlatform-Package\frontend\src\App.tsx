import { useEffect } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { Box } from '@mui/material';
import { useAuthStore } from './store/auth';
import { api } from './api/client';
import { wsClient } from './api/websocket';
import { NotificationProvider } from './components/Notification';

// Components
import Navigation from './components/Navigation';

// Pages
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Projects from './pages/Projects';
import ProjectDetail from './pages/ProjectDetail';
import ScriptTests from './pages/ScriptTests';
import Agents from './pages/Agents';
import TestDetail from './pages/TestDetail';
import Comparisons from './pages/Comparisons';

function App() {
  const { token, setUser } = useAuthStore();
  
  useEffect(() => {
    if (token) {
      api.getMe().then(setUser).catch(() => {});
      
      // Connect WebSocket
      wsClient.connect(token);
      
      return () => {
        wsClient.disconnect();
      };
    }
  }, [token, setUser]);
  
  if (!token) {
    return (
      <NotificationProvider>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="*" element={<Navigate to="/login" replace />} />
        </Routes>
      </NotificationProvider>
    );
  }
  
  return (
    <NotificationProvider>
      <Box>
        <Navigation />
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/projects" element={<Projects />} />
          <Route path="/projects/:id" element={<ProjectDetail />} />
          <Route path="/scripts/:id/tests" element={<ScriptTests />} />
          <Route path="/agents" element={<Agents />} />
          <Route path="/tests/:id" element={<TestDetail />} />
          <Route path="/comparisons" element={<Comparisons />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </Box>
    </NotificationProvider>
  );
}

export default App;
