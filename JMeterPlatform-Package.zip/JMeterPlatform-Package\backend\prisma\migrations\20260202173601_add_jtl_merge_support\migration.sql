-- AlterTable
ALTER TABLE "tests" ADD COLUMN "mergedJtlPath" TEXT;
