import { Router, Response } from 'express';
import multer from 'multer';
import { PrismaClient } from '@prisma/client';
import { v4 as uuidv4 } from 'uuid';
import { authenticate, AuthRequest } from '../middleware/auth';
import { uploadFile, deleteFile, downloadFile } from '../config/minio';
import archiver from 'archiver';
import { parseStringPromise } from 'xml2js';

const router = Router();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 100 * 1024 * 1024 } });

router.use(authenticate);

interface ThreadGroupConfig {
  name: string;
  threads: number;
  rampUp: number;
  duration: number;
}

interface ScriptThreadGroupConfig {
  overrideEnabled: boolean;
  groups: ThreadGroupConfig[];
}

// Upload JMX script
router.post(
  '/',
  upload.single('file'),
  async (req: AuthRequest, res: Response): Promise<void> => {
    try {
      if (!req.file) {
        res.status(400).json({ error: 'No file uploaded' });

        return;
      }
      
      const { projectId, name, description, scenarioName } = req.body;
      const prisma: PrismaClient = req.app.get('prisma');
      
      // Generate scriptKey from name (make it URL-friendly and unique)
      const baseName = (name || req.file.originalname).replace(/\.[^/.]+$/, ''); // Remove extension
      let scriptKey = baseName
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-') // Replace non-alphanumeric with hyphens
        .replace(/^-+|-+$/g, ''); // Remove leading/trailing hyphens
      
      // Ensure uniqueness by checking existing keys
      let counter = 1;
      let uniqueScriptKey = scriptKey;
      while (await prisma.script.findFirst({ where: { projectId, scriptKey: uniqueScriptKey } })) {
        uniqueScriptKey = `${scriptKey}-${counter}`;
        counter++;
      }
      
      // Verify project ownership
      const project = await prisma.project.findFirst({
        where: { id: projectId, userId: req.user!.id }
      });
      
      if (!project) {
        res.status(404).json({ error: 'Project not found' });

        return;
      }
      
      // Upload to MinIO (or local storage if MinIO unavailable)
      const filePath = `scripts/${uuidv4()}-${req.file.originalname}`;
      await uploadFile(filePath, req.file.buffer, req.file.mimetype);
      
      // Create script record
      const script = await prisma.script.create({
        data: {
          projectId,
          scriptKey: uniqueScriptKey,
          scenarioName: scenarioName || null,
          name: name || req.file.originalname,
          description,
          filePath
        }
      });
      
      res.status(201).json(script);
    } catch (error) {
      console.error('Error uploading script:', error);
      res.status(500).json({ error: 'Failed to upload script' });
    }
  }
);

// Add dependency
router.post(
  '/:id/dependencies',
  upload.single('file'),
  async (req: AuthRequest, res: Response): Promise<void> => {
    try {
      if (!req.file) {
        res.status(400).json({ error: 'No file uploaded' });

        return;
      }
      
      const { type } = req.body;
      const prisma: PrismaClient = req.app.get('prisma');
      const scriptId = req.params.id as string;
      
      console.log(`[Add Dependency] Request for script ID: ${scriptId}, File: ${req.file.originalname}`);
      
      // Verify script exists and user owns project
      const script = await prisma.script.findFirst({
        where: { id: scriptId },
        include: { 
          project: true,
          dependencies: true
        }
      });
      
      if (!script || script.project.userId !== req.user!.id) {
        res.status(404).json({ error: 'Script not found' });

        return;
      }
      
      // Check if a dependency with the same name already exists
      const existingDependency = script.dependencies.find(
        dep => dep.name === req.file!.originalname
      );
      
      if (existingDependency) {
        console.log(`[Add Dependency] Found existing dependency with same name, replacing: ${existingDependency.name}`);
        
        // Delete old file from MinIO
        try {
          await deleteFile(existingDependency.filePath);
          console.log(`[Add Dependency] Deleted old file: ${existingDependency.filePath}`);
        } catch (minioError) {
          console.warn(`[Add Dependency] Failed to delete old file (continuing): ${existingDependency.filePath}`, minioError);
        }
        
        // Upload new file to MinIO (or local storage)
        const newFilePath = `dependencies/${uuidv4()}-${req.file.originalname}`;
        await uploadFile(newFilePath, req.file.buffer, req.file.mimetype);
        console.log(`[Add Dependency] Uploaded new file: ${newFilePath}`);
        
        // Update existing dependency record
        const dependency = await prisma.dependency.update({
          where: { id: existingDependency.id },
          data: {
            filePath: newFilePath,
            type: type || existingDependency.type,
          }
        });
        
        console.log(`[Add Dependency] Replaced dependency: ${dependency.name}`);
        res.status(200).json(dependency);
        
      } else {
        console.log(`[Add Dependency] Creating new dependency: ${req.file.originalname}`);
        
        // Upload to MinIO (or local storage)
        const filePath = `dependencies/${uuidv4()}-${req.file.originalname}`;
        await uploadFile(filePath, req.file.buffer, req.file.mimetype);
        
        // Create dependency record
        const dependency = await prisma.dependency.create({
          data: {
            scriptId: scriptId,
            name: req.file.originalname,
            type: type || 'other',
            filePath
          }
        });
        
        console.log(`[Add Dependency] Created new dependency: ${dependency.name}`);
        res.status(201).json(dependency);
      }
      
    } catch (error) {
      console.error('[Add Dependency] Error:', error);
      res.status(500).json({ error: 'Failed to add dependency' });
    }
  }
);

// Get scripts for project
router.get('/project/:projectId', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const prisma: PrismaClient = req.app.get('prisma');
    
    // Verify project ownership
    const project = await prisma.project.findFirst({
      where: { id: req.params.projectId as string, userId: req.user!.id }
    });
    
    if (!project) {
      res.status(404).json({ error: 'Project not found' });

      return;
    }
    
    const scripts = await prisma.script.findMany({
      where: { projectId: req.params.projectId as string },
      include: {
        dependencies: true,
        tests: {
          select: {
            id: true,
            name: true,
            status: true,
            createdAt: true,
            startedAt: true,
            completedAt: true,
            threads: true,
            duration: true
          },
          orderBy: { createdAt: 'desc' },
          take: 5 // Get last 5 tests for each script
        },
        _count: { select: { tests: true } }
      },
      orderBy: { createdAt: 'desc' }
    });
    
    res.json(scripts);
  } catch (error) {
    console.error('Error fetching scripts:', error);
    res.status(500).json({ error: 'Failed to fetch scripts' });
  }
});

// Get thread groups for a script (for scenario editing)
router.get('/:id/thread-groups', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const prisma: PrismaClient = req.app.get('prisma');

    const script = await prisma.script.findFirst({
      where: { id: req.params.id as string },
      include: { project: true }
    });

    if (!script || script.project.userId !== req.user!.id) {
      res.status(404).json({ error: 'Script not found' });
      return;
    }

    // Download JMX content
    const buffer = await downloadFile(script.filePath);
    const xml = buffer.toString('utf-8');

    // Parse XML and extract ThreadGroup elements
    const parsed = await parseStringPromise(xml, { explicitArray: false });

    const threadGroups: ThreadGroupConfig[] = [];

    const collectThreadGroups = (node: any) => {
      if (!node || typeof node !== 'object') return;

      const maybeGroups = (node as any).ThreadGroup;
      if (maybeGroups) {
        const groupsArray = Array.isArray(maybeGroups) ? maybeGroups : [maybeGroups];
        for (const tg of groupsArray) {
          const attrs = tg.$ || {};
          const name: string = (attrs.testname || attrs.name || 'Thread Group').toString();

          const toArray = (value: any) => (Array.isArray(value) ? value : value ? [value] : []);
          const props = [
            ...toArray((tg as any).stringProp),
            ...toArray((tg as any).intProp),
            ...toArray((tg as any).longProp),
          ];

          let threads = 10;
          let rampUp = 10;
          let duration = 60;

          for (const prop of props) {
            if (!prop || !prop.$) continue;
            const propName = prop.$.name;
            const rawValue: string = (prop._ ?? '').toString();

            const parseNumeric = (value: string): number | null => {
              const numericMatch = value.match(/-?\d+/);
              if (!numericMatch) return null;
              const parsedInt = parseInt(numericMatch[0], 10);
              return Number.isNaN(parsedInt) ? null : parsedInt;
            };

            if (propName === 'ThreadGroup.num_threads') {
              const v = parseNumeric(rawValue);
              if (v !== null) threads = v;
            } else if (propName === 'ThreadGroup.ramp_time') {
              const v = parseNumeric(rawValue);
              if (v !== null) rampUp = v;
            } else if (propName === 'ThreadGroup.duration') {
              const v = parseNumeric(rawValue);
              if (v !== null) duration = v;
            }
          }

          threadGroups.push({ name, threads, rampUp, duration });
        }
      }

      for (const key of Object.keys(node)) {
        const child = (node as any)[key];
        if (child && typeof child === 'object') {
          if (Array.isArray(child)) {
            child.forEach((c) => collectThreadGroups(c));
          } else {
            collectThreadGroups(child);
          }
        }
      }
    };

    collectThreadGroups(parsed);

    // Merge with any existing saved configuration
    let savedConfig: ScriptThreadGroupConfig | null = null;
    if (script.threadGroupConfig) {
      try {
        const parsedConfig = JSON.parse(script.threadGroupConfig) as ScriptThreadGroupConfig;
        if (parsedConfig && Array.isArray(parsedConfig.groups)) {
          savedConfig = {
            overrideEnabled: Boolean(parsedConfig.overrideEnabled),
            groups: parsedConfig.groups.map((g) => ({
              name: g.name,
              threads: Number.isFinite(g.threads as any) ? Number(g.threads) : 10,
              rampUp: Number.isFinite(g.rampUp as any) ? Number(g.rampUp) : 10,
              duration: Number.isFinite(g.duration as any) ? Number(g.duration) : 60,
            })),
          };
        }
      } catch {
        savedConfig = null;
      }
    }

    const overrideEnabled = savedConfig?.overrideEnabled ?? false;
    const mergedGroups: ThreadGroupConfig[] = threadGroups.map((tg) => {
      const match = savedConfig?.groups.find((g) => g.name === tg.name);
      return match
        ? { name: tg.name, threads: match.threads, rampUp: match.rampUp, duration: match.duration }
        : tg;
    });

    res.json({ overrideEnabled, groups: mergedGroups });
  } catch (error) {
    console.error('Error fetching thread groups:', error);
    res.status(500).json({ error: 'Failed to fetch thread groups for script' });
  }
});

// Update thread group configuration for a script
router.put('/:id/thread-groups', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const prisma: PrismaClient = req.app.get('prisma');
    const { overrideEnabled, groups } = req.body as ScriptThreadGroupConfig;

    const script = await prisma.script.findFirst({
      where: { id: req.params.id as string },
      include: { project: true }
    });

    if (!script || script.project.userId !== req.user!.id) {
      res.status(404).json({ error: 'Script not found' });
      return;
    }

    const sanitizedGroups: ThreadGroupConfig[] = Array.isArray(groups)
      ? groups
          .filter((g) => g && typeof g.name === 'string' && g.name.trim().length > 0)
          .map((g) => ({
            name: g.name.trim(),
            threads: Math.max(1, parseInt(String(g.threads ?? 1), 10) || 1),
            rampUp: Math.max(0, parseInt(String(g.rampUp ?? 0), 10) || 0),
            duration: Math.max(1, parseInt(String(g.duration ?? 1), 10) || 1),
          }))
      : [];

    const configToSave: ScriptThreadGroupConfig = {
      overrideEnabled: Boolean(overrideEnabled),
      groups: sanitizedGroups,
    };

    const updated = await prisma.script.update({
      where: { id: req.params.id as string },
      data: {
        threadGroupConfig: JSON.stringify(configToSave),
        updatedAt: new Date(),
      },
      include: {
        dependencies: true,
        tests: {
          select: {
            id: true,
            name: true,
            status: true,
            createdAt: true,
          },
          orderBy: { createdAt: 'desc' },
          take: 5,
        },
        _count: { select: { tests: true } },
      },
    });

    res.json({
      overrideEnabled: configToSave.overrideEnabled,
      groups: configToSave.groups,
      script: updated,
    });
  } catch (error) {
    console.error('Error updating thread group configuration:', error);
    res.status(500).json({ error: 'Failed to update thread group configuration' });
  }
});

// Replace/Update script file
router.put(
  '/:id/replace',
  upload.single('file'),
  async (req: AuthRequest, res: Response): Promise<void> => {
    try {
      if (!req.file) {
        res.status(400).json({ error: 'No file uploaded' });
        return;
      }
      
      const prisma: PrismaClient = req.app.get('prisma');
      
      console.log(`[Replace Script] Request for script ID: ${req.params.id}`);
      
      // Verify script exists and user owns project
      const script = await prisma.script.findFirst({
        where: { id: req.params.id as string },
        include: { project: true }
      });
      
      if (!script || script.project.userId !== req.user!.id) {
        console.log(`[Replace Script] Script not found or unauthorized: ${req.params.id}`);
        res.status(404).json({ error: 'Script not found' });
        return;
      }
      
      console.log(`[Replace Script] Replacing file for script: ${script.name}`);
      
      // Delete old file from MinIO
      try {
        await deleteFile(script.filePath);
        console.log(`[Replace Script] Deleted old file: ${script.filePath}`);
      } catch (minioError) {
        console.warn(`[Replace Script] Failed to delete old file (continuing): ${script.filePath}`, minioError);
      }
      
      // Upload new file to MinIO (or local storage)
      const newFilePath = `scripts/${uuidv4()}-${req.file.originalname}`;
      await uploadFile(newFilePath, req.file.buffer, req.file.mimetype);
      console.log(`[Replace Script] Uploaded new file: ${newFilePath}`);
      
      // Update script record with new file path and name
      const updatedScript = await prisma.script.update({
        where: { id: req.params.id as string },
        data: {
          filePath: newFilePath,
          name: req.file.originalname,
          updatedAt: new Date()
        },
        include: {
          dependencies: true,
          tests: {
            select: {
              id: true,
              name: true,
              status: true,
              createdAt: true
            },
            orderBy: { createdAt: 'desc' },
            take: 5
          },
          _count: { select: { tests: true } }
        }
      });
      
      console.log(`[Replace Script] Successfully replaced script file: ${req.params.id}`);
      res.json(updatedScript);
      
    } catch (error) {
      console.error('[Replace Script] Error:', error);
      res.status(500).json({ error: 'Failed to replace script' });
    }
  }
);

// Download script with all dependencies as ZIP
router.get('/:id/download-zip', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const prisma: PrismaClient = req.app.get('prisma');
    const minioClient = req.app.get('minio');
    const bucketName = process.env.MINIO_BUCKET || 'jmeter-files';
    
    console.log(`[Download ZIP] Request for script ID: ${req.params.id}`);
    
    // Verify script exists and user owns project
    const script = await prisma.script.findFirst({
      where: { id: req.params.id as string },
      include: { 
        project: true, 
        dependencies: true 
      }
    });
    
    if (!script || script.project.userId !== req.user!.id) {
      console.log(`[Download ZIP] Script not found or unauthorized: ${req.params.id}`);
      res.status(404).json({ error: 'Script not found' });
      return;
    }
    
    console.log(`[Download ZIP] Creating ZIP for script: ${script.name}`);
    
    // Create a safe filename for the ZIP
    const zipFileName = `${script.scenarioName || script.name.replace(/\.[^/.]+$/, '')}-files.zip`;
    
    // Set response headers
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', `attachment; filename="${zipFileName}"`);
    
    // Create ZIP archive
    const archive = archiver('zip', {
      zlib: { level: 9 } // Maximum compression
    });
    
    // Handle errors
    archive.on('error', (err) => {
      console.error('[Download ZIP] Archive error:', err);
      throw err;
    });
    
    // Pipe archive to response
    archive.pipe(res);
    
    // Add JMX file
    try {
      console.log(`[Download ZIP] Adding JMX file: ${script.filePath}`);
      const jmxStream = await minioClient.getObject(bucketName, script.filePath);
      archive.append(jmxStream, { name: script.name });
    } catch (error) {
      console.error(`[Download ZIP] Failed to add JMX file: ${script.filePath}`, error);
      // Continue even if main file fails
    }
    
    // Add all dependencies
    for (const dep of script.dependencies) {
      try {
        console.log(`[Download ZIP] Adding dependency: ${dep.name}`);
        const depStream = await minioClient.getObject(bucketName, dep.filePath);
        
        // Organize by type in subdirectories
        const folderName = dep.type === 'csv' ? 'data' : 
                          dep.type === 'jar' ? 'lib' : 
                          dep.type === 'properties' ? 'config' : 'files';
        
        archive.append(depStream, { name: `${folderName}/${dep.name}` });
      } catch (error) {
        console.error(`[Download ZIP] Failed to add dependency: ${dep.name}`, error);
        // Continue with other files
      }
    }
    
    // Finalize archive
    console.log(`[Download ZIP] Finalizing ZIP with ${script.dependencies.length + 1} file(s)`);
    await archive.finalize();
    
  } catch (error) {
    console.error('[Download ZIP] Error:', error);
    if (!res.headersSent) {
      res.status(500).json({ error: 'Failed to create ZIP file' });
    }
  }
});

// Delete script
router.delete('/:id', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const prisma: PrismaClient = req.app.get('prisma');
    
    console.log(`[Delete Script] Request for script ID: ${req.params.id}`);
    
    const script = await prisma.script.findFirst({
      where: { id: req.params.id as string },
      include: { project: true, dependencies: true, tests: true }
    });
    
    if (!script) {
      console.log(`[Delete Script] Script not found: ${req.params.id}`);
      res.status(404).json({ error: 'Script not found' });
      return;
    }
    
    if (script.project.userId !== req.user!.id) {
      console.log(`[Delete Script] Unauthorized: User ${req.user!.id} does not own script ${req.params.id}`);
      res.status(404).json({ error: 'Script not found' });
      return;
    }
    
    console.log(`[Delete Script] Deleting script: ${script.name}, File: ${script.filePath}`);
    
    // Delete all associated tests and their related data
    if (script.tests.length > 0) {
      console.log(`[Delete Script] Deleting ${script.tests.length} associated test(s) and all related data`);
      
      const testIds = script.tests.map((t: any) => t.id);
      
      // Delete test results (including JTL files from MinIO)
      const testResults = await prisma.testResult.findMany({
        where: { testId: { in: testIds } }
      });
      
      for (const result of testResults) {
        if (result.resultFilePath) {
          try {
            await deleteFile(result.resultFilePath);
            console.log(`[Delete Script] Deleted JTL file: ${result.resultFilePath}`);
          } catch (minioError) {
            console.warn(`[Delete Script] Failed to delete JTL file (continuing): ${result.resultFilePath}`, minioError);
          }
        }
      }
      
      // Delete all test-related data (cascade will handle most, but being explicit)
      await prisma.testResult.deleteMany({
        where: { testId: { in: testIds } }
      });
      
      await prisma.testMetric.deleteMany({
        where: { testId: { in: testIds } }
      });
      
      await prisma.testAgent.deleteMany({
        where: { testId: { in: testIds } }
      });
      
      await prisma.testTag.deleteMany({
        where: { testId: { in: testIds } }
      });
      
      await prisma.testNote.deleteMany({
        where: { testId: { in: testIds } }
      });
      
      // Delete tests (will cascade to any remaining relations)
      await prisma.test.deleteMany({
        where: { id: { in: testIds } }
      });
      
      console.log(`[Delete Script] Deleted ${script.tests.length} test(s) and all their results, metrics, tags, and notes`);
    }
    
    // Delete files from MinIO (with error handling)
    try {
      await deleteFile(script.filePath);
      console.log(`[Delete Script] Deleted main file: ${script.filePath}`);
    } catch (minioError) {
      console.warn(`[Delete Script] Failed to delete file from MinIO (continuing): ${script.filePath}`, minioError);
    }
    
    for (const dep of script.dependencies) {
      try {
        await deleteFile(dep.filePath);
        console.log(`[Delete Script] Deleted dependency: ${dep.filePath}`);
      } catch (minioError) {
        console.warn(`[Delete Script] Failed to delete dependency from MinIO (continuing): ${dep.filePath}`, minioError);
      }
    }
    
    // Delete from database
    await prisma.script.delete({ where: { id: req.params.id as string } });
    console.log(`[Delete Script] Successfully deleted script from database: ${req.params.id}`);
    
    res.status(204).send();
  } catch (error) {
    console.error('[Delete Script] Error:', error);
    res.status(500).json({ error: 'Failed to delete script' });
  }
});

export default router;

