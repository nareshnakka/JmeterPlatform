const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient();

async function checkResults() {
  try {
    const results = await prisma.testResult.findMany({
      take: 5,
      include: {
        test: {
          select: {
            name: true,
            status: true
          }
        }
      }
    });
    
    console.log('Total test results found:', results.length);
    console.log('\nTest Results:');
    results.forEach(r => {
      console.log(`\nTest: ${r.test.name} (${r.test.status})`);
      console.log(`  Total Samples: ${r.totalSamples}`);
      console.log(`  Successful: ${r.successfulSamples}`);
      console.log(`  Failed: ${r.failedSamples}`);
      console.log(`  Error Rate: ${r.errorRate}%`);
      console.log(`  Avg Response Time: ${r.avgResponseTime}ms`);
    });
    
    await prisma.$disconnect();
  } catch (error) {
    console.error('Error:', error);
    await prisma.$disconnect();
  }
}

checkResults();
