# JMeter Platform - Development Guide

## Running Locally for Development

### Prerequisites

- Node.js 18+
- PostgreSQL 15+
- Redis 7+
- MinIO (or use Docker for dependencies)

### Option 1: All in Docker (Recommended)

```bash
./quick-start.sh
# or on Windows:
quick-start.bat
```

### Option 2: Local Development

**1. Start Dependencies (Docker)**

```bash
# Start only databases and services
docker-compose up postgres redis minio -d
```

**2. Backend Development**

```bash
cd backend

# Install dependencies
npm install

# Copy environment file
cp .env.example .env

# Edit .env if needed (default values should work with Docker)

# Generate Prisma client
npm run prisma:generate

# Run migrations
npm run prisma:migrate

# Start development server (with auto-reload)
npm run dev

# Server will start on http://localhost:3000
```

**3. Frontend Development**

```bash
cd frontend

# Install dependencies
npm install

# Copy environment file
cp .env.example .env

# Start development server (with hot reload)
npm run dev

# Frontend will start on http://localhost:8080
```

### Database Management

**Prisma Studio (Database GUI):**
```bash
cd backend
npm run prisma:studio
# Opens at http://localhost:5555
```

**Create Admin User:**
```bash
cd backend
node -e "
const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcrypt');
const prisma = new PrismaClient();

async function createAdmin() {
  const hash = await bcrypt.hash('admin123', 10);
  const user = await prisma.user.create({
    data: {
      email: 'admin@jmeter-platform.local',
      passwordHash: hash,
      role: 'admin'
    }
  });
  console.log('Admin user created:', user.email);
  await prisma.\$disconnect();
}

createAdmin();
"
```

### Code Quality

**Backend Linting:**
```bash
cd backend
npm run lint
```

**Backend Build (check TypeScript):**
```bash
cd backend
npm run build
```

**Frontend Linting:**
```bash
cd frontend
npm run lint
```

**Frontend Build:**
```bash
cd frontend
npm run build
# Production build in dist/
```

## Project Structure

```
Jmeter Solution/
├── backend/
│   ├── src/
│   │   ├── index.ts                 # Main server entry
│   │   ├── config/
│   │   │   └── minio.ts            # MinIO configuration
│   │   ├── middleware/
│   │   │   ├── auth.ts             # JWT authentication
│   │   │   └── errorHandler.ts    # Global error handler
│   │   ├── routes/
│   │   │   ├── auth.ts             # Auth endpoints
│   │   │   ├── projects.ts         # Projects CRUD
│   │   │   ├── scripts.ts          # Scripts upload
│   │   │   ├── agents.ts           # Agent management
│   │   │   ├── tests.ts            # Test execution
│   │   │   ├── export.ts           # Export results
│   │   │   └── comparison.ts       # Test comparison
│   │   └── utils/
│   │       └── logger.ts           # Winston logger
│   ├── prisma/
│   │   └── schema.prisma           # Database schema
│   ├── package.json
│   ├── tsconfig.json
│   ├── Dockerfile
│   └── .env.example
│
├── frontend/
│   ├── src/
│   │   ├── main.tsx                # App entry point
│   │   ├── App.tsx                 # Router & auth wrapper
│   │   ├── api/
│   │   │   └── client.ts           # API client
│   │   ├── store/
│   │   │   └── auth.ts             # Auth state (Zustand)
│   │   └── pages/
│   │       ├── Login.tsx           # Login/Register
│   │       ├── Dashboard.tsx       # Main dashboard
│   │       ├── Projects*.tsx       # Projects pages
│   │       ├── Agents*.tsx         # Agents pages
│   │       ├── TestDetail*.tsx     # Test monitoring
│   │       └── Comparisons*.tsx    # Test comparison
│   ├── package.json
│   ├── vite.config.ts
│   ├── tsconfig.json
│   ├── Dockerfile
│   ├── nginx.conf
│   ├── index.html
│   └── .env.example
│
├── agent/
│   ├── agent.py                    # Load generator agent
│   ├── requirements.txt
│   ├── start-agent.sh
│   └── start-agent.bat
│
├── installers/
│   ├── server-installer-linux.sh   # Server wizard (Linux)
│   ├── server-installer-windows.bat # Server wizard (Windows)
│   ├── agent-installer-linux.sh    # Agent wizard (Linux)
│   └── agent-installer-windows.bat  # Agent wizard (Windows)
│
├── docker-compose.yml              # Full stack deployment
├── quick-start.sh                  # Quick start (Linux)
├── quick-start.bat                 # Quick start (Windows)
│
└── Documentation/
    ├── README.md                   # Main README
    ├── IMPLEMENTATION_STATUS.md    # Implementation status
    ├── SETUP_WIZARD.md            # Installation guide
    ├── ARCHITECTURE.md            # System design
    ├── API_REFERENCE.md           # API documentation
    └── ... (15+ more guides)
```

## Development Workflow

### Making Changes

1. **Create a feature branch**
   ```bash
   git checkout -b feature/my-feature
   ```

2. **Make your changes**
   - Backend: Edit files in `backend/src/`
   - Frontend: Edit files in `frontend/src/`
   - Dev servers auto-reload

3. **Test your changes**
   - Backend: Use Postman or curl
   - Frontend: Check browser
   - Both: Check console for errors

4. **Commit and push**
   ```bash
   git add .
   git commit -m "Add feature X"
   git push origin feature/my-feature
   ```

### Adding a New API Endpoint

1. **Add route in backend**
   ```typescript
   // backend/src/routes/myroute.ts
   import { Router, Response } from 'express';
   import { authenticate, AuthRequest } from '../middleware/auth';
   
   const router = Router();
   router.use(authenticate);
   
   router.get('/', async (req: AuthRequest, res: Response) => {
     // Your logic here
     res.json({ message: 'Hello' });
   });
   
   export default router;
   ```

2. **Register route in index.ts**
   ```typescript
   // backend/src/index.ts
   import myRoute from './routes/myroute';
   app.use('/api/myroute', myRoute);
   ```

3. **Add to API client**
   ```typescript
   // frontend/src/api/client.ts
   async getMyData() {
     const { data } = await this.client.get('/api/myroute');
     return data;
   }
   ```

4. **Use in frontend**
   ```typescript
   // frontend/src/pages/MyPage.tsx
   import { api } from '../api/client';
   
   const data = await api.getMyData();
   ```

### Adding a Database Model

1. **Edit Prisma schema**
   ```prisma
   // backend/prisma/schema.prisma
   model MyModel {
     id        String   @id @default(uuid())
     name      String
     createdAt DateTime @default(now())
   }
   ```

2. **Create migration**
   ```bash
   cd backend
   npm run prisma:migrate
   # Name your migration when prompted
   ```

3. **Use in code**
   ```typescript
   const prisma: PrismaClient = req.app.get('prisma');
   const items = await prisma.myModel.findMany();
   ```

## Testing

### Manual API Testing

**Using curl:**
```bash
# Login
TOKEN=$(curl -s -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@jmeter-platform.local","password":"admin123"}' \
  | jq -r '.token')

# Use token
curl http://localhost:3000/api/projects \
  -H "Authorization: Bearer $TOKEN"
```

**Using Postman:**
1. Import API_REFERENCE.md examples
2. Set environment variable `TOKEN`
3. Test all endpoints

### Frontend Testing

1. Open http://localhost:8080
2. Open Browser DevTools (F12)
3. Check Console for errors
4. Check Network tab for API calls

## Debugging

### Backend Debugging

**View logs:**
```bash
# Development
tail -f backend/logs/combined.log

# Docker
docker logs jmeter-backend -f
```

**Debug with VSCode:**
```json
// .vscode/launch.json
{
  "configurations": [
    {
      "type": "node",
      "request": "launch",
      "name": "Debug Backend",
      "runtimeExecutable": "npm",
      "runtimeArgs": ["run", "dev"],
      "cwd": "${workspaceFolder}/backend"
    }
  ]
}
```

### Frontend Debugging

**React DevTools:**
1. Install React DevTools extension
2. Inspect component tree
3. View props and state

**Redux DevTools (if using Redux):**
1. Install Redux DevTools extension
2. View action history
3. Time-travel debugging

## Environment Variables

### Backend (.env)

```env
# Required
NODE_ENV=development
PORT=3000
DATABASE_URL=postgresql://jmeter:password@localhost:5432/jmeter_platform
JWT_SECRET=your-secret-key-min-32-chars

# Optional
REDIS_URL=redis://localhost:6379
LOG_LEVEL=info
CORS_ORIGIN=http://localhost:8080

# MinIO
MINIO_ENDPOINT=localhost
MINIO_PORT=9000
MINIO_ACCESS_KEY=minioadmin
MINIO_SECRET_KEY=minioadmin
MINIO_USE_SSL=false
MINIO_BUCKET=jmeter-files
```

### Frontend (.env)

```env
VITE_API_URL=http://localhost:3000
VITE_WS_URL=ws://localhost:3000
```

## Deployment

See [IMPLEMENTATION_STATUS.md](IMPLEMENTATION_STATUS.md) for deployment instructions.

## Common Issues

### "Cannot connect to database"
```bash
# Check PostgreSQL is running
docker ps | grep postgres

# Test connection
psql -h localhost -U jmeter -d jmeter_platform

# Restart PostgreSQL
docker-compose restart postgres
```

### "Port already in use"
```bash
# Find process using port 3000
lsof -i :3000

# Kill process
kill -9 <PID>

# Or change port in .env
PORT=3001
```

### "Module not found"
```bash
# Backend
cd backend
rm -rf node_modules package-lock.json
npm install

# Frontend
cd frontend
rm -rf node_modules package-lock.json
npm install
```

## Next Steps

1. Complete the 5 frontend pages (see IMPLEMENTATION_STATUS.md)
2. Add real-time WebSocket updates to frontend
3. Implement charts with Recharts
4. Add tests (Jest for backend, React Testing Library for frontend)
5. Set up CI/CD pipeline
6. Deploy to production

## Resources

- [TypeScript Docs](https://www.typescriptlang.org/docs/)
- [React Docs](https://react.dev/)
- [Prisma Docs](https://www.prisma.io/docs)
- [Material-UI Docs](https://mui.com/)
- [Express Docs](https://expressjs.com/)
- [Socket.IO Docs](https://socket.io/docs/)
