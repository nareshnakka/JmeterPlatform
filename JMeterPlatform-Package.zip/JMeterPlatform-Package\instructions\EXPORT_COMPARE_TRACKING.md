# Test Results Export & Analysis Features

## Overview

This document covers the features for exporting test results, comparing tests, and tracking test execution over time.

## 1. Export Results to CSV

### Export Types

#### Summary Export
Basic test summary with key metrics:
```csv
Test ID,Test Name,Started At,Completed At,Duration (s),Total Samples,Error Count,Error Rate (%),Avg Response Time (ms),Min Response Time (ms),Max Response Time (ms),P50 (ms),P90 (ms),P95 (ms),P99 (ms),Throughput (req/s)
uuid-1,Load Test 100 users,2026-01-25 10:00:00,2026-01-25 10:05:00,300,15000,150,1.0,234.5,45,1250,220,450,650,980,50.5
```

#### Detailed Export
Individual request/sample data:
```csv
Timestamp,Label,Response Time (ms),Success,Error Message,Response Code,Bytes,Sent Bytes,Latency (ms),Connect Time (ms),Active Threads,URL
2026-01-25 10:00:01,HTTP Request,234,true,,200,1024,512,230,45,100,https://api.example.com/users
2026-01-25 10:00:02,HTTP Request,245,true,,200,1024,512,241,43,100,https://api.example.com/users
2026-01-25 10:00:03,API Login,189,true,,200,512,256,185,40,100,https://api.example.com/login
```

#### Metrics Export
Time-series metrics for tracking:
```csv
Timestamp,Active Threads,Throughput (req/s),Avg Response Time (ms),Error Rate (%),CPU %,Memory (MB)
2026-01-25 10:00:00,100,50.5,234,1.0,45.2,2048
2026-01-25 10:00:05,100,51.2,230,0.8,46.1,2056
2026-01-25 10:00:10,100,52.1,228,0.7,44.8,2062
```

### Usage Examples

#### Frontend Implementation

```typescript
// Export service
export const exportTestResults = async (
  testId: string, 
  type: 'summary' | 'detailed' | 'metrics' = 'summary'
) => {
  const response = await axios.get(
    `/api/tests/${testId}/export/csv?type=${type}`,
    { responseType: 'blob' }
  );
  
  // Download file
  const url = window.URL.createObjectURL(new Blob([response.data]));
  const link = document.createElement('a');
  link.href = url;
  link.setAttribute('download', `test-results-${testId}-${type}.csv`);
  document.body.appendChild(link);
  link.click();
  link.remove();
};

// React component
function ExportButton({ testId }: { testId: string }) {
  const [exportType, setExportType] = useState<'summary' | 'detailed' | 'metrics'>('summary');
  
  const handleExport = async () => {
    await exportTestResults(testId, exportType);
  };
  
  return (
    <div>
      <Select value={exportType} onChange={(e) => setExportType(e.target.value)}>
        <MenuItem value="summary">Summary</MenuItem>
        <MenuItem value="detailed">Detailed</MenuItem>
        <MenuItem value="metrics">Metrics</MenuItem>
      </Select>
      <Button onClick={handleExport} startIcon={<DownloadIcon />}>
        Export CSV
      </Button>
    </div>
  );
}
```

#### Backend Implementation

```typescript
// Export controller
export const exportTestResultsCSV = async (req: Request, res: Response) => {
  const { testId } = req.params;
  const { type = 'summary' } = req.query;
  
  const test = await prisma.test.findUnique({
    where: { id: testId },
    include: { 
      results: true,
      metrics: type === 'metrics',
      script: true
    }
  });
  
  if (!test) {
    return res.status(404).json({ error: 'Test not found' });
  }
  
  let csv: string;
  
  switch (type) {
    case 'summary':
      csv = generateSummaryCSV(test);
      break;
    case 'detailed':
      csv = await generateDetailedCSV(test);
      break;
    case 'metrics':
      csv = generateMetricsCSV(test);
      break;
    default:
      csv = generateSummaryCSV(test);
  }
  
  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', `attachment; filename="test-results-${testId}-${type}.csv"`);
  res.send(csv);
};

// CSV generators
function generateSummaryCSV(test: Test): string {
  const headers = [
    'Test ID', 'Test Name', 'Started At', 'Completed At', 
    'Duration (s)', 'Total Samples', 'Error Count', 'Error Rate (%)',
    'Avg Response Time (ms)', 'Min Response Time (ms)', 
    'Max Response Time (ms)', 'P50 (ms)', 'P90 (ms)', 
    'P95 (ms)', 'P99 (ms)', 'Throughput (req/s)'
  ];
  
  const row = [
    test.id,
    test.name,
    test.startedAt.toISOString(),
    test.completedAt?.toISOString() || '',
    test.durationSeconds,
    test.results.totalSamples,
    test.results.errorCount,
    ((test.results.errorCount / test.results.totalSamples) * 100).toFixed(2),
    test.results.avgResponseTime.toFixed(2),
    test.results.minResponseTime,
    test.results.maxResponseTime,
    test.results.p50ResponseTime,
    test.results.p90ResponseTime,
    test.results.p95ResponseTime,
    test.results.p99ResponseTime,
    test.results.throughput.toFixed(2)
  ];
  
  return [headers.join(','), row.join(',')].join('\n');
}

function generateMetricsCSV(test: Test): string {
  const headers = [
    'Timestamp', 'Active Threads', 'Throughput (req/s)', 
    'Avg Response Time (ms)', 'Error Rate (%)', 'CPU %', 'Memory (MB)'
  ];
  
  const rows = test.metrics.map(m => [
    m.timestamp.toISOString(),
    m.activeThreads,
    m.throughput.toFixed(2),
    m.avgResponseTime.toFixed(2),
    (m.errorRate * 100).toFixed(2),
    m.cpuPercent?.toFixed(1) || '',
    m.memoryMb || ''
  ].join(','));
  
  return [headers.join(','), ...rows].join('\n');
}
```

## 2. Compare Multiple Tests

### Comparison Features

- Compare up to 10 tests simultaneously
- Side-by-side metric comparison
- Visual charts for easy analysis
- Save comparisons for future reference
- Export comparison results

### Frontend Implementation

```typescript
// Comparison component
function TestComparison() {
  const [selectedTests, setSelectedTests] = useState<string[]>([]);
  const [comparisonData, setComparisonData] = useState(null);
  
  const handleCompare = async () => {
    const response = await axios.post('/api/tests/compare', {
      testIds: selectedTests,
      metrics: ['avgResponseTime', 'throughput', 'errorRate', 'p95']
    });
    setComparisonData(response.data);
  };
  
  return (
    <Box>
      <Typography variant="h5">Compare Tests</Typography>
      
      {/* Test Selection */}
      <TestSelector 
        selectedTests={selectedTests}
        onSelectionChange={setSelectedTests}
        maxSelection={10}
      />
      
      <Button 
        onClick={handleCompare} 
        disabled={selectedTests.length < 2}
        variant="contained"
      >
        Compare Tests
      </Button>
      
      {/* Comparison Results */}
      {comparisonData && (
        <Box mt={3}>
          <ComparisonTable data={comparisonData} />
          <ComparisonCharts data={comparisonData} />
        </Box>
      )}
    </Box>
  );
}

// Comparison table
function ComparisonTable({ data }: { data: any }) {
  return (
    <TableContainer>
      <Table>
        <TableHead>
          <TableRow>
            <TableCell>Test Name</TableCell>
            <TableCell>Date</TableCell>
            <TableCell>Avg Response Time</TableCell>
            <TableCell>Throughput</TableCell>
            <TableCell>Error Rate</TableCell>
            <TableCell>P95</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {data.comparison.tests.map((test: any) => (
            <TableRow key={test.id}>
              <TableCell>{test.name}</TableCell>
              <TableCell>{new Date(test.startedAt).toLocaleDateString()}</TableCell>
              <TableCell>
                {test.metrics.avgResponseTime}ms
                {test.id === data.comparison.summary.bestAvgResponseTime && ' 🏆'}
              </TableCell>
              <TableCell>
                {test.metrics.throughput} req/s
                {test.id === data.comparison.summary.bestThroughput && ' 🏆'}
              </TableCell>
              <TableCell>
                {(test.metrics.errorRate * 100).toFixed(2)}%
                {test.id === data.comparison.summary.lowestErrorRate && ' 🏆'}
              </TableCell>
              <TableCell>{test.metrics.p95}ms</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
}

// Comparison charts
function ComparisonCharts({ data }: { data: any }) {
  const chartData = data.comparison.tests.map((test: any) => ({
    name: test.name.substring(0, 20),
    'Avg Response Time': test.metrics.avgResponseTime,
    'Throughput': test.metrics.throughput,
    'Error Rate': test.metrics.errorRate * 100
  }));
  
  return (
    <Grid container spacing={3}>
      <Grid item xs={12} md={6}>
        <Typography variant="h6">Response Time Comparison</Typography>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="Avg Response Time" fill="#8884d8" />
          </BarChart>
        </ResponsiveContainer>
      </Grid>
      
      <Grid item xs={12} md={6}>
        <Typography variant="h6">Throughput Comparison</Typography>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="Throughput" fill="#82ca9d" />
          </BarChart>
        </ResponsiveContainer>
      </Grid>
    </Grid>
  );
}
```

### Backend Implementation

```typescript
export const compareTests = async (req: Request, res: Response) => {
  const { testIds, metrics } = req.body;
  
  if (testIds.length < 2 || testIds.length > 10) {
    return res.status(400).json({ 
      error: 'Please select between 2 and 10 tests to compare' 
    });
  }
  
  const tests = await prisma.test.findMany({
    where: { id: { in: testIds } },
    include: { results: true, script: true }
  });
  
  const comparison = {
    tests: tests.map(test => ({
      id: test.id,
      name: test.name,
      startedAt: test.startedAt,
      completedAt: test.completedAt,
      metrics: {
        avgResponseTime: test.results.avgResponseTime,
        throughput: test.results.throughput,
        errorRate: test.results.errorCount / test.results.totalSamples,
        p95: test.results.p95ResponseTime,
        p99: test.results.p99ResponseTime
      }
    })),
    summary: {
      bestAvgResponseTime: findBestTest(tests, 'avgResponseTime', 'min'),
      bestThroughput: findBestTest(tests, 'throughput', 'max'),
      lowestErrorRate: findBestTest(tests, 'errorRate', 'min')
    }
  };
  
  res.json({ comparison });
};

function findBestTest(tests: Test[], metric: string, direction: 'min' | 'max'): string {
  const sorted = tests.sort((a, b) => {
    const aValue = a.results[metric];
    const bValue = b.results[metric];
    return direction === 'min' ? aValue - bValue : bValue - aValue;
  });
  return sorted[0].id;
}
```

## 3. Test Tracking

### Real-Time Metrics Tracking

Track test execution with time-series data:

```typescript
// Metrics collection service
class MetricsCollector {
  async collectMetrics(testId: string, data: MetricData) {
    await prisma.testMetric.create({
      data: {
        testId,
        timestamp: new Date(),
        activeThreads: data.activeThreads,
        throughput: data.throughput,
        avgResponseTime: data.avgResponseTime,
        errorRate: data.errorRate,
        cpuPercent: data.cpuPercent,
        memoryMb: data.memoryMb
      }
    });
  }
}

// Frontend real-time tracking
function TestTracker({ testId }: { testId: string }) {
  const [metrics, setMetrics] = useState<MetricPoint[]>([]);
  
  useEffect(() => {
    const ws = new WebSocket(`ws://backend/ws?token=${token}`);
    
    ws.onopen = () => {
      ws.send(JSON.stringify({ type: 'subscribe', testId }));
    };
    
    ws.onmessage = (event) => {
      const data = JSON.parse(event.data);
      if (data.type === 'metrics') {
        setMetrics(prev => [...prev, data.data]);
      }
    };
    
    return () => ws.close();
  }, [testId]);
  
  return (
    <Box>
      <Typography variant="h6">Test Execution Tracking</Typography>
      
      <Grid container spacing={3}>
        <Grid item xs={12} md={6}>
          <MetricChart 
            title="Throughput Over Time"
            data={metrics}
            dataKey="throughput"
            unit="req/s"
          />
        </Grid>
        
        <Grid item xs={12} md={6}>
          <MetricChart 
            title="Response Time Over Time"
            data={metrics}
            dataKey="avgResponseTime"
            unit="ms"
          />
        </Grid>
        
        <Grid item xs={12} md={6}>
          <MetricChart 
            title="Active Threads"
            data={metrics}
            dataKey="activeThreads"
            unit="threads"
          />
        </Grid>
        
        <Grid item xs={12} md={6}>
          <MetricChart 
            title="Error Rate"
            data={metrics}
            dataKey="errorRate"
            unit="%"
          />
        </Grid>
      </Grid>
    </Box>
  );
}
```

### Test History & Tags

```typescript
// Test history component
function TestHistory({ projectId }: { projectId: string }) {
  const [tests, setTests] = useState<Test[]>([]);
  const [filters, setFilters] = useState({
    status: 'all',
    tags: [],
    dateFrom: null,
    dateTo: null
  });
  
  const fetchTests = async () => {
    const params = new URLSearchParams();
    params.append('projectId', projectId);
    if (filters.status !== 'all') params.append('status', filters.status);
    if (filters.tags.length) params.append('tags', filters.tags.join(','));
    if (filters.dateFrom) params.append('dateFrom', filters.dateFrom);
    if (filters.dateTo) params.append('dateTo', filters.dateTo);
    
    const response = await axios.get(`/api/tests/search?${params}`);
    setTests(response.data.tests);
  };
  
  return (
    <Box>
      <TestFilters filters={filters} onChange={setFilters} />
      <TestList tests={tests} />
    </Box>
  );
}
```

### Test Notes & Documentation

```typescript
// Add note to test
function TestNotes({ testId }: { testId: string }) {
  const [notes, setNotes] = useState<Note[]>([]);
  const [newNote, setNewNote] = useState('');
  
  const addNote = async () => {
    await axios.post(`/api/tests/${testId}/notes`, { note: newNote });
    setNewNote('');
    fetchNotes();
  };
  
  return (
    <Box>
      <Typography variant="h6">Test Notes</Typography>
      
      <TextField
        fullWidth
        multiline
        rows={3}
        value={newNote}
        onChange={(e) => setNewNote(e.target.value)}
        placeholder="Add a note about this test..."
      />
      <Button onClick={addNote}>Add Note</Button>
      
      <List>
        {notes.map(note => (
          <ListItem key={note.id}>
            <ListItemText
              primary={note.note}
              secondary={`${note.userName} - ${new Date(note.createdAt).toLocaleString()}`}
            />
          </ListItem>
        ))}
      </List>
    </Box>
  );
}
```

## Summary

### Export Features
- ✅ Export to CSV (summary, detailed, metrics)
- ✅ Export to JSON
- ✅ Multiple export formats
- ✅ Download directly from UI

### Comparison Features
- ✅ Compare up to 10 tests
- ✅ Side-by-side metrics
- ✅ Visual charts
- ✅ Save comparisons
- ✅ Best performer highlighting

### Tracking Features
- ✅ Real-time metrics
- ✅ Time-series data
- ✅ Test history
- ✅ Tags for organization
- ✅ Notes and documentation
- ✅ Advanced search and filtering
