import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Container,
  Typography,
  Button,
  Card,
  CardContent,
  Grid,
  Box,
  Tabs,
  Tab,
  List,
  ListItem,
  ListItemText,
  ListItemSecondaryAction,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Alert,
  Chip,
  CircularProgress,
  Autocomplete,
  Tooltip,
  Divider,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Checkbox,
} from '@mui/material';
import UploadIcon from '@mui/icons-material/Upload';
import DeleteIcon from '@mui/icons-material/Delete';
import PlayArrowIcon from '@mui/icons-material/PlayArrow';
import EditIcon from '@mui/icons-material/Edit';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import HistoryIcon from '@mui/icons-material/History';
import DownloadIcon from '@mui/icons-material/Download';
import SwapHorizIcon from '@mui/icons-material/SwapHoriz';
import { api } from '../api/client';
import { useNotification } from '../components/Notification';

interface Project {
  id: string;
  name: string;
  description: string | null;
}

interface Script {
  id: string;
  scriptKey: string | null;
  scenarioName: string | null;
  name: string;
  filePath: string;
  createdAt: string;
  dependencies: Dependency[];
  tests?: ScriptTest[];
  _count?: { tests: number };
}

interface ScriptTest {
  id: string;
  name: string;
  status: string;
  createdAt: string;
  startedAt: string | null;
  completedAt: string | null;
  threads: number;
  duration: number;
}

interface Dependency {
  id: string;
  name: string;
  type: string;
  filePath: string;
}

interface Test {
  id: string;
  name: string;
  status: string;
  createdAt: string;
  startedAt: string | null;
  completedAt: string | null;
}

interface Agent {
  id: string;
  hostname: string;
  ipAddress: string;
  status: string;
  cores: number;
  memory: number;
  lastSeen: string;
   mode?: string; // 'load' (default) or 'monitor'
}

export default function ProjectDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { showNotification } = useNotification();
  const [project, setProject] = useState<Project | null>(null);
  const [scripts, setScripts] = useState<Script[]>([]);
  const [tests, setTests] = useState<Test[]>([]);
  const [selectedTests, setSelectedTests] = useState<string[]>([]);
  const [agents, setAgents] = useState<Agent[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [tabValue, setTabValue] = useState(0);
  const [openUploadDialog, setOpenUploadDialog] = useState(false);
  const [openTestDialog, setOpenTestDialog] = useState(false);
  const [openDependencyDialog, setOpenDependencyDialog] = useState(false);
  const [openReplaceDialog, setOpenReplaceDialog] = useState(false);
  const [openScenarioDialog, setOpenScenarioDialog] = useState(false);
  const [selectedScript, setSelectedScript] = useState<string | null>(null);
  const [editingScript, setEditingScript] = useState<Script | null>(null);
  const [scriptFile, setScriptFile] = useState<File | null>(null);
  const [replaceScriptFile, setReplaceScriptFile] = useState<File | null>(null);
  const [scenarioName, setScenarioName] = useState('');
  const [dependencyFiles, setDependencyFiles] = useState<File[]>([]);
  const [dependencyType, setDependencyType] = useState<'jar' | 'csv' | 'properties' | 'txt' | 'json' | 'xml'>('csv');
  const [testName, setTestName] = useState('');
  const [selectedAgents, setSelectedAgents] = useState<Agent[]>([]);
  const [threads, setThreads] = useState(10);
  const [duration, setDuration] = useState(60);
  const [rampUp, setRampUp] = useState(10);
  const [startImmediately, setStartImmediately] = useState(true);
  const [scenarioOverrideEnabled, setScenarioOverrideEnabled] = useState(false);
  const [threadGroupsConfig, setThreadGroupsConfig] = useState<
    { name: string; threads: number; rampUp: number; duration: number }[]
  >([]);
  // Snapshot of scenario config used for the current test run (not persisted)
  const [runThreadGroupsConfig, setRunThreadGroupsConfig] = useState<
    { name: string; threads: number; rampUp: number; duration: number }[]
  >([]);
  const [loadingScenario, setLoadingScenario] = useState(false);

  const LAST_SELECTED_AGENTS_KEY = 'jmeter_last_selected_agents_by_project';

  const buildDefaultTestName = (scriptId: string | null, totalThreads: number): string => {
    if (!scriptId) return '';
    const script = scripts.find(s => s.id === scriptId);
    if (!script) return '';

    const rawName = script.scenarioName && script.scenarioName.trim()
      ? script.scenarioName.trim()
      : script.name.replace(/\.[^/.]+$/, '');

    const now = new Date();
    const pad = (n: number) => n.toString().padStart(2, '0');
    const ts = `${now.getFullYear()}${pad(now.getMonth() + 1)}${pad(now.getDate())}${pad(now.getHours())}${pad(now.getMinutes())}`;

    const users = Math.max(totalThreads || 0, 0);
    return `${rawName}_users${users}_${ts}`;
  };

  useEffect(() => {
    if (id) {
      loadProject();
      loadScripts();
      loadTests();
      loadAgents();
    }
  }, [id]);

  const loadProject = async () => {
    try {
      const data = await api.getProject(id!);
      setProject(data);
      setError(''); // Clear any previous errors
    } catch (err: any) {
      setError(err.response?.data?.error || 'Failed to load project');
    }
  };

  const loadScripts = async () => {
    try {
      setLoading(true);
      const data = await api.getProjectScripts(id!);
      setScripts(data);
      setError(''); // Clear any previous errors
    } catch (err: any) {
      setError(err.response?.data?.error || 'Failed to load scripts');
    } finally {
      setLoading(false);
    }
  };

  const loadTests = async () => {
    try {
      const data = await api.getProjectTests(id!);
      setTests(data);
      setError(''); // Clear any previous errors
    } catch (err: any) {
      setError(err.response?.data?.error || 'Failed to load tests');
    }
  };

  const loadAgents = async () => {
    try {
      const data = await api.getAgents();
      // Filter only online, available, load-generating agents
      const availableAgents = data.filter((agent: Agent) => {
        const lastSeenDate = new Date(agent.lastSeen);
        const now = new Date();
        const diffSeconds = (now.getTime() - lastSeenDate.getTime()) / 1000;
        const isOnline = diffSeconds < 60; // Online if heartbeat within last 60 seconds
        const isAvailable = agent.status !== 'busy'; // Not running a test
        const isLoadAgent = !agent.mode || agent.mode === 'load';
        return isOnline && isAvailable && isLoadAgent;
      });
      setAgents(availableAgents);

      // Apply last selected agents for this project if none selected yet
      if (!selectedAgents.length && id) {
        try {
          const raw = localStorage.getItem(LAST_SELECTED_AGENTS_KEY);
          if (raw) {
            const map = JSON.parse(raw) as Record<string, string[]>;
            const savedIds = map[id];
            if (Array.isArray(savedIds) && savedIds.length > 0) {
              const defaults = availableAgents.filter(a => savedIds.includes(a.id));
              if (defaults.length > 0) {
                setSelectedAgents(defaults);
              }
            }
          }
        } catch (e) {
          // Ignore localStorage/JSON errors
        }
      }
    } catch (err: any) {
      console.error('Failed to load agents:', err);
    }
  };

  const handleUploadScript = async () => {
    if (!scriptFile) return;

    try {
      const formData = new FormData();
      formData.append('file', scriptFile);
      formData.append('projectId', id!);
      formData.append('name', scriptFile.name);
      if (scenarioName.trim()) {
        formData.append('scenarioName', scenarioName.trim());
      }

      // Upload the script first
      const script = await api.uploadScript(formData);
      
      // Upload dependencies if any
      if (dependencyFiles.length > 0) {
        for (const depFile of dependencyFiles) {
          const depFormData = new FormData();
          depFormData.append('file', depFile);
          
          // Determine type from file extension
          const ext = depFile.name.split('.').pop()?.toLowerCase() || '';
          depFormData.append('type', ext);
          
          await api.addDependency(script.id, depFormData);
        }
      }

      setOpenUploadDialog(false);
      setScriptFile(null);
      setScenarioName('');
      setDependencyFiles([]);
      loadScripts();
      showNotification('✅ Script uploaded successfully!', 'success');
    } catch (err: any) {
      setError(err.response?.data?.error || 'Failed to upload script');
      showNotification('❌ Failed to upload script', 'error');
    }
  };

  const handleAddDependency = async () => {
    if (dependencyFiles.length === 0 || !selectedScript) return;

    try {
      for (const depFile of dependencyFiles) {
        const formData = new FormData();
        formData.append('file', depFile);
        formData.append('type', dependencyType);

        await api.addDependency(selectedScript, formData);
      }
      
      setOpenDependencyDialog(false);
      setDependencyFiles([]);
      setSelectedScript(null);
      loadScripts();
      showNotification('✅ Dependencies added successfully!', 'success');
    } catch (err: any) {
      setError(err.response?.data?.error || 'Failed to add dependency');
      showNotification('❌ Failed to add dependencies', 'error');
    }
  };

  const handleCreateTest = async () => {
    if (!testName || !selectedScript || selectedAgents.length === 0) return;

    try {
      // When per-thread-group overrides are present, derive overall
      // test-level settings from them so the backend has consistent
      // aggregate values, while JMX still uses per-group overrides.
      const totalThreads = hasPerThreadOverrides
        ? runThreadGroupsConfig.reduce((sum, g) => sum + (g.threads || 0), 0)
        : threads;
      const totalDuration = hasPerThreadOverrides
        ? runThreadGroupsConfig.reduce((max, g) => Math.max(max, g.duration || 0), 0) || duration
        : duration;
      const totalRampUp = hasPerThreadOverrides
        ? runThreadGroupsConfig.reduce((max, g) => Math.max(max, g.rampUp || 0), 0) || rampUp
        : rampUp;

      const test = await api.createTest({
        name: testName,
        scriptId: selectedScript,
        projectId: id!,
        threads: totalThreads,
        duration: totalDuration,
        rampUp: totalRampUp,
        agentIds: selectedAgents.map(a => a.id),
      });

      // Remember last selected agents for this project
      try {
        const raw = localStorage.getItem(LAST_SELECTED_AGENTS_KEY);
        const map = raw ? (JSON.parse(raw) as Record<string, string[]>) : {};
        map[id!] = selectedAgents.map(a => a.id);
        localStorage.setItem(LAST_SELECTED_AGENTS_KEY, JSON.stringify(map));
      } catch (e) {
        // Ignore localStorage/JSON errors
      }
      
      // Start test immediately if requested
      if (startImmediately) {
        try {
          await api.startTest(
            test.id,
            runThreadGroupsConfig.length
              ? { threadGroups: runThreadGroupsConfig }
              : undefined
          );
          setError('');
          
          showNotification(`🚀 Test "${testName}" started successfully!`, 'success');
          
          // Close dialog and navigate to test detail page
          setOpenTestDialog(false);
          setTestName('');
          setSelectedScript(null);
          setSelectedAgents([]);
          setThreads(10);
          setDuration(60);
          setRampUp(10);
          setRunThreadGroupsConfig([]);
          setStartImmediately(true);
          
          // Navigate to live dashboard
          setTimeout(() => {
            navigate(`/tests/${test.id}`);
          }, 300);
          
        } catch (startErr: any) {
          setError(startErr.response?.data?.error || 'Test created but failed to start');
          showNotification('❌ Test created but failed to start', 'error');
        }
      } else {
        setOpenTestDialog(false);
        setTestName('');
        setSelectedScript(null);
        setSelectedAgents([]);
        setThreads(10);
        setDuration(60);
        setRampUp(10);
        setRunThreadGroupsConfig([]);
        setStartImmediately(true);
        loadTests();
        
        showNotification(`✅ Test "${testName}" created successfully!`, 'success');
      }
      
    } catch (err: any) {
      setError(err.response?.data?.error || 'Failed to create test');
      showNotification('❌ Failed to create test', 'error');
    }
  };

  const handleDownloadScriptZip = async (script: Script, e?: React.MouseEvent) => {
    if (e) {
      e.stopPropagation();
    }
    
    try {
      const fileName = `${script.scenarioName || script.name.replace(/\.[^/.]+$/, '')}-files.zip`;
      await api.downloadScriptZip(script.id, fileName);
      setError('');
      showNotification(`📦 Downloaded ${fileName}`, 'success');
    } catch (err: any) {
      setError(err.response?.data?.error || 'Failed to download files');
      showNotification('❌ Failed to download files', 'error');
      console.error('Download ZIP error:', err);
    }
  };

  const handleEditScript = async (script: Script, e?: React.MouseEvent) => {
    if (e) {
      e.stopPropagation();
    }
    try {
      setLoadingScenario(true);
      setEditingScript(script);
      setSelectedScript(script.id);
      const data = await api.getScriptThreadGroups(script.id);
      setScenarioOverrideEnabled(Boolean(data.overrideEnabled));
      setThreadGroupsConfig(
        Array.isArray(data.groups)
          ? data.groups.map((g: any) => ({
              name: g.name,
              threads: g.threads ?? 10,
              rampUp: g.rampUp ?? 10,
              duration: g.duration ?? 60,
            }))
          : []
      );
      setOpenScenarioDialog(true);
    } catch (err: any) {
      console.error('Failed to load scenario configuration:', err);
      showNotification(
        err.response?.data?.error || '❌ Failed to load scenario configuration',
        'error'
      );
    } finally {
      setLoadingScenario(false);
    }
  };

  const handleReplaceScript = async () => {
    if (!replaceScriptFile || !selectedScript) return;

    try {
      const formData = new FormData();
      formData.append('file', replaceScriptFile);

      await api.replaceScript(selectedScript, formData);
      
      setOpenReplaceDialog(false);
      setReplaceScriptFile(null);
      setSelectedScript(null);
      loadScripts();
      setError('');
      showNotification('🔄 Script replaced successfully!', 'success');
    } catch (err: any) {
      setError(err.response?.data?.error || 'Failed to replace script');
      showNotification('❌ Failed to replace script', 'error');
      console.error('Replace script error:', err);
    }
  };

  const handleDeleteScript = async (scriptId: string, e?: React.MouseEvent) => {
    if (e) {
      e.stopPropagation();
    }
    
    if (!window.confirm('Are you sure you want to delete this script?')) return;

    try {
      await api.deleteScript(scriptId);
      loadScripts();
      setError('');
      showNotification('🗑️ Script deleted successfully!', 'success');
    } catch (err: any) {
      setError(err.response?.data?.error || 'Failed to delete script');
      showNotification('❌ Failed to delete script', 'error');
      console.error('Delete script error:', err);
    }
  };

  const handleStartTest = async (testId: string) => {
    try {
      await api.startTest(testId);
      setError('');
      showNotification('🚀 Test started!', 'success');
      
      // Navigate to live dashboard
      navigate(`/tests/${testId}`);
      
    } catch (err: any) {
      setError(err.response?.data?.error || 'Failed to start test');
      showNotification('❌ Failed to start test', 'error');
    }
  };

  const handleDeleteTests = async () => {
    if (selectedTests.length === 0) return;
    
    if (!window.confirm(`Are you sure you want to delete ${selectedTests.length} test(s)?`)) {
      return;
    }

    try {
      await api.deleteTests(selectedTests);
      setSelectedTests([]);
      loadTests();
      setError('');
      showNotification(`🗑️ Deleted ${selectedTests.length} test(s) successfully!`, 'success');
    } catch (err: any) {
      setError(err.response?.data?.error || 'Failed to delete tests');
      showNotification('❌ Failed to delete tests', 'error');
    }
  };

  const handleDeleteTest = async (testId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    
    if (!window.confirm('Are you sure you want to delete this test?')) {
      return;
    }

    try {
      await api.deleteTest(testId);
      loadTests();
      setError('');
      showNotification('🗑️ Test deleted successfully!', 'success');
    } catch (err: any) {
      setError(err.response?.data?.error || 'Failed to delete test');
      showNotification('❌ Failed to delete test', 'error');
    }
  };


  const handleScenarioFieldChange = (
    index: number,
    field: 'threads' | 'rampUp' | 'duration',
    value: string
  ) => {
    setThreadGroupsConfig((prev) => {
      const next = [...prev];
      const numeric = parseInt(value, 10);
      const safeValue = Number.isNaN(numeric) ? 0 : numeric;
      next[index] = {
        ...next[index],
        [field]: safeValue,
      };
      return next;
    });
  };

  const handleSaveScenario = async () => {
    if (!selectedScript) return;

    try {
      await api.updateScriptThreadGroups(selectedScript, {
        overrideEnabled: scenarioOverrideEnabled,
        groups: threadGroupsConfig,
      });
      showNotification('✅ Scenario configuration saved successfully!', 'success');
      setOpenScenarioDialog(false);
      setEditingScript(null);
      setSelectedScript(null);
      // Reload scripts to reflect any metadata changes
      loadScripts();
    } catch (err: any) {
      console.error('Failed to save scenario configuration:', err);
      showNotification(
        err.response?.data?.error || '❌ Failed to save scenario configuration',
        'error'
      );
    }
  };
  if (loading || !project) {
    return (
      <Container maxWidth={false} sx={{ mt: 4, mb: 4, textAlign: 'center' }}>
        <CircularProgress />
      </Container>
    );
  }

  // Derived effective configuration when per-thread-group overrides are present
  const hasPerThreadOverrides = runThreadGroupsConfig.length > 0;
  const derivedThreads = hasPerThreadOverrides
    ? runThreadGroupsConfig.reduce((sum, g) => sum + (g.threads || 0), 0)
    : threads;
  const derivedDuration = hasPerThreadOverrides
    ? runThreadGroupsConfig.reduce((max, g) => Math.max(max, g.duration || 0), 0) || duration
    : duration;
  const derivedRampUp = hasPerThreadOverrides
    ? runThreadGroupsConfig.reduce((max, g) => Math.max(max, g.rampUp || 0), 0) || rampUp
    : rampUp;

  return (
    <Container maxWidth={false} sx={{ mt: 4, mb: 4 }}>
      <Box sx={{ mb: 3 }}>
        <Button
          startIcon={<ArrowBackIcon />}
          onClick={() => navigate('/projects')}
          sx={{ mb: 2 }}
        >
          Back to Projects
        </Button>
        <Typography variant="h4">{project.name}</Typography>
        {project.description && (
          <Typography color="text.secondary">{project.description}</Typography>
        )}
      </Box>

      {error && (
        <Alert severity="error" sx={{ mb: 3 }} onClose={() => setError('')}>
          {error}
        </Alert>
      )}

      <Box sx={{ borderBottom: 1, borderColor: 'divider', mb: 3 }}>
        <Tabs value={tabValue} onChange={(_, v) => setTabValue(v)}>
          <Tab label={`Scripts (${scripts.length})`} />
          <Tab label={`Tests (${tests.length})`} />
        </Tabs>
      </Box>

      {tabValue === 0 && (
        <Box>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2 }}>
            <Typography variant="h6">JMeter Scripts</Typography>
      {/* Edit Scenario Dialog */}
      <Dialog
        open={openScenarioDialog}
        onClose={() => {
          setOpenScenarioDialog(false);
          setEditingScript(null);
          setSelectedScript(null);
        }}
        maxWidth="md"
        fullWidth
      >
        <DialogTitle>
          Edit Scenario{editingScript ? ` - ${editingScript.scenarioName || editingScript.name}` : ''}
        </DialogTitle>
        <DialogContent dividers>
          {loadingScenario ? (
            <Box display="flex" justifyContent="center" alignItems="center" py={4}>
              <CircularProgress size={32} />
            </Box>
          ) : threadGroupsConfig.length === 0 ? (
            <Typography variant="body2" color="text.secondary">
              No Thread Groups were detected in this JMX script.
            </Typography>
          ) : (
            <Box>
              <Typography variant="body2" color="text.secondary" mb={2}>
                Configure per-thread-group settings for this scenario. These settings are stored with the
                script and can be used to drive a multi-thread-group model.
              </Typography>
              <Box display="flex" alignItems="center" mb={2}>
                <Checkbox
                  checked={scenarioOverrideEnabled}
                  onChange={(e) => setScenarioOverrideEnabled(e.target.checked)}
                />
                <Typography variant="body2">Override Script settings</Typography>
              </Box>
              {!scenarioOverrideEnabled && (
                <Alert severity="info" sx={{ mb: 2 }}>
                  Overrides are currently disabled. Enable "Override Script settings" to edit per-thread-group
                  values.
                </Alert>
              )}
              <Grid container spacing={2}>
                {threadGroupsConfig.map((tg, index) => (
                  <Grid item xs={12} key={tg.name + index}>
                    <Card variant="outlined">
                      <CardContent>
                        <Typography variant="subtitle1" gutterBottom>
                          {tg.name}
                        </Typography>
                        <Grid container spacing={2}>
                          <Grid item xs={12} sm={4}>
                            <TextField
                              label="Threads"
                              type="number"
                              fullWidth
                              size="small"
                              value={tg.threads}
                              onChange={(e) =>
                                handleScenarioFieldChange(index, 'threads', e.target.value)
                              }
                              disabled={!scenarioOverrideEnabled}
                              inputProps={{ min: 1 }}
                            />
                          </Grid>
                          <Grid item xs={12} sm={4}>
                            <TextField
                              label="Ramp-up (seconds)"
                              type="number"
                              fullWidth
                              size="small"
                              value={tg.rampUp}
                              onChange={(e) =>
                                handleScenarioFieldChange(index, 'rampUp', e.target.value)
                              }
                              disabled={!scenarioOverrideEnabled}
                              inputProps={{ min: 0 }}
                            />
                          </Grid>
                          <Grid item xs={12} sm={4}>
                            <TextField
                              label="Duration (seconds)"
                              type="number"
                              fullWidth
                              size="small"
                              value={tg.duration}
                              onChange={(e) =>
                                handleScenarioFieldChange(index, 'duration', e.target.value)
                              }
                              disabled={!scenarioOverrideEnabled}
                              inputProps={{ min: 1 }}
                            />
                          </Grid>
                        </Grid>
                      </CardContent>
                    </Card>
                  </Grid>
                ))}
              </Grid>
            </Box>
          )}
        </DialogContent>
        <DialogActions>
          <Button
            onClick={() => {
              setOpenScenarioDialog(false);
              setEditingScript(null);
              setSelectedScript(null);
            }}
          >
            Cancel
          </Button>
          <Button
            onClick={handleSaveScenario}
            variant="contained"
            color="primary"
            disabled={loadingScenario || threadGroupsConfig.length === 0}
          >
            Save
          </Button>
        </DialogActions>
      </Dialog>
            <Button
              variant="contained"
              startIcon={<UploadIcon />}
              onClick={() => setOpenUploadDialog(true)}
            >
              Upload Script
            </Button>
          </Box>

          {scripts.length === 0 ? (
            <Card>
              <CardContent sx={{ textAlign: 'center', py: 8 }}>
                <Typography variant="h6" gutterBottom>
                  No scripts uploaded
                </Typography>
                <Typography color="text.secondary" sx={{ mb: 3 }}>
                  Upload a JMeter (.jmx) script to get started
                </Typography>
                <Button
                  variant="contained"
                  startIcon={<UploadIcon />}
                  onClick={() => setOpenUploadDialog(true)}
                >
                  Upload Script
                </Button>
              </CardContent>
            </Card>
          ) : (
            <TableContainer component={Paper} sx={{ boxShadow: 3 }}>
              <Table>
                <TableHead sx={{ bgcolor: '#f5f5f5' }}>
                  <TableRow>
                    <TableCell sx={{ fontWeight: 700, color: '#667eea' }}>Script Key</TableCell>
                    <TableCell sx={{ fontWeight: 700, color: '#667eea' }}>Name</TableCell>
                    <TableCell sx={{ fontWeight: 700, color: '#667eea' }}>Tests</TableCell>
                    <TableCell sx={{ fontWeight: 700, color: '#667eea' }}>Last Run</TableCell>
                    <TableCell sx={{ fontWeight: 700, color: '#667eea' }}>Dependencies</TableCell>
                    <TableCell sx={{ fontWeight: 700, color: '#667eea' }}>Uploaded</TableCell>
                    <TableCell align="right" sx={{ fontWeight: 700, color: '#667eea' }}>Actions</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {scripts.map((script) => {
                    const lastTest = script.tests && script.tests.length > 0 ? script.tests[0] : null;
                    const testCount = script._count?.tests || 0;
                    
                    return (
                      <TableRow 
                        key={script.id}
                        sx={{ 
                          '&:hover': { bgcolor: '#f9f9f9' }
                        }}
                      >
                        <TableCell>
                          <Chip 
                            label={script.scriptKey || 'N/A'} 
                            size="small" 
                            sx={{ 
                              bgcolor: '#e3f2fd', 
                              color: '#1976d2',
                              fontWeight: 600,
                              fontFamily: 'monospace'
                            }}
                          />
                        </TableCell>
                        <TableCell>
                          <Box>
                            {script.scenarioName && (
                              <Typography 
                                variant="body2" 
                                sx={{ fontWeight: 600, cursor: 'pointer', color: '#667eea', mb: 0.5 }}
                                onClick={() => navigate(`/scripts/${script.id}/tests`)}
                              >
                                {script.scenarioName}
                              </Typography>
                            )}
                            <Typography 
                              variant="caption" 
                              sx={{ cursor: 'pointer', color: script.scenarioName ? 'text.secondary' : '#667eea', fontWeight: script.scenarioName ? 400 : 600 }}
                              onClick={() => navigate(`/scripts/${script.id}/tests`)}
                            >
                              {script.name}
                            </Typography>
                          </Box>
                        </TableCell>
                        <TableCell>
                          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                            <Chip 
                              label={testCount} 
                              size="small" 
                              color="primary"
                              onClick={() => navigate(`/scripts/${script.id}/tests`)}
                              sx={{ cursor: 'pointer' }}
                            />
                            {testCount > 0 && (
                              <Tooltip title="View all tests">
                                <IconButton 
                                  size="small"
                                  onClick={() => navigate(`/scripts/${script.id}/tests`)}
                                >
                                  <HistoryIcon fontSize="small" />
                                </IconButton>
                              </Tooltip>
                            )}
                          </Box>
                        </TableCell>
                        <TableCell>
                          {lastTest ? (
                            <Box>
                              <Chip 
                                label={lastTest.status} 
                                size="small"
                                color={
                                  lastTest.status === 'completed' ? 'success' :
                                  lastTest.status === 'running' ? 'primary' :
                                  lastTest.status === 'failed' ? 'error' : 'default'
                                }
                              />
                              <Typography variant="caption" display="block" color="text.secondary" sx={{ mt: 0.5 }}>
                                {new Date(lastTest.createdAt).toLocaleDateString()}
                              </Typography>
                            </Box>
                          ) : (
                            <Typography variant="caption" color="text.secondary">
                              No tests yet
                            </Typography>
                          )}
                        </TableCell>
                        <TableCell>
                          {script.dependencies.length > 0 ? (
                            <Chip 
                              label={`${script.dependencies.length} file(s)`}
                              size="small"
                              variant="outlined"
                            />
                          ) : (
                            <Typography variant="caption" color="text.secondary">None</Typography>
                          )}
                        </TableCell>
                        <TableCell>
                          <Typography variant="caption" color="text.secondary">
                            {new Date(script.createdAt).toLocaleDateString()}
                          </Typography>
                        </TableCell>
                        <TableCell align="right">
                          <Tooltip title="Run Test">
                            <IconButton
                              size="small"
                              onClick={async () => {
                                setSelectedScript(script.id);
                                // Initialize per-run thread group config from saved scenario for this script
                                try {
                                  const data = await api.getScriptThreadGroups(script.id);
                                  const groups = Array.isArray(data.groups)
                                    ? data.groups.map((g: any) => ({
                                        name: g.name,
                                        threads: g.threads ?? 10,
                                        rampUp: g.rampUp ?? 10,
                                        duration: g.duration ?? 60,
                                      }))
                                    : [];
                                  setRunThreadGroupsConfig(groups);
                                  // Auto-generate test name based on JMX (script) and total users
                                  const totalFromGroups = groups.length
                                    ? groups.reduce((sum: number, g: any) => sum + (g.threads || 0), 0)
                                    : threads;
                                  setTestName(buildDefaultTestName(script.id, totalFromGroups));
                                } catch (e) {
                                  // If loading fails, keep any existing per-run config empty
                                  setRunThreadGroupsConfig([]);
                                  // Fallback: generate name from current global threads
                                  setTestName(buildDefaultTestName(script.id, threads));
                                }
                                // Apply last selected agents for this project if available
                                if (selectedAgents.length === 0 && agents.length > 0 && id) {
                                  try {
                                    const raw = localStorage.getItem(LAST_SELECTED_AGENTS_KEY);
                                    if (raw) {
                                      const map = JSON.parse(raw) as Record<string, string[]>;
                                      const savedIds = map[id];
                                      if (Array.isArray(savedIds) && savedIds.length > 0) {
                                        const defaults = agents.filter(a => savedIds.includes(a.id));
                                        if (defaults.length > 0) {
                                          setSelectedAgents(defaults);
                                        }
                                      }
                                    }
                                  } catch (e) {
                                    // Ignore localStorage/JSON errors
                                  }
                                }
                                setOpenTestDialog(true);
                              }}
                              sx={{ color: '#4caf50' }}
                            >
                              <PlayArrowIcon />
                            </IconButton>
                          </Tooltip>
                          <Tooltip title="Edit Scenario">
                            <IconButton
                              size="small"
                              onClick={(e) => handleEditScript(script, e)}
                            >
                              <EditIcon fontSize="small" />
                            </IconButton>
                          </Tooltip>
                          <Tooltip title="Download All Files (ZIP)">
                            <IconButton
                              size="small"
                              onClick={(e) => handleDownloadScriptZip(script, e)}
                              sx={{ color: '#2196f3' }}
                            >
                              <DownloadIcon fontSize="small" />
                            </IconButton>
                          </Tooltip>
                          <Tooltip title="Replace Script">
                            <IconButton
                              size="small"
                              onClick={() => {
                                setSelectedScript(script.id);
                                setOpenReplaceDialog(true);
                              }}
                              sx={{ color: '#ff9800' }}
                            >
                              <SwapHorizIcon fontSize="small" />
                            </IconButton>
                          </Tooltip>
                          <Tooltip title="Add Dependency">
                            <IconButton
                              size="small"
                              onClick={() => {
                                setSelectedScript(script.id);
                                setOpenDependencyDialog(true);
                              }}
                            >
                              <UploadIcon fontSize="small" />
                            </IconButton>
                          </Tooltip>
                          <Tooltip title="Delete Script">
                            <IconButton
                              size="small"
                              onClick={(e) => handleDeleteScript(script.id, e)}
                              sx={{ color: '#f44336' }}
                            >
                              <DeleteIcon />
                            </IconButton>
                          </Tooltip>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </TableContainer>
          )}
        </Box>
      )}

      {tabValue === 1 && (
        <Box>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
            <Typography variant="h6">
              Test History
            </Typography>
            {selectedTests.length > 0 && (
              <Button
                variant="contained"
                color="error"
                startIcon={<DeleteIcon />}
                onClick={handleDeleteTests}
              >
                Delete {selectedTests.length} Selected
              </Button>
            )}
          </Box>

          {tests.length === 0 ? (
            <Card>
              <CardContent sx={{ textAlign: 'center', py: 8 }}>
                <Typography variant="h6" gutterBottom>
                  No tests yet
                </Typography>
                <Typography color="text.secondary">
                  Create a test from the Scripts tab
                </Typography>
              </CardContent>
            </Card>
          ) : (
            <List>
              {tests.map((test) => (
                <ListItem key={test.id} divider>
                  <Checkbox
                    checked={selectedTests.includes(test.id)}
                    onChange={() => {
                      setSelectedTests(prev =>
                        prev.includes(test.id)
                          ? prev.filter(id => id !== test.id)
                          : [...prev, test.id]
                      );
                    }}
                    sx={{ mr: 2 }}
                  />
                  <ListItemText
                    primary={
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                        <Typography variant="body1">{test.name}</Typography>
                        <Chip 
                          label={test.status} 
                          size="small" 
                          color={
                            test.status === 'completed' ? 'success' :
                            test.status === 'running' ? 'primary' :
                            test.status === 'failed' ? 'error' : 'default'
                          }
                        />
                      </Box>
                    }
                    secondary={`Created ${new Date(test.createdAt).toLocaleString()}${test.startedAt ? ` • Started ${new Date(test.startedAt).toLocaleString()}` : ''}`}
                  />
                  <ListItemSecondaryAction>
                    {test.status === 'pending' && (
                      <Button
                        size="small"
                        variant="contained"
                        color="success"
                        onClick={() => handleStartTest(test.id)}
                        startIcon={<PlayArrowIcon />}
                        sx={{ mr: 1 }}
                      >
                        Start Test
                      </Button>
                    )}
                    <Button
                      size="small"
                      onClick={() => navigate(`/tests/${test.id}`)}
                      sx={{ mr: 1 }}
                    >
                      View Details
                    </Button>
                    <IconButton
                      size="small"
                      onClick={(e) => handleDeleteTest(test.id, e)}
                      sx={{ color: '#f44336' }}
                    >
                      <DeleteIcon />
                    </IconButton>
                  </ListItemSecondaryAction>
                </ListItem>
              ))}
            </List>
          )}
        </Box>
      )}

      {/* Upload Script Dialog */}
      <Dialog open={openUploadDialog} onClose={() => setOpenUploadDialog(false)} maxWidth="md" fullWidth>
        <DialogTitle sx={{ background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)', color: 'white', fontWeight: 700 }}>
          📤 Upload JMeter Script with Dependencies
        </DialogTitle>
        <DialogContent sx={{ mt: 2 }}>
          <Box sx={{ mb: 3 }}>
            <Typography variant="subtitle2" gutterBottom sx={{ fontWeight: 600 }}>
              Scenario Name (Optional)
            </Typography>
            <TextField
              fullWidth
              size="small"
              placeholder="e.g., User Login Test, API Load Test"
              value={scenarioName}
              onChange={(e) => setScenarioName(e.target.value)}
              helperText="A descriptive name for this test scenario"
            />
          </Box>

          <Box sx={{ mb: 3 }}>
            <Typography variant="subtitle2" gutterBottom sx={{ fontWeight: 600 }}>
              JMeter Script (.jmx) *
            </Typography>
            <input
              type="file"
              accept=".jmx"
              onChange={(e) => setScriptFile(e.target.files?.[0] || null)}
              style={{ marginTop: 8 }}
            />
            <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 1 }}>
              Required: Your main JMeter test script file
            </Typography>
          </Box>

          <Divider sx={{ my: 2 }} />

          <Box>
            <Typography variant="subtitle2" gutterBottom sx={{ fontWeight: 600 }}>
              Dependencies (Optional)
            </Typography>
            <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 2 }}>
              Upload any additional files your script needs (CSV data files, JAR libraries, properties files, etc.)
            </Typography>
            
            <input
              type="file"
              multiple
              accept=".csv,.jar,.properties,.txt,.json,.xml"
              onChange={(e) => setDependencyFiles(Array.from(e.target.files || []))}
              style={{ marginTop: 8 }}
            />
            
            {dependencyFiles.length > 0 && (
              <Box sx={{ mt: 2 }}>
                <Typography variant="caption" sx={{ fontWeight: 600 }}>
                  Selected files ({dependencyFiles.length}):
                </Typography>
                <List dense>
                  {dependencyFiles.map((file, index) => (
                    <ListItem key={index} sx={{ py: 0.5 }}>
                      <ListItemText 
                        primary={file.name}
                        secondary={`${(file.size / 1024).toFixed(2)} KB`}
                      />
                      <IconButton 
                        size="small" 
                        onClick={() => setDependencyFiles(dependencyFiles.filter((_, i) => i !== index))}
                      >
                        <DeleteIcon fontSize="small" />
                      </IconButton>
                    </ListItem>
                  ))}
                </List>
              </Box>
            )}
            
            <Typography variant="caption" color="primary" sx={{ display: 'block', mt: 1 }}>
              Supported: .csv, .jar, .properties, .txt, .json, .xml
            </Typography>
          </Box>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button onClick={() => {
            setOpenUploadDialog(false);
            setScriptFile(null);
            setScenarioName('');
            setDependencyFiles([]);
          }}>
            Cancel
          </Button>
          <Button
            onClick={handleUploadScript}
            variant="contained"
            disabled={!scriptFile}
            sx={{ 
              background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
              '&:hover': { background: 'linear-gradient(135deg, #5568d3 0%, #6a3f8f 100%)' }
            }}
          >
            Upload Script {dependencyFiles.length > 0 && `+ ${dependencyFiles.length} Dependencies`}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Add Dependency Dialog (for existing scripts) */}
      <Dialog open={openDependencyDialog} onClose={() => setOpenDependencyDialog(false)} maxWidth="sm" fullWidth>
        <DialogTitle sx={{ background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)', color: 'white', fontWeight: 700 }}>
          Add Dependency Files
        </DialogTitle>
        <DialogContent sx={{ mt: 2 }}>
          <FormControl fullWidth margin="dense">
            <InputLabel>File Type</InputLabel>
            <Select
              value={dependencyType}
              onChange={(e) => setDependencyType(e.target.value as any)}
            >
              <MenuItem value="csv">CSV Data File</MenuItem>
              <MenuItem value="jar">JAR Library</MenuItem>
              <MenuItem value="properties">Properties File</MenuItem>
              <MenuItem value="txt">Text File</MenuItem>
              <MenuItem value="json">JSON File</MenuItem>
              <MenuItem value="xml">XML File</MenuItem>
            </Select>
          </FormControl>
          <Box sx={{ mt: 2 }}>
            <input
              type="file"
              multiple
              accept={
                dependencyType === 'jar' ? '.jar' :
                dependencyType === 'csv' ? '.csv' :
                dependencyType === 'properties' ? '.properties' :
                dependencyType === 'txt' ? '.txt' :
                dependencyType === 'json' ? '.json' :
                '.xml'
              }
              onChange={(e) => setDependencyFiles(Array.from(e.target.files || []))}
            />
            {dependencyFiles.length > 0 && (
              <Box sx={{ mt: 2 }}>
                <Typography variant="caption" sx={{ fontWeight: 600 }}>
                  Selected: {dependencyFiles.length} file(s)
                </Typography>
                <List dense>
                  {dependencyFiles.map((file, index) => (
                    <ListItem key={index}>
                      <ListItemText primary={file.name} />
                    </ListItem>
                  ))}
                </List>
              </Box>
            )}
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => {
            setOpenDependencyDialog(false);
            setDependencyFiles([]);
          }}>
            Cancel
          </Button>
          <Button
            onClick={handleAddDependency}
            variant="contained"
            disabled={dependencyFiles.length === 0}
            sx={{ 
              background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
              '&:hover': { background: 'linear-gradient(135deg, #5568d3 0%, #6a3f8f 100%)' }
            }}
          >
            Add {dependencyFiles.length} File(s)
          </Button>
        </DialogActions>
      </Dialog>

      {/* Create Test Dialog */}
      <Dialog open={openTestDialog} onClose={() => setOpenTestDialog(false)} maxWidth="md" fullWidth>
        <DialogTitle sx={{ background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)', color: 'white', fontWeight: 700 }}>
          🚀 Create Performance Test
        </DialogTitle>
        <DialogContent sx={{ mt: 2 }}>
          <TextField
            autoFocus
            margin="dense"
            label="Test Name"
            fullWidth
            required
            value={testName}
            onChange={(e) => setTestName(e.target.value)}
            sx={{
              '& .MuiOutlinedInput-root': {
                '&:hover fieldset': { borderColor: '#667eea' },
                '&.Mui-focused fieldset': { borderColor: '#667eea' },
              }
            }}
          />

          <Divider sx={{ my: 3 }} />
          
          <Typography variant="subtitle2" gutterBottom sx={{ fontWeight: 600, color: '#667eea', mb: 2 }}>
            🖥️ Select Load Generators
          </Typography>
          
          {agents.length === 0 ? (
            <Alert severity="warning" sx={{ mb: 2, borderRadius: 2 }}>
              ⚠️ No online agents available. Please start at least one agent to run tests.
            </Alert>
          ) : (
            <Autocomplete
              multiple
              options={agents}
              value={selectedAgents}
              onChange={(_, newValue) => setSelectedAgents(newValue)}
              getOptionLabel={(option) => `${option.hostname} (${option.ipAddress})`}
              renderOption={(props, option) => {
                const getStatusInfo = (agent: Agent) => {
                  if (agent.status === 'busy') return { label: 'Running Test', color: 'warning' as const };
                  if (agent.currentLoad > 80) return { label: 'High Load', color: 'warning' as const };
                  return { label: 'Available', color: 'success' as const };
                };
                const statusInfo = getStatusInfo(option);
                
                return (
                  <li {...props}>
                    <Box sx={{ display: 'flex', alignItems: 'center', width: '100%' }}>
                      <Box sx={{ flexGrow: 1 }}>
                        <Typography variant="body2" sx={{ fontWeight: 600 }}>
                          {option.hostname}
                        </Typography>
                        <Typography variant="caption" color="text.secondary">
                          {option.ipAddress} • {option.cores} cores • {(option.memory / 1024).toFixed(1)} GB RAM
                        </Typography>
                      </Box>
                      <Chip label={statusInfo.label} size="small" color={statusInfo.color} sx={{ ml: 1 }} />
                    </Box>
                  </li>
                );
              }}
              renderTags={(value, getTagProps) =>
                value.map((option, index) => (
                  <Chip
                    label={option.hostname}
                    {...getTagProps({ index })}
                    color="primary"
                    size="small"
                  />
                ))
              }
              renderInput={(params) => (
                <TextField
                  {...params}
                  label="Load Generator Agents"
                  placeholder={selectedAgents.length === 0 ? "Select agents..." : "Add more agents..."}
                  required
                  helperText={selectedAgents.length > 0 
                    ? `${selectedAgents.length} agent(s) selected` 
                    : "Select at least one agent to distribute the load"}
                  sx={{
                    '& .MuiOutlinedInput-root': {
                      '&:hover fieldset': { borderColor: '#667eea' },
                      '&.Mui-focused fieldset': { borderColor: '#667eea' },
                    }
                  }}
                />
              )}
              sx={{ mb: 2 }}
            />
          )}

          {selectedAgents.length > 0 && (
            <Box sx={{ mb: 2, p: 2, bgcolor: '#f5f7fa', borderRadius: 2, border: '1px solid #e0e0e0' }}>
              <Typography variant="caption" sx={{ fontWeight: 600, color: '#667eea', display: 'block', mb: 1 }}>
                📊 Load Distribution (per agent):
              </Typography>
              {selectedAgents.map((agent) => (
                <Box key={agent.id} sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 0.5 }}>
                  <Typography variant="caption" color="text.secondary">
                    {agent.hostname}
                  </Typography>
                  <Chip 
                    label={`${Math.floor(derivedThreads / selectedAgents.length)} threads`} 
                    size="small" 
                    sx={{ bgcolor: 'white', fontWeight: 600, fontSize: '0.7rem' }}
                  />
                </Box>
              ))}
            </Box>
          )}

          {/* Global test configuration is only needed when no per-thread-group overrides exist */}
          {!hasPerThreadOverrides && (
            <>
              <Divider sx={{ my: 3 }} />

              <Typography variant="subtitle2" gutterBottom sx={{ fontWeight: 600, color: '#667eea', mb: 2 }}>
                ⚙️ Test Configuration
              </Typography>

              <Grid container spacing={2}>
                <Grid item xs={12} sm={4}>
                  <TextField
                    label="Threads (Virtual Users)"
                    type="number"
                    fullWidth
                    value={threads}
                    onChange={(e) => setThreads(Math.max(1, parseInt(e.target.value) || 1))}
                    inputProps={{ min: 1 }}
                    helperText="Total concurrent users"
                    sx={{
                      '& .MuiOutlinedInput-root': {
                        '&:hover fieldset': { borderColor: '#667eea' },
                        '&.Mui-focused fieldset': { borderColor: '#667eea' },
                      }
                    }}
                  />
                </Grid>
                <Grid item xs={12} sm={4}>
                  <TextField
                    label="Duration (seconds)"
                    type="number"
                    fullWidth
                    value={duration}
                    onChange={(e) => setDuration(Math.max(1, parseInt(e.target.value) || 1))}
                    inputProps={{ min: 1 }}
                    helperText="Test run time"
                    sx={{
                      '& .MuiOutlinedInput-root': {
                        '&:hover fieldset': { borderColor: '#667eea' },
                        '&.Mui-focused fieldset': { borderColor: '#667eea' },
                      }
                    }}
                  />
                </Grid>
                <Grid item xs={12} sm={4}>
                  <TextField
                    label="Ramp-Up (seconds)"
                    type="number"
                    fullWidth
                    value={rampUp}
                    onChange={(e) => setRampUp(Math.max(0, parseInt(e.target.value) || 0))}
                    inputProps={{ min: 0 }}
                    helperText="Time to reach full load"
                    sx={{
                      '& .MuiOutlinedInput-root': {
                        '&:hover fieldset': { borderColor: '#667eea' },
                        '&.Mui-focused fieldset': { borderColor: '#667eea' },
                      }
                    }}
                  />
                </Grid>
              </Grid>
            </>
          )}

          {/* Per-thread-group configuration for this run only (not persisted) */}
          {hasPerThreadOverrides && (
            <Box sx={{ mt: 2 }}>
              <Typography variant="subtitle2" gutterBottom sx={{ fontWeight: 600, color: '#009688', mb: 1 }}>
                🧩 Per-Thread Group Overrides (this run only)
              </Typography>
              <Grid container spacing={2}>
                {runThreadGroupsConfig.map((tg, index) => (
                  <Grid item xs={12} key={tg.name + index}>
                    <Card variant="outlined">
                      <CardContent>
                        <Typography variant="subtitle1" gutterBottom>
                          {tg.name}
                        </Typography>
                        <Grid container spacing={2}>
                          <Grid item xs={12} sm={4}>
                            <TextField
                              label="Threads"
                              type="number"
                              fullWidth
                              size="small"
                              value={tg.threads}
                              onChange={(e) => {
                                const value = Math.max(1, parseInt(e.target.value) || 1);
                                setRunThreadGroupsConfig((prev) =>
                                  prev.map((g, i) => (i === index ? { ...g, threads: value } : g))
                                );
                              }}
                              inputProps={{ min: 1 }}
                            />
                          </Grid>
                          <Grid item xs={12} sm={4}>
                            <TextField
                              label="Ramp-up (seconds)"
                              type="number"
                              fullWidth
                              size="small"
                              value={tg.rampUp}
                              onChange={(e) => {
                                const value = Math.max(0, parseInt(e.target.value) || 0);
                                setRunThreadGroupsConfig((prev) =>
                                  prev.map((g, i) => (i === index ? { ...g, rampUp: value } : g))
                                );
                              }}
                              inputProps={{ min: 0 }}
                            />
                          </Grid>
                          <Grid item xs={12} sm={4}>
                            <TextField
                              label="Duration (seconds)"
                              type="number"
                              fullWidth
                              size="small"
                              value={tg.duration}
                              onChange={(e) => {
                                const value = Math.max(1, parseInt(e.target.value) || 1);
                                setRunThreadGroupsConfig((prev) =>
                                  prev.map((g, i) => (i === index ? { ...g, duration: value } : g))
                                );
                              }}
                              inputProps={{ min: 1 }}
                            />
                          </Grid>
                        </Grid>
                      </CardContent>
                    </Card>
                  </Grid>
                ))}
              </Grid>
            </Box>
          )}

          <Box sx={{ mt: 3, p: 2, bgcolor: '#e3f2fd', borderRadius: 2, borderLeft: '4px solid #2196f3' }}>
            <Typography variant="caption" sx={{ fontWeight: 600, display: 'block', mb: 0.5 }}>
              💡 Test Summary
            </Typography>
            <Typography variant="caption" color="text.secondary">
              {derivedThreads} virtual users will be distributed across {selectedAgents.length} agent(s), 
              running for {derivedDuration} seconds with a {derivedRampUp}s ramp-up period.
            </Typography>
          </Box>

          <Box sx={{ mt: 2, p: 2, bgcolor: '#f5f5f5', borderRadius: 2, display: 'flex', alignItems: 'center' }}>
            <input 
              type="checkbox" 
              id="startImmediately" 
              checked={startImmediately}
              onChange={(e) => setStartImmediately(e.target.checked)}
              style={{ marginRight: 8 }}
            />
            <label htmlFor="startImmediately" style={{ cursor: 'pointer', fontSize: '0.875rem' }}>
              <strong>🚀 Start test immediately</strong>
              <Typography variant="caption" display="block" color="text.secondary">
                Agent will begin execution within 5 seconds
              </Typography>
            </label>
          </Box>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button onClick={() => setOpenTestDialog(false)} sx={{ color: '#666' }}>Cancel</Button>
          <Button
            onClick={handleCreateTest}
            variant="contained"
            disabled={!testName.trim() || selectedAgents.length === 0}
            sx={{ 
              background: startImmediately 
                ? 'linear-gradient(135deg, #4caf50 0%, #45a049 100%)'
                : 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
              fontWeight: 600,
              px: 3
            }}
          >
            {startImmediately ? '🚀 Create & Start' : 'Create Test'}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Replace Script Dialog */}
      <Dialog open={openReplaceDialog} onClose={() => setOpenReplaceDialog(false)} maxWidth="sm" fullWidth>
        <DialogTitle sx={{ background: 'linear-gradient(135deg, #ff9800 0%, #f57c00 100%)', color: 'white', fontWeight: 700 }}>
          🔄 Replace Script File
        </DialogTitle>
        <DialogContent sx={{ mt: 2 }}>
          <Alert severity="warning" sx={{ mb: 2 }}>
            This will replace the JMX file while keeping scenario name, dependencies, and test history.
          </Alert>
          <Box>
            <Typography variant="subtitle2" gutterBottom sx={{ fontWeight: 600 }}>
              Select New JMX File
            </Typography>
            <input
              type="file"
              accept=".jmx"
              onChange={(e) => setReplaceScriptFile(e.target.files?.[0] || null)}
              style={{
                padding: '12px',
                border: '2px dashed #ff9800',
                borderRadius: '8px',
                width: '100%',
                cursor: 'pointer',
                backgroundColor: '#fff3e0'
              }}
            />
            {replaceScriptFile && (
              <Typography variant="caption" color="success.main" sx={{ mt: 1, display: 'block' }}>
                ✓ Selected: {replaceScriptFile.name}
              </Typography>
            )}
          </Box>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button onClick={() => {
            setOpenReplaceDialog(false);
            setReplaceScriptFile(null);
          }} sx={{ color: '#666' }}>
            Cancel
          </Button>
          <Button
            onClick={handleReplaceScript}
            variant="contained"
            disabled={!replaceScriptFile}
            sx={{ 
              background: 'linear-gradient(135deg, #ff9800 0%, #f57c00 100%)',
              fontWeight: 600
            }}
          >
            Replace Script
          </Button>
        </DialogActions>
      </Dialog>
    </Container>
  );
}
