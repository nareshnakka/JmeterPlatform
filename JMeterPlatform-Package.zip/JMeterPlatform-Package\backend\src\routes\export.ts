import { Router, Response } from 'express';
import { PrismaClient } from '@prisma/client';
import { authenticate, AuthRequest } from '../middleware/auth';

const router = Router();

router.use(authenticate);

// Export test results
router.get('/:testId', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const prisma: PrismaClient = req.app.get('prisma');
    const { format = 'json', type = 'summary' } = req.query;
    
    const test = await prisma.test.findFirst({
      where: { id: req.params.testId as string },
      include: {
        project: true,
        script: true,
        results: true,
        metrics: { orderBy: { timestamp: 'asc' } },
        testAgents: { include: { agent: true } }
      }
    });
    
    if (!test || test.project.userId !== req.user!.id) {
      res.status(404).json({ error: 'Test not found' });

      return;
    }
    
    if (!test.results) {
      res.status(400).json({ error: 'Test has no results yet' });

      return;
    }
    
    if (format === 'csv') {
      // Generate CSV
      let csv = '';
      
      if (type === 'summary') {
        csv = 'Metric,Value\n';
        csv += `Test Name,${test.name}\n`;
        csv += `Total Samples,${test.results.totalSamples}\n`;
        csv += `Successful Samples,${test.results.successfulSamples}\n`;
        csv += `Failed Samples,${test.results.failedSamples}\n`;
        csv += `Avg Response Time,${test.results.avgResponseTime}\n`;
        csv += `Min Response Time,${test.results.minResponseTime}\n`;
        csv += `Max Response Time,${test.results.maxResponseTime}\n`;
        csv += `Throughput,${test.results.throughput}\n`;
        csv += `Error Rate,${test.results.errorRate}\n`;
        csv += `P50,${test.results.p50}\n`;
        csv += `P90,${test.results.p90}\n`;
        csv += `P95,${test.results.p95}\n`;
        csv += `P99,${test.results.p99}\n`;
      } else if (type === 'detailed' || type === 'metrics') {
        csv = 'Timestamp,Label,Response Time,Status Code,Success,Bytes,Threads,Latency\n';
        test.metrics.forEach(m => {
          csv += `${m.timestamp.toISOString()},${m.label},${m.responseTime},${m.statusCode},${m.success},${m.bytes},${m.threads},${m.latency}\n`;
        });
      }
      
      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', `attachment; filename="test-${test.id}-${type}.csv"`);
      res.send(csv);

      return;
    }
    
    // JSON format
    const data = type === 'summary'
      ? {
          test: {
            id: test.id,
            name: test.name,
            status: test.status,
            threads: test.threads,
            duration: test.duration
          },
          results: test.results,
          agents: test.testAgents.map(ta => ({
            name: ta.agent.name,
            threads: ta.threads,
            status: ta.status
          }))
        }
      : type === 'metrics'
      ? {
          test: { id: test.id, name: test.name },
          metrics: test.metrics
        }
      : {
          test,
          results: test.results,
          metrics: test.metrics
        };
    
    res.json(data);
  } catch (error) {
    console.error('Error exporting results:', error);
    res.status(500).json({ error: 'Failed to export results' });
  }
});

export default router;

