import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcrypt';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Seeding database...');

  // Create default admin user
  const adminEmail = 'admin@example.com';
  const adminPassword = 'Admin@123';
  
  const existingAdmin = await prisma.user.findUnique({
    where: { email: adminEmail }
  });

  if (!existingAdmin) {
    const passwordHash = await bcrypt.hash(adminPassword, 10);
    
    await prisma.user.create({
      data: {
        email: adminEmail,
        passwordHash: passwordHash,
        role: 'admin'
      }
    });
    
    console.log('✅ Created admin user:', adminEmail);
    console.log('   Password:', adminPassword);
  } else {
    console.log('ℹ️  Admin user already exists');
  }

  // Create sample project for admin
  const adminUser = await prisma.user.findUnique({
    where: { email: adminEmail }
  });

  if (adminUser) {
    const existingProject = await prisma.project.findFirst({
      where: { userId: adminUser.id }
    });

    if (!existingProject) {
      await prisma.project.create({
        data: {
          name: 'Sample Project',
          description: 'Default sample project for testing',
          userId: adminUser.id
        }
      });
      console.log('✅ Created sample project');
    }
  }

  console.log('🎉 Database seeding completed!');
}

main()
  .catch((e) => {
    console.error('❌ Error seeding database:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
