# Implementation Guide

## Quick Start

This guide will help you implement the JMeter Testing Platform step by step.

## Prerequisites

- Node.js 18+ (for backend and frontend)
- Python 3.9+ (for agent)
- Docker & Docker Compose
- PostgreSQL 14+
- Redis 7+
- JMeter 5.5+

## Phase 1: MVP Implementation

### Step 1: Set Up Development Environment

```bash
# Clone or create project structure
mkdir jmeter-platform
cd jmeter-platform

# Create subdirectories
mkdir -p frontend backend agent docker docs
```

### Step 2: Backend Setup (Node.js + Express + TypeScript)

```bash
cd backend
npm init -y
npm install express cors dotenv pg prisma @prisma/client
npm install -D typescript @types/node @types/express ts-node nodemon
npm install jsonwebtoken bcrypt multer
npm install -D @types/jsonwebtoken @types/bcrypt @types/multer
```

**backend/package.json scripts**:
```json
{
  "scripts": {
    "dev": "nodemon src/index.ts",
    "build": "tsc",
    "start": "node dist/index.js",
    "prisma:generate": "prisma generate",
    "prisma:migrate": "prisma migrate dev"
  }
}
```

**backend/tsconfig.json**:
```json
{
  "compilerOptions": {
    "target": "ES2020",
    "module": "commonjs",
    "outDir": "./dist",
    "rootDir": "./src",
    "strict": true,
    "esModuleInterop": true,
    "skipLibCheck": true,
    "forceConsistentCasingInFileNames": true
  }
}
```

**backend/src/index.ts** (Basic setup):
```typescript
import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Routes
app.use('/api/auth', require('./routes/auth'));
app.use('/api/scripts', require('./routes/scripts'));
app.use('/api/agents', require('./routes/agents'));
app.use('/api/tests', require('./routes/tests'));

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
```

**backend/prisma/schema.prisma**:
```prisma
datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
}

generator client {
  provider = "prisma-client-js"
}

model User {
  id           String    @id @default(uuid())
  email        String    @unique
  passwordHash String    @map("password_hash")
  role         String    @default("user")
  createdAt    DateTime  @default(now()) @map("created_at")
  projects     Project[]
  tests        Test[]

  @@map("users")
}

model Project {
  id        String   @id @default(uuid())
  name      String
  ownerId   String   @map("owner_id")
  owner     User     @relation(fields: [ownerId], references: [id])
  createdAt DateTime @default(now()) @map("created_at")
  scripts   Script[]
  tests     Test[]

  @@map("projects")
}

model Script {
  id          String       @id @default(uuid())
  projectId   String       @map("project_id")
  project     Project      @relation(fields: [projectId], references: [id])
  name        String
  filePath    String       @map("file_path")
  version     Int          @default(1)
  uploadedBy  String       @map("uploaded_by")
  uploadedAt  DateTime     @default(now()) @map("uploaded_at")
  dependencies Dependency[]
  tests       Test[]

  @@map("scripts")
}

model Dependency {
  id       String @id @default(uuid())
  scriptId String @map("script_id")
  script   Script @relation(fields: [scriptId], references: [id])
  name     String
  filePath String @map("file_path")
  type     String // 'csv', 'jar', 'properties'

  @@map("dependencies")
}

model Agent {
  id            String      @id @default(uuid())
  name          String
  hostname      String
  ipAddress     String?     @map("ip_address")
  location      String?
  status        String      @default("offline") // 'online', 'offline', 'busy'
  maxThreads    Int         @default(1000) @map("max_threads")
  registeredAt  DateTime    @default(now()) @map("registered_at")
  lastHeartbeat DateTime?   @map("last_heartbeat")
  testAgents    TestAgent[]

  @@map("agents")
}

model Test {
  id              String      @id @default(uuid())
  projectId       String      @map("project_id")
  project         Project     @relation(fields: [projectId], references: [id])
  scriptId        String      @map("script_id")
  script          Script      @relation(fields: [scriptId], references: [id])
  name            String
  status          String      @default("pending") // 'pending', 'running', 'completed', 'failed'
  startedBy       String      @map("started_by")
  user            User        @relation(fields: [startedBy], references: [id])
  startedAt       DateTime?   @map("started_at")
  completedAt     DateTime?   @map("completed_at")
  totalThreads    Int         @map("total_threads")
  durationSeconds Int         @map("duration_seconds")
  testAgents      TestAgent[]
  results         TestResult[]

  @@map("tests")
}

model TestAgent {
  id              String @id @default(uuid())
  testId          String @map("test_id")
  test            Test   @relation(fields: [testId], references: [id])
  agentId         String @map("agent_id")
  agent           Agent  @relation(fields: [agentId], references: [id])
  threadsAssigned Int    @map("threads_assigned")
  status          String @default("pending")

  @@map("test_agents")
}

model TestResult {
  id                String  @id @default(uuid())
  testId            String  @map("test_id")
  test              Test    @relation(fields: [testId], references: [id])
  agentId           String  @map("agent_id")
  totalSamples      Int     @map("total_samples")
  errorCount        Int     @map("error_count")
  avgResponseTime   Float   @map("avg_response_time")
  minResponseTime   Float   @map("min_response_time")
  maxResponseTime   Float   @map("max_response_time")
  throughput        Float
  resultFilePath    String  @map("result_file_path")

  @@map("test_results")
}
```

**backend/.env**:
```env
DATABASE_URL="postgresql://user:password@localhost:5432/jmeter_platform"
JWT_SECRET="your-secret-key-change-in-production"
PORT=3000
UPLOAD_DIR=./uploads
MINIO_ENDPOINT=localhost
MINIO_PORT=9000
MINIO_ACCESS_KEY=minioadmin
MINIO_SECRET_KEY=minioadmin
MINIO_USE_SSL=false
```

### Step 3: Frontend Setup (React + TypeScript)

```bash
cd ../frontend
npm create vite@latest . -- --template react-ts
npm install
npm install @mui/material @mui/icons-material @emotion/react @emotion/styled
npm install react-router-dom axios recharts
npm install @tanstack/react-query zustand
```

**frontend/src/main.tsx**:
```typescript
import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import App from './App';
import './index.css';

const queryClient = new QueryClient();

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <QueryClientProvider client={queryClient}>
      <BrowserRouter>
        <App />
      </BrowserRouter>
    </QueryClientProvider>
  </React.StrictMode>
);
```

**frontend/src/App.tsx**:
```typescript
import { Routes, Route } from 'react-router-dom';
import { ThemeProvider, createTheme } from '@mui/material';
import Layout from './components/Layout';
import Dashboard from './pages/Dashboard';
import Scripts from './pages/Scripts';
import Agents from './pages/Agents';
import Tests from './pages/Tests';
import Results from './pages/Results';
import Login from './pages/Login';

const theme = createTheme({
  palette: {
    primary: { main: '#1976d2' },
    secondary: { main: '#dc004e' },
  },
});

function App() {
  return (
    <ThemeProvider theme={theme}>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/" element={<Layout />}>
          <Route index element={<Dashboard />} />
          <Route path="scripts" element={<Scripts />} />
          <Route path="agents" element={<Agents />} />
          <Route path="tests" element={<Tests />} />
          <Route path="results/:testId" element={<Results />} />
        </Route>
      </Routes>
    </ThemeProvider>
  );
}

export default App;
```

### Step 4: Agent Setup (Python)

```bash
cd ../agent
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
pip install requests websocket-client psutil
```

**agent/requirements.txt**:
```
requests==2.31.0
websocket-client==1.6.4
psutil==5.9.6
python-dotenv==1.0.0
```

**agent/agent.py**:
```python
import os
import subprocess
import requests
import time
import json
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

class JMeterAgent:
    def __init__(self):
        self.backend_url = os.getenv('BACKEND_URL', 'http://localhost:3000')
        self.agent_id = None
        self.jmeter_home = os.getenv('JMETER_HOME', '/opt/jmeter')
        self.work_dir = Path('./work')
        self.work_dir.mkdir(exist_ok=True)
        
    def register(self):
        """Register agent with backend"""
        import socket
        payload = {
            'name': os.getenv('AGENT_NAME', socket.gethostname()),
            'hostname': socket.gethostname(),
            'ip_address': socket.gethostbyname(socket.gethostname()),
            'location': os.getenv('AGENT_LOCATION', 'unknown'),
            'max_threads': int(os.getenv('MAX_THREADS', '1000'))
        }
        
        response = requests.post(f'{self.backend_url}/api/agents/register', json=payload)
        if response.status_code == 201:
            self.agent_id = response.json()['id']
            print(f'Agent registered with ID: {self.agent_id}')
        else:
            raise Exception(f'Failed to register agent: {response.text}')
    
    def heartbeat(self):
        """Send heartbeat to backend"""
        if self.agent_id:
            requests.put(f'{self.backend_url}/api/agents/{self.agent_id}/heartbeat')
    
    def poll_for_tests(self):
        """Poll backend for test assignments"""
        if not self.agent_id:
            return None
        
        response = requests.get(f'{self.backend_url}/api/agents/{self.agent_id}/pending-tests')
        if response.status_code == 200:
            tests = response.json()
            return tests[0] if tests else None
        return None
    
    def download_test_files(self, test_id):
        """Download JMX and dependencies"""
        test_dir = self.work_dir / test_id
        test_dir.mkdir(exist_ok=True)
        
        # Download JMX
        response = requests.get(f'{self.backend_url}/api/tests/{test_id}/jmx')
        jmx_path = test_dir / 'test.jmx'
        jmx_path.write_bytes(response.content)
        
        # Download dependencies
        response = requests.get(f'{self.backend_url}/api/tests/{test_id}/dependencies')
        deps = response.json()
        for dep in deps:
            dep_response = requests.get(dep['url'])
            (test_dir / dep['name']).write_bytes(dep_response.content)
        
        return str(jmx_path)
    
    def execute_test(self, test_id, jmx_path, threads):
        """Execute JMeter test"""
        result_file = self.work_dir / test_id / 'results.jtl'
        
        cmd = [
            f'{self.jmeter_home}/bin/jmeter',
            '-n',
            '-t', jmx_path,
            '-l', str(result_file),
            f'-Jthreads={threads}'
        ]
        
        print(f'Executing: {" ".join(cmd)}')
        process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        
        # Update status
        requests.put(f'{self.backend_url}/api/tests/{test_id}/status', 
                    json={'status': 'running', 'agent_id': self.agent_id})
        
        # Wait for completion
        process.wait()
        
        return str(result_file)
    
    def upload_results(self, test_id, result_file):
        """Upload results to backend"""
        with open(result_file, 'rb') as f:
            files = {'result': f}
            requests.post(f'{self.backend_url}/api/tests/{test_id}/results', 
                         files=files,
                         data={'agent_id': self.agent_id})
    
    def run(self):
        """Main agent loop"""
        self.register()
        
        while True:
            try:
                self.heartbeat()
                
                test = self.poll_for_tests()
                if test:
                    print(f'Received test assignment: {test["id"]}')
                    jmx_path = self.download_test_files(test['id'])
                    result_file = self.execute_test(test['id'], jmx_path, test['threads'])
                    self.upload_results(test['id'], result_file)
                    print(f'Test {test["id"]} completed')
                
                time.sleep(5)  # Poll every 5 seconds
                
            except KeyboardInterrupt:
                print('Agent shutting down...')
                break
            except Exception as e:
                print(f'Error: {e}')
                time.sleep(10)

if __name__ == '__main__':
    agent = JMeterAgent()
    agent.run()
```

**agent/.env**:
```env
BACKEND_URL=http://localhost:3000
AGENT_NAME=agent-001
AGENT_LOCATION=us-east-1
MAX_THREADS=1000
JMETER_HOME=/opt/jmeter
```

### Step 5: Docker Setup

**docker/docker-compose.yml**:
```yaml
version: '3.8'

services:
  postgres:
    image: postgres:14
    environment:
      POSTGRES_USER: jmeter
      POSTGRES_PASSWORD: jmeter123
      POSTGRES_DB: jmeter_platform
    ports:
      - "5432:5432"
    volumes:
      - postgres_data:/var/lib/postgresql/data

  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"

  minio:
    image: minio/minio
    command: server /data --console-address ":9001"
    environment:
      MINIO_ROOT_USER: minioadmin
      MINIO_ROOT_PASSWORD: minioadmin
    ports:
      - "9000:9000"
      - "9001:9001"
    volumes:
      - minio_data:/data

  backend:
    build:
      context: ../backend
      dockerfile: ../docker/backend.Dockerfile
    ports:
      - "3000:3000"
    environment:
      DATABASE_URL: postgresql://jmeter:jmeter123@postgres:5432/jmeter_platform
      REDIS_URL: redis://redis:6379
    depends_on:
      - postgres
      - redis
      - minio

  frontend:
    build:
      context: ../frontend
      dockerfile: ../docker/frontend.Dockerfile
    ports:
      - "5173:5173"
    depends_on:
      - backend

volumes:
  postgres_data:
  minio_data:
```

### Step 6: Run the Application

```bash
# Start infrastructure
cd docker
docker-compose up -d postgres redis minio

# Run database migrations
cd ../backend
npx prisma migrate dev
npx prisma generate

# Start backend
npm run dev

# In another terminal, start frontend
cd ../frontend
npm run dev

# In another terminal, start agent
cd ../agent
source venv/bin/activate
python agent.py
```

## Next Steps

1. Implement authentication endpoints
2. Build script upload functionality
3. Create agent management UI
4. Implement test execution logic
5. Add real-time metrics streaming
6. Build results visualization

See [API_REFERENCE.md](API_REFERENCE.md) for detailed API documentation.
