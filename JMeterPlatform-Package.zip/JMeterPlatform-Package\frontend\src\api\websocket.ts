import { io, Socket } from 'socket.io-client';

class WebSocketClient {
  private socket: Socket | null = null;
  private url: string;

  constructor(url: string) {
    this.url = url;
  }

  connect(token: string) {
    
    this.socket = io(this.url, {
      auth: {
        token,
      },
      transports: ['websocket', 'polling'],
    });

    this.socket.on('connect', () => {
      console.log('WebSocket connected');
    });

    this.socket.on('disconnect', () => {
      console.log('WebSocket disconnected');
    });

    this.socket.on('connect_error', (error) => {
      console.error('WebSocket connection error:', error);
    });

    return this.socket;
  }

  disconnect() {
    if (this.socket) {
      this.socket.disconnect();
      this.socket = null;
    }
  }

  onTestStarted(callback: (data: any) => void) {
    this.socket?.on('test:started', callback);
  }

  onTestStopped(callback: (data: any) => void) {
    this.socket?.on('test:stopped', callback);
  }

  onTestCompleted(callback: (data: any) => void) {
    this.socket?.on('test:completed', callback);
  }

  onTestMetrics(callback: (data: any) => void) {
    this.socket?.on('test:metrics', callback);
  }

  onAgentStatus(callback: (data: any) => void) {
    this.socket?.on('agent:status', callback);
  }

  offAllListeners() {
    if (this.socket) {
      this.socket.off('test:started');
      this.socket.off('test:stopped');
      this.socket.off('test:completed');
      this.socket.off('test:metrics');
      this.socket.off('agent:status');
    }
  }

  getSocket(): Socket | null {
    return this.socket;
  }
}

const wsUrl = import.meta.env.VITE_WS_URL || 'http://localhost:3000';
export const wsClient = new WebSocketClient(wsUrl);

export default wsClient;
