import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Container,
  Grid,
  Card,
  CardContent,
  Typography,
  Button,
  AppBar,
  Toolbar,
  Box,
  Paper,
  IconButton,
  Chip,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  Select,
  MenuItem,
  InputAdornment,
} from '@mui/material';
import {
  Add as AddIcon,
  Logout as LogoutIcon,
  FolderOpen as ProjectsIcon,
  Computer as AgentsIcon,
  PlayArrow as RunningIcon,
  CheckCircle as CompletedIcon,
  TrendingUp as TrendingUpIcon,
  Menu as MenuIcon,
  Assessment as AssessmentIcon,
  ArrowForward as ArrowForwardIcon,
  Search as SearchIcon,
} from '@mui/icons-material';
import { api } from '../api/client';
import { useAuthStore } from '../store/auth';

export default function Dashboard() {
  const navigate = useNavigate();
  const { user, logout } = useAuthStore();
  const [stats, setStats] = useState({
    projects: 0,
    agents: 0,
    testsRunning: 0,
    testsCompleted: 0,
  });
  const [recentTests, setRecentTests] = useState<any[]>([]);
  const [filters, setFilters] = useState({
    scenarioName: '',
    testName: '',
    status: '',
    started: '',
    completed: '',
  });
  
  useEffect(() => {
    const loadStats = async () => {
      try {
        const projects = await api.getProjects();
        const agents = await api.getAgents();
        
        let runningTests = 0;
        let completedTests = 0;
        
        try {
          const tests = await api.getTests();
          runningTests = tests.filter((t: any) => t.status === 'running').length;
          completedTests = tests.filter((t: any) => t.status === 'completed').length;
          
          // Get most recent 5 tests
          const sortedTests = [...tests].sort((a: any, b: any) => 
            new Date(b.startedAt || b.createdAt).getTime() - new Date(a.startedAt || a.createdAt).getTime()
          );
          setRecentTests(sortedTests.slice(0, 5));
        } catch (err) {
          console.error('Failed to load tests:', err);
        }
        
        setStats({
          projects: projects.length,
          agents: agents.filter((a: any) => a.status === 'online').length,
          testsRunning: runningTests,
          testsCompleted: completedTests,
        });
      } catch (err) {
        console.error('Failed to load dashboard stats:', err);
      }
    };
    
    loadStats();
  }, []);
  
  const filteredTests = recentTests.filter((test) => {
    const scenarioName = (test.scriptName || test.filename || test.name || '').toLowerCase();
    const testName = (test.name || test.scriptName || '').toLowerCase();
    const status = (test.status || '').toLowerCase();
    const started = test.startedAt || test.createdAt || '';
    const completed = test.completedAt || '';
    
    return (
      scenarioName.includes(filters.scenarioName.toLowerCase()) &&
      testName.includes(filters.testName.toLowerCase()) &&
      (filters.status === '' || status === filters.status.toLowerCase()) &&
      (!filters.started || started.includes(filters.started)) &&
      (!filters.completed || completed.includes(filters.completed))
    );
  });
  
  return (
    <>
      <Box 
        sx={{ 
          background: 'linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%)',
          minHeight: '100vh',
          py: 4
        }}
      >
        <Container maxWidth={false}>
          <Paper 
            elevation={0}
            sx={{ 
              p: 3, 
              mb: 4,
              background: 'white',
              borderRadius: 2,
              boxShadow: '0 2px 12px rgba(0,0,0,0.08)'
            }}
          >
            <Typography 
              variant="h4" 
              gutterBottom 
              sx={{ 
                fontWeight: 700,
                background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                backgroundClip: 'text',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent'
              }}
            >
              Performance Dashboard
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Monitor and manage your load testing infrastructure
            </Typography>
          </Paper>
        
          <Grid container spacing={3}>
            <Grid item xs={12} sm={6} md={3}>
              <Card 
                sx={{ 
                  height: '100%',
                  transition: 'transform 0.2s, box-shadow 0.2s',
                  '&:hover': {
                    transform: 'translateY(-4px)',
                    boxShadow: '0 8px 24px rgba(102, 126, 234, 0.3)'
                  },
                  borderTop: '4px solid #667eea',
                  cursor: 'pointer'
                }}
                onClick={() => navigate('/projects')}
              >
                <CardContent>
                  <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                    <ProjectsIcon sx={{ fontSize: 40, color: '#667eea', mr: 1 }} />
                    <Typography color="textSecondary" variant="h6">
                      Projects
                    </Typography>
                  </Box>
                  <Typography variant="h3" sx={{ fontWeight: 700, color: '#667eea' }}>
                    {stats.projects}
                  </Typography>
                  <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
                    Active projects
                  </Typography>
                </CardContent>
              </Card>
            </Grid>
          
            <Grid item xs={12} sm={6} md={3}>
              <Card 
                sx={{ 
                  height: '100%',
                  transition: 'transform 0.2s, box-shadow 0.2s',
                  '&:hover': {
                    transform: 'translateY(-4px)',
                    boxShadow: '0 8px 24px rgba(76, 175, 80, 0.3)'
                  },
                  borderTop: '4px solid #4caf50',
                  cursor: 'pointer'
                }}
                onClick={() => navigate('/agents')}
              >
                <CardContent>
                  <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                    <AgentsIcon sx={{ fontSize: 40, color: '#4caf50', mr: 1 }} />
                    <Typography color="textSecondary" variant="h6">
                      Agents
                    </Typography>
                  </Box>
                  <Typography variant="h3" sx={{ fontWeight: 700, color: '#4caf50' }}>
                    {stats.agents}
                  </Typography>
                  <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
                    Online now
                  </Typography>
                </CardContent>
              </Card>
            </Grid>
          
            <Grid item xs={12} sm={6} md={3}>
              <Card 
                sx={{ 
                  height: '100%',
                  transition: 'transform 0.2s, box-shadow 0.2s',
                  '&:hover': {
                    transform: 'translateY(-4px)',
                    boxShadow: '0 8px 24px rgba(255, 152, 0, 0.3)'
                  },
                  borderTop: '4px solid #ff9800'
                }}
              >
                <CardContent>
                  <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                    <RunningIcon sx={{ fontSize: 40, color: '#ff9800', mr: 1 }} />
                    <Typography color="textSecondary" variant="h6">
                      Running
                    </Typography>
                  </Box>
                  <Typography variant="h3" sx={{ fontWeight: 700, color: '#ff9800' }}>
                    {stats.testsRunning}
                  </Typography>
                  <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
                    Tests in progress
                  </Typography>
                </CardContent>
              </Card>
            </Grid>
          
            <Grid item xs={12} sm={6} md={3}>
              <Card 
                sx={{ 
                  height: '100%',
                  transition: 'transform 0.2s, box-shadow 0.2s',
                  '&:hover': {
                    transform: 'translateY(-4px)',
                    boxShadow: '0 8px 24px rgba(33, 150, 243, 0.3)'
                  },
                  borderTop: '4px solid #2196f3'
                }}
              >
                <CardContent>
                  <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                    <CompletedIcon sx={{ fontSize: 40, color: '#2196f3', mr: 1 }} />
                    <Typography color="textSecondary" variant="h6">
                      Completed
                    </Typography>
                  </Box>
                  <Typography variant="h3" sx={{ fontWeight: 700, color: '#2196f3' }}>
                    {stats.testsCompleted}
                  </Typography>
                  <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
                    Total tests
                  </Typography>
                </CardContent>
              </Card>
            </Grid>
          </Grid>

          {recentTests.length > 0 && (
            <Paper 
              elevation={0}
              sx={{ 
                mt: 4,
                background: 'white',
                borderRadius: 2,
                boxShadow: '0 2px 12px rgba(0,0,0,0.08)',
                overflow: 'hidden'
              }}
            >
              <Box sx={{ p: 3, pb: 2, display: 'flex', alignItems: 'center' }}>
                <AssessmentIcon sx={{ fontSize: 28, color: '#667eea', mr: 1 }} />
                <Typography variant="h5" sx={{ fontWeight: 600, color: '#333' }}>
                  Recent Test Runs
                </Typography>
              </Box>
              
              <TableContainer>
                <Table>
                  <TableHead>
                    <TableRow sx={{ bgcolor: '#f5f7fa' }}>
                      <TableCell sx={{ fontWeight: 700, color: '#667eea' }}>Scenario Name</TableCell>
                      <TableCell sx={{ fontWeight: 700, color: '#667eea' }}>Test Name</TableCell>
                      <TableCell sx={{ fontWeight: 700, color: '#667eea' }}>Status</TableCell>
                      <TableCell sx={{ fontWeight: 700, color: '#667eea' }}>Started</TableCell>
                      <TableCell sx={{ fontWeight: 700, color: '#667eea' }}>Completed</TableCell>
                      <TableCell sx={{ fontWeight: 700, color: '#667eea', textAlign: 'center' }}>Action</TableCell>
                    </TableRow>
                    <TableRow sx={{ bgcolor: 'white' }}>
                      <TableCell sx={{ py: 1 }}>
                        <TextField
                          size="small"
                          placeholder="Filter..."
                          value={filters.scenarioName}
                          onChange={(e) => setFilters({ ...filters, scenarioName: e.target.value })}
                          InputProps={{
                            startAdornment: (
                              <InputAdornment position="start">
                                <SearchIcon fontSize="small" sx={{ color: '#999' }} />
                              </InputAdornment>
                            ),
                          }}
                          sx={{ width: '100%' }}
                        />
                      </TableCell>
                      <TableCell sx={{ py: 1 }}>
                        <TextField
                          size="small"
                          placeholder="Filter..."
                          value={filters.testName}
                          onChange={(e) => setFilters({ ...filters, testName: e.target.value })}
                          InputProps={{
                            startAdornment: (
                              <InputAdornment position="start">
                                <SearchIcon fontSize="small" sx={{ color: '#999' }} />
                              </InputAdornment>
                            ),
                          }}
                          sx={{ width: '100%' }}
                        />
                      </TableCell>
                      <TableCell sx={{ py: 1 }}>
                        <Select
                          size="small"
                          value={filters.status}
                          onChange={(e) => setFilters({ ...filters, status: e.target.value })}
                          displayEmpty
                          sx={{ width: '100%' }}
                        >
                          <MenuItem value="">All</MenuItem>
                          <MenuItem value="running">Running</MenuItem>
                          <MenuItem value="completed">Completed</MenuItem>
                          <MenuItem value="failed">Failed</MenuItem>
                          <MenuItem value="pending">Pending</MenuItem>
                        </Select>
                      </TableCell>
                      <TableCell sx={{ py: 1 }}>
                        <TextField
                          size="small"
                          placeholder="Filter..."
                          value={filters.started}
                          onChange={(e) => setFilters({ ...filters, started: e.target.value })}
                          InputProps={{
                            startAdornment: (
                              <InputAdornment position="start">
                                <SearchIcon fontSize="small" sx={{ color: '#999' }} />
                              </InputAdornment>
                            ),
                          }}
                          sx={{ width: '100%' }}
                        />
                      </TableCell>
                      <TableCell sx={{ py: 1 }}>
                        <TextField
                          size="small"
                          placeholder="Filter..."
                          value={filters.completed}
                          onChange={(e) => setFilters({ ...filters, completed: e.target.value })}
                          InputProps={{
                            startAdornment: (
                              <InputAdornment position="start">
                                <SearchIcon fontSize="small" sx={{ color: '#999' }} />
                              </InputAdornment>
                            ),
                          }}
                          sx={{ width: '100%' }}
                        />
                      </TableCell>
                      <TableCell sx={{ py: 1 }} />
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {filteredTests.map((test) => {
                      const statusColor = 
                        test.status === 'running' ? '#ff9800' : 
                        test.status === 'completed' ? '#4caf50' : 
                        test.status === 'collating' ? '#2196f3' :
                        test.status === 'failed' ? '#f44336' : '#9e9e9e';
                      
                      const displayStatus = test.status === 'collating' ? 'Collating Results' : test.status;
                      const scenarioName =
                        (test.script && test.script.name) ||
                        test.scriptName ||
                        test.filename ||
                        test.name ||
                        '-';
                      const scriptId = test.script && test.script.id;
                      const projectId = test.project && test.project.id;
                      
                      return (
                        <TableRow 
                          key={test.id}
                          sx={{ 
                            cursor: 'pointer',
                            '&:hover': {
                              bgcolor: '#f5f7fa'
                            },
                            transition: 'background-color 0.2s'
                          }}
                        >
                          <TableCell>
                            <Typography
                              variant="body2"
                              color="primary"
                              sx={{ cursor: scriptId ? 'pointer' : 'default' }}
                              onClick={() => {
                                if (projectId) {
                                  navigate(`/projects/${projectId}`);
                                } else if (scriptId) {
                                  // Fallback: if project is not present, show script test history
                                  navigate(`/scripts/${scriptId}/tests`);
                                }
                              }}
                            >
                              {scenarioName}
                            </Typography>
                          </TableCell>
                          <TableCell>
                            <Typography
                              variant="body1"
                              sx={{ fontWeight: 600, cursor: 'pointer' }}
                              onClick={() => navigate(`/tests/${test.id}`)}
                            >
                              {test.name || test.scriptName || 'Test Run'}
                            </Typography>
                            {test.testAgents && test.testAgents.length > 1 && (
                              <Box sx={{ display: 'flex', alignItems: 'center', mt: 0.5 }}>
                                <AgentsIcon sx={{ fontSize: 14, mr: 0.5, color: 'primary.main' }} />
                                <Typography variant="caption" color="primary">
                                  {test.testAgents.length} agents • {test.threads} total threads
                                </Typography>
                              </Box>
                            )}
                          </TableCell>
                          <TableCell>
                            <Chip 
                              label={displayStatus} 
                              size="small"
                              sx={{ 
                                bgcolor: statusColor,
                                color: 'white',
                                fontWeight: 600,
                                textTransform: 'capitalize'
                              }}
                            />
                          </TableCell>
                          <TableCell>
                            <Typography variant="body2" color="text.secondary">
                              {new Date(test.startedAt || test.createdAt).toLocaleString()}
                            </Typography>
                          </TableCell>
                          <TableCell>
                            <Typography variant="body2" color="text.secondary">
                              {test.completedAt ? new Date(test.completedAt).toLocaleString() : '-'}
                            </Typography>
                          </TableCell>
                          <TableCell sx={{ textAlign: 'center' }}>
                            <IconButton 
                              size="small"
                              sx={{ color: '#667eea' }}
                              onClick={(e) => {
                                e.stopPropagation();
                                navigate(`/tests/${test.id}`);
                              }}
                            >
                              <ArrowForwardIcon />
                            </IconButton>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </TableContainer>
            </Paper>
          )}
        </Container>
      </Box>
    </>
  );
}
